# Bosqich 3 — Biznes-spetsifik operativ komponentlar

> Bosqich 2 universal komponentlar ustiga 4 ta biznes turi uchun maxsus komponentlar.
> Adapter'lar Bosqich 4'da yoziladi — bu yerda faqat komponent kutubxonasi.

---

## Yetkazib berilgan komponentlar (18 ta)

### Bosqich 3.A — Restaurant (4 ta)

| Komponent | Vazifa |
|---|---|
| `TableMap` | Stollar vizual xaritasi. Zal bo'yicha guruhlangan, har stol holati rangli kartochka. Tap → status menyu |
| `ReservationCard` | Bron kartochkasi. OrderCard kabi extension renderer va advance tugma. InboxList ichida ham ishlatish mumkin |
| `BanquetManager` | Banket CRUD (to'y, korporativ tadbir). Multi-table booking |
| `HallStatusBoard` | Zal statistikasi (free/reserved/occupied/cleaning soni, jami band o'rinlar) |

ReservationCard extension'lari (alohida fayl emas, ReservationCard.js ichida): `SpecialRequestsBlock`, `DepositStatusBlock`, `PartyInfoBlock`.

### Bosqich 3.B — Appointment service (5 ta)

| Komponent | Vazifa |
|---|---|
| `CalendarView` | Kun bo'yicha uchrashuvlar jadvali. Specialist filter. Vaqt slot'lariga guruhlangan |
| `ServiceCRUD` | Xizmatlar (soch olish, manikyur va h.k.) — nom, davomiyligi, narx, active |
| `SpecialistCRUD` | Mutaxassislar — ism, qaysi xizmatlar (chip toggle), ish vaqti, active |
| `AppointmentCard` | Uchrashuv kartochkasi. OrderCard kabi pattern, advance tugma |
| `WalkInQueue` | Navbat — oldindan bron qilinmagan tashriflar. Tezkor qo'shish/chiqarish |

### Bosqich 3.C — Custom production (4 ta)

| Komponent | Vazifa |
|---|---|
| `TechBriefViewer` | Texnik topshiriq ko'rinishi. Mijoz ma'lumotlari, tavsifi, narx, real-time stage yangilanish |
| `StageAdvancer` | Bosqichni o'zgartirish tugmalari. Backend transition jadvali bilan mos |
| `PriceProposalSender` | Narx taklif yuborish (faqat brief_review da). Yuborilgach avtomatik proposal_sent |
| `OnSiteDispatch` | O'lcham olish/o'rnatish uchun ishchi yuborish. CRUD va status (scheduled/in_progress/completed/cancelled) |

### Bosqich 3.D — Courier service (5 ta)

| Komponent | Vazifa |
|---|---|
| `CourierList` | Kuryerlar ro'yxati. Filter (available/on_route/busy/offline). Real-time status va lokatsiya yangilanish |
| `CourierAssigner` | Tayinlanmagan yetkazib berishlarga kuryer tanlash sheet. Oflayn kuryerlar avtomatik filtrlanadi |
| `LiveTracker` | **Push-based** kuryer kuzatuvi. `setInterval` YO'Q. Map<courier_id, position> da saqlanadi |
| `RouteMap` | Bir kuryer marshruti (assigned/on_route to'xtashlar) sodda ro'yxat ko'rinishida |
| `DeliveryStatusBoard` | Holat dashboard'i — har status uchun count, jami faol, kunlik tushum |

---

## Real-time event arxitekturasi

Push orqali — POLLING YO'Q. Backend (WebSocketEventTransport, Bosqich 4'da) event'larni `Events.emit`'ga uzatadi.

| Event | Push qiluvchi | Subscribers |
|---|---|---|
| `table.status_changed` | TableMap action, banket assign | TableMap, HallStatusBoard |
| `reservation.created` | Customer-side telegram bot | InboxList (Bosqich 4 adapter) |
| `reservation.status_changed` | Operator action | ReservationCard |
| `appointment.created` | Telegram bot | CalendarView |
| `appointment.status_changed` | Operator action | CalendarView |
| `brief.stage_changed` | StageAdvancer, sendProposal | TechBriefViewer |
| `courier.location_updated` | Telegram bot (kuryer client) | LiveTracker, CourierList |
| `courier.status_changed` | Operator/auto | CourierList, LiveTracker |
| `delivery.assigned` | CourierAssigner | DeliveryStatusBoard |

### LiveTracker idempotency

`courier.location_updated` event'i tez-tez kelishi mumkin va WebSocket reconnect'da takrorlanishi mumkin. LiveTracker:
- `seenEventIds = new Set()` — har event id bir marta qabul qilinadi
- Yangi pozitsiya `new Map(positions.value)` orqali set qilinadi (Vue reactivity)
- Komponent unmount'da `useEvents()` auto-cleanup qiladi

---

## Service layer kengaytirish

`Services.*` ostida 4 ta yangi oila ([core/services.js](src/core/services.js)):

```
Services.restaurant.*
  listTables, setTableStatus,
  listReservations, updateReservationStatus,
  listBanquets, createBanquet, updateBanquet, deleteBanquet

Services.appointment.*
  listServices, createService, updateService, deleteService,
  listSpecialists, createSpecialist, updateSpecialist, deleteSpecialist,
  listAppointments, updateAppointmentStatus,
  listWalkIn, addWalkIn, removeWalkIn

Services.production.*
  listBriefs, getBrief, advanceStage, sendProposal,
  listDispatches, createDispatch, updateDispatchStatus

Services.courier.*
  listCouriers, setCourierStatus,
  listDeliveries, assignDelivery
```

Hech bir komponent endpoint URL'ni bilmaydi.

---

## Labels kengaytirish

4 ta yangi status oilasi `Labels`'ga qo'shildi:

```
TABLE_STATUS        — free, reserved, occupied, cleaning           (4 ta)
APPOINTMENT_STATUS  — scheduled, in_progress, completed,
                      cancelled, no_show                            (5 ta)
PRODUCTION_STAGE    — brief_review, proposal_sent, approved,
                      design, production, finishing, delivery,
                      completed, cancelled                          (9 ta)
COURIER_STATUS      — available, on_route, busy, offline           (4 ta)
```

`formatStatus(key, kind)` va `listStatuses(kind)` barcha yangi turlarni qo'llab-quvvatlaydi.

---

## Transition jadval (mock backend ham, UI ham bilshadi)

**Reservation:**
```
requested → confirmed, cancelled
confirmed → seated, no_show, cancelled
seated    → completed
```

**Appointment:**
```
scheduled   → in_progress, cancelled, no_show
in_progress → completed, cancelled
```

**Production stage:**
```
brief_review  → proposal_sent, cancelled
proposal_sent → approved, cancelled
approved      → design
design        → production, cancelled
production    → finishing
finishing     → delivery
delivery      → completed
```

Noto'g'ri transition → 409. Mock backend ham, real backend ham bir xil jadvalga rioya qiladi.

---

## Dev helper'lar

URL parametrlari (Bosqich 1 dan davom) bilan birga:

```js
window.__mockNewReservation()             // Bosqich 3.A — yangi bron event
window.__mockCourierLocation(id, lat, lng) // Bosqich 3.D — pozitsiya yangilash
```

Mock holat (faqat o'qish uchun):
```js
window.__mockRestaurantState    // { tables, reservations, banquets, halls }
window.__mockAppointmentState   // { services, specialists, appointments, walkIn }
window.__mockProductionState    // { briefs, dispatches }
window.__mockCourierState       // { couriers, deliveries }
```

---

## Test natijasi

```
test_bosqich_1.js        → 152 PASS / 0 FAIL  (Bosqich 1, 1.5, 1.6)
test_bosqich_2_1.js      →  47 PASS / 0 FAIL  (Inbox bloki)
test_bosqich_2_rest.js   →  95 PASS / 0 FAIL  (Katalog, mijoz, hisobot, audit, supplier)
test_bosqich_3.js        → 100 PASS / 0 FAIL  (Restaurant, appointment, production, courier)
─────────────────────────────────────────────
JAMI:                       394 PASS / 0 FAIL
```

`test_bosqich_3.js` qamrov:

**3.A Restaurant (~22):** listTables (zal+stol), setTableStatus (valid/422/404), real-time event push, reservations pagination/filter/transition, banquet CRUD (422 name), `__mockNewReservation`.

**3.B Appointment (~22):** services CRUD, specialists CRUD (422 first_name), appointments filter/transition (409 noto'g'ri), walk-in CRUD (422 customer_name).

**3.C Production (~20):** briefs pagination/filter, getBrief (404), stage advance (valid/409), sendProposal (brief_review only/422 price/409 boshqa stage), real-time stage_changed event, dispatches CRUD (422 brief_id).

**3.D Courier (~18):** couriers list/filter, setCourierStatus (422), deliveries pagination/filter, assignDelivery (404 kuryer/409 oflayn), real-time delivery.assigned va courier.location_updated event'lar.

**Static (~13):** mocks va komponentlarda setInterval YO'Q, fetch() YO'Q, v-html YO'Q. LiveTracker idempotency (seenEventIds Set). Labels yangi statuslari.

**Komponent registratsiyasi (~17):** 18 ta komponent + 3 ta extension global registr.

---

## Loyiha statistikasi

| Metr | Bosqich 2 oxiri | Bosqich 3 oxiri |
|---|---:|---:|
| Komponentlar | 31 | **49** |
| Mock fayllar | 10 | **14** |
| Service resurslar | 12 | **16** |
| Status oilalari (Labels) | 5 | **9** |
| Test soni | 294 | **394** |
| dist/index.html (dev) | ~435 KB | ~565 KB |
| dist/index.html (prod) | ~415 KB | ~545 KB |

---

## Bosqich 4 ga qoldirilgan ish

Universal kutubxona endi 4 ta biznes turi uchun tayyor. Bosqich 4'da:

1. **7 ta adapter** (`src/business/<biz>/adapter.js`):
   - `shop/adapter.js` — kengaytirish (mavjud)
   - `fastfood/adapter.js` — shop ga yaqin
   - `supplier/adapter.js` — Balance va Tier komponentlari ishlatadi
   - `restaurant/adapter.js` — TableMap, ReservationCard, BanquetManager, HallStatusBoard
   - `appointment/adapter.js` — CalendarView, ServiceCRUD, SpecialistCRUD, WalkInQueue
   - `production/adapter.js` — TechBriefViewer, OnSiteDispatch
   - `courier/adapter.js` — CourierList, CourierAssigner, LiveTracker, RouteMap, DeliveryStatusBoard

2. **WebSocketEventTransport** to'liq amalga oshirish — `Events.emit` orqali frontend'ga event'lar uzatish.

3. **Routes va component_configs** har biznes turi uchun + `enabled_components`, `terms` override'lar.

Adapter'lar sof deklarativ bo'lganligi sababli — function YO'Q, faqat config — bu eng tez bosqich.
