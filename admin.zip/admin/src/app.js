/**
 * app.js — boot fayli (eng oxirgi yuklanadigan).
 *
 * Yadro init → Vue ilova yaratish → RootShell mount.
 * RootShell qolgan oqimni boshqaradi (auth, PIN, lock, route).
 */
(function () {
  'use strict';

  function boot() {
    const Vue = window.Vue;
    if (!Vue) {
      const el = document.getElementById('app');
      if (el) el.textContent = 'Vue yuklanmadi.';
      return;
    }

    const Core = window.Adminbot.Core;
    const Comps = window.Adminbot.Components;

    // 1. Yadro init
    Core.Startup.init();   // URL params (allowlist) — BIRINCHI
    Core.Theme.init();
    Core.Router.init();
    Core.Pin.init();
    Core.Events.init();

    // 2. Vue app
    const RootShell = Comps.RootShell;
    if (!RootShell) {
      console.error('RootShell topilmadi');
      return;
    }

    // RootShell template'i $options.AuthGate, $options.LockScreen kabilarga
    // tayanadi — quyidagi options ni qo'shamiz:
    RootShell.AuthGate = Comps.AuthGate;
    RootShell.PinGate = Comps.PinGate;
    RootShell.LockScreen = Comps.LockScreen;
    RootShell.BottomNav = Comps.BottomNav;

    const app = Vue.createApp(RootShell);

    // Barcha komponentlarni global qilib register qilamiz —
    // template ichida ham nomi bilan ishlatish mumkin
    for (const name of Object.keys(Comps)) {
      app.component(name, Comps[name]);
    }

    // Telegram WebApp ready signali (mavjud bo'lsa)
    try {
      const tg = window.Telegram && window.Telegram.WebApp;
      if (tg && typeof tg.ready === 'function') {
        tg.ready();
        if (typeof tg.expand === 'function') tg.expand();
      }
    } catch (e) {}

    app.mount('#app');
    window.Adminbot.Runtime.app = app;
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
