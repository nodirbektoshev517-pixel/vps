/**
 * mocks/auth.js — auth endpoint mock handler'lari.
 *
 * Mock PIN: "1234" (test uchun).
 * Bu kod faqat mock mode'da ishlaydi. Real mode'da bu fayl yuklansa
 * ham, mocks register'i to'ldiriladi xolos — Api.request'da
 * isMockMode === false bo'lsa, mocks chaqirilmaydi.
 */
(function () {
  'use strict';
  if (!window.Adminbot || !window.Adminbot.Mocks) return;
  const M = window.Adminbot.Mocks;

  // Mock holat — qaysi tenant uchun PIN o'rnatilgan?
  const _state = {
    pin: '1234',            // sukut bo'yicha mock PIN
    pinAttemptsLeft: 5,
    locked: false,
  };

  M.register('POST', '/adminbot/auth/telegram', async (body) => {
    if (!body || !body.init_data) {
      const e = new Error('init_data majburiy');
      e.status = 400;
      throw e;
    }
    return {
      token: 'mock_jwt_' + Math.random().toString(36).slice(2),
      user: {
        id: 'usr_demo',
        telegram_id: 123456789,
        first_name: 'Demo',
        last_name: 'Owner',
        username: 'demo_owner',
        role: 'owner',
      },
      tenant_id: 'demo_tenant',
      business_type: 'shop',
      permissions: ['*'],
      expires_at: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
    };
  });

  M.register('POST', '/adminbot/auth/pin/verify', async (body) => {
    if (_state.locked) {
      const e = new Error('Xavfsizlik holati');
      e.status = 423;
      throw e;
    }
    if (!body || !body.pin) {
      return { ok: false, error: 'PIN talab qilinadi' };
    }
    if (body.pin === _state.pin) {
      _state.pinAttemptsLeft = 5;
      return {
        ok: true,
        session: {
          token: 'mock_pin_session_' + Date.now(),
          expires_at: new Date(Date.now() + 60 * 60 * 1000).toISOString(),
        },
      };
    }
    _state.pinAttemptsLeft = Math.max(0, _state.pinAttemptsLeft - 1);
    if (_state.pinAttemptsLeft <= 0) {
      _state.locked = true;
      const e = new Error('Juda ko\'p urinish — bloklandi');
      e.status = 423;
      throw e;
    }
    return { ok: false, attempts_left: _state.pinAttemptsLeft };
  });

  M.register('POST', '/adminbot/auth/pin/set', async (body) => {
    if (!body || !body.pin || body.pin.length < 4) {
      const e = new Error('PIN kamida 4 raqamdan iborat bo\'lishi kerak');
      e.status = 422;
      throw e;
    }
    _state.pin = body.pin;
    _state.pinAttemptsLeft = 5;
    _state.locked = false;
    return { ok: true, session: { token: 'mock_pin_session_' + Date.now() } };
  });

  M.register('POST', '/adminbot/auth/pin/remove', async (body) => {
    if (!body || body.pin !== _state.pin) {
      const e = new Error('Joriy PIN noto\'g\'ri');
      e.status = 403;
      throw e;
    }
    _state.pin = null;
    return { ok: true };
  });

  M.register('POST', '/adminbot/auth/lock', async () => ({ ok: true }));
  M.register('POST', '/adminbot/auth/logout', async () => ({ ok: true }));

  // Test uchun mock holatga kirish (test fayllari ishlatadi)
  window.__mockAuthState = _state;
})();
