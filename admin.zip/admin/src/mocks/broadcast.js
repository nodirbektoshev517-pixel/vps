/**
 * mocks/broadcast.js — Broadcast yuborish + audit log.
 */
(function () {
  'use strict';
  if (!window.Adminbot || !window.Adminbot.Mocks) return;
  const M = window.Adminbot.Mocks;
  const { Utils } = window.Adminbot.Core;

  const _audit = [];
  function addAudit(type, actor, summary) {
    _audit.unshift({
      id: `audit_${Utils.uuid().slice(0, 8)}`,
      type,
      actor_id: actor.id || 'usr_demo',
      actor_name: actor.name || 'Demo Admin',
      summary,
      created_at: new Date().toISOString(),
    });
  }
  // Boshlang'ich audit
  const initialEvents = [
    ['order.status_changed', 'Buyurtma #1024 → "qabul qilindi"'],
    ['product.created',      'Yangi mahsulot qo\'shildi: Cappuccino'],
    ['staff.created',        'Yangi xodim qo\'shildi: Madina Yusupova'],
    ['broadcast.sent',       'Mijozlarga xabar yuborildi (412 ta)'],
    ['order.cancelled',      'Buyurtma #1019 bekor qilindi'],
    ['product.updated',      'Mahsulot narxi yangilandi: Latte'],
    ['category.deleted',     'Kategoriya o\'chirildi: Eski'],
    ['settings.changed',     'Notification sozlamasi yangilandi'],
    ['order.status_changed', 'Buyurtma #1018 → "yetkazildi"'],
    ['login.success',        'Tizimga kirish'],
  ];
  initialEvents.forEach((ev, i) => {
    _audit.push({
      id: `audit_init_${i}`,
      type: ev[0],
      actor_id: 'usr_demo',
      actor_name: 'Demo Admin',
      summary: ev[1],
      created_at: new Date(Date.now() - i * 3600000 * 2).toISOString(),
    });
  });

  M.register('POST', '/adminbot/:tenant_id/broadcast', async (body) => {
    if (!body || !body.message || body.message.length < 5) {
      const e = new Error('Xabar matni juda qisqa (min 5 belgi)');
      e.status = 422; throw e;
    }
    if (body.message.length > 500) {
      const e = new Error('Xabar juda uzun (max 500 belgi)');
      e.status = 422; throw e;
    }
    const recipients = body.audience === 'all' ? 412 :
                       body.audience === 'active' ? 234 : 0;
    addAudit('broadcast.sent', { id: 'usr_demo', name: 'Demo Admin' },
      `Mijozlarga xabar yuborildi (${recipients} ta): "${body.message.slice(0, 50)}..."`);
    return {
      ok: true,
      sent_to: recipients,
      sent_at: new Date().toISOString(),
    };
  });

  M.register('GET', '/adminbot/:tenant_id/audit', async (_body, opts) => {
    const url = (opts && opts.url) || '';
    const q = new URLSearchParams(url.split('?')[1] || '');
    const type = q.get('type');
    const cursor = q.get('cursor');
    const pageSize = Math.min(50, parseInt(q.get('page_size') || '20', 10));

    let filtered = _audit;
    if (type && type !== 'all') filtered = filtered.filter(a => a.type === type);
    let startIdx = 0;
    if (cursor) {
      const i = filtered.findIndex(a => a.id === cursor);
      if (i >= 0) startIdx = i + 1;
    }
    const items = filtered.slice(startIdx, startIdx + pageSize);
    const nextCursor = (startIdx + pageSize < filtered.length)
      ? items[items.length - 1].id : null;
    return { items, total: filtered.length, next_cursor: nextCursor, has_more: !!nextCursor };
  });
})();
