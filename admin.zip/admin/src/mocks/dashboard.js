/**
 * mocks/dashboard.js — Dashboard statistikalari mock.
 *
 * Universal shakl: { stats: { key: { value, label, delta, format } } }
 * Adapter qaysi kalitlarni ko'rsatishini deklare qiladi
 * (component_configs.Dashboard.stat_cards = ['todays_orders', ...]).
 */
(function () {
  'use strict';
  if (!window.Adminbot || !window.Adminbot.Mocks) return;
  const M = window.Adminbot.Mocks;

  M.register('GET', '/adminbot/:tenant_id/dashboard', async () => {
    return {
      stats: {
        // Umumiy
        todays_orders: { value: 24, label: 'Bugungi buyurtmalar', delta: +12, format: 'count' },
        new_orders: { value: 5, label: 'Yangi buyurtmalar', format: 'count' },
        active_orders: { value: 9, label: 'Faol buyurtmalar', format: 'count' },
        revenue: { value: 4_250_000, label: 'Bugungi tushum', delta: +8, format: 'money' },
        revenue_week: { value: 28_500_000, label: 'Haftalik tushum', delta: +3, format: 'money' },
        revenue_month: { value: 112_000_000, label: 'Oylik tushum', format: 'money' },
        customers: { value: 412, label: 'Mijozlar', delta: +4, format: 'count' },
        new_customers: { value: 8, label: 'Yangi mijozlar', format: 'count' },

        // Restaurant
        todays_reservations: { value: 14, label: 'Bugungi bronlar', format: 'count' },
        occupied_tables: { value: 6, label: 'Band stollar', format: 'count' },

        // Fastfood
        dine_in_orders: { value: 12, label: 'Dine-in', format: 'count' },
        delivery_orders: { value: 7, label: 'Yetkazib berish', format: 'count' },

        // Supplier
        pending_approvals: { value: 3, label: 'Tasdiq kutmoqda', format: 'count' },
        total_debt: { value: 12_000_000, label: 'Umumiy qarz', format: 'money' },

        // Appointment
        todays_appointments: { value: 7, label: 'Bugungi qabullar', format: 'count' },
        no_shows: { value: 1, label: 'Kelmaganlar', format: 'count' },

        // Custom production
        active_projects: { value: 4, label: 'Faol loyihalar', format: 'count' },
        pending_proposals: { value: 2, label: 'Taklif kutmoqda', format: 'count' },

        // Courier
        active_couriers: { value: 5, label: 'Faol kuryerlar', format: 'count' },
        completed_deliveries: { value: 23, label: 'Bugungi yetkazishlar', format: 'count' },
      },
      last_updated_at: new Date().toISOString(),
    };
  });
})();
