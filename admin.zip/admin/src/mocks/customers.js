/**
 * mocks/customers.js — Mijozlar va ular buyurtmalari tarixi.
 */
(function () {
  'use strict';
  if (!window.Adminbot || !window.Adminbot.Mocks) return;
  const M = window.Adminbot.Mocks;

  const _customers = [];
  const names = [
    ['Ali', 'Karimov'], ['Dilshod', 'Tursunov'], ['Madina', 'Yusupova'],
    ['Bekzod', 'Saidov'], ['Zarina', 'Olimova'], ['Jamshid', 'Yusupov'],
    ['Nodira', 'Kamalova'], ['Rustam', 'Ahmedov'], ['Aziza', 'Rahmonova'],
    ['Sardor', 'Toshmatov'], ['Iroda', 'Mamatova'], ['Otabek', 'Nazarov'],
  ];
  for (let i = 0; i < names.length; i++) {
    _customers.push({
      id: `cust_${i + 1}`,
      first_name: names[i][0],
      last_name: names[i][1],
      phone: `+99890${1000000 + i * 12345}`,
      orders_count: (i * 3) % 14 + 1,
      total_spent: (i + 1) * 250_000 + (i * 17_000),
      last_order_at: new Date(Date.now() - i * 86400000 * 2).toISOString(),
      created_at: new Date(Date.now() - i * 86400000 * 30).toISOString(),
    });
  }

  M.register('GET', '/adminbot/:tenant_id/customers', async (_body, opts) => {
    const url = (opts && opts.url) || '';
    const q = new URLSearchParams(url.split('?')[1] || '');
    const search = (q.get('q') || '').toLowerCase();
    const cursor = q.get('cursor');
    const pageSize = Math.min(50, parseInt(q.get('page_size') || '20', 10));

    let filtered = _customers;
    if (search) {
      filtered = filtered.filter(c =>
        c.first_name.toLowerCase().includes(search) ||
        c.last_name.toLowerCase().includes(search) ||
        c.phone.includes(search)
      );
    }
    let startIdx = 0;
    if (cursor) {
      const i = filtered.findIndex(c => c.id === cursor);
      if (i >= 0) startIdx = i + 1;
    }
    const items = filtered.slice(startIdx, startIdx + pageSize);
    const nextCursor = (startIdx + pageSize < filtered.length)
      ? items[items.length - 1].id : null;
    return { items, total: filtered.length, next_cursor: nextCursor, has_more: !!nextCursor };
  });

  M.register('GET', '/adminbot/:tenant_id/customers/:id', async (_b, _o, params) => {
    const id = params && params[1];
    const c = _customers.find(x => x.id === id);
    if (!c) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
    // orders_history mock
    const orders = [];
    for (let i = 0; i < Math.min(c.orders_count, 5); i++) {
      orders.push({
        id: `ord_${c.id}_${i}`,
        number: 5000 + i * 7,
        status: ['delivered', 'cancelled', 'delivered', 'delivered'][i % 4],
        total: 80_000 + i * 35_000,
        created_at: new Date(Date.now() - i * 86400000 * 3).toISOString(),
      });
    }
    return { ...c, orders_history: orders };
  });

  window.__mockCustomersState = _customers;
})();
