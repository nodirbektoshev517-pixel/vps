/**
 * mocks/reports.js — Hisobotlar.
 */
(function () {
  'use strict';
  if (!window.Adminbot || !window.Adminbot.Mocks) return;
  const M = window.Adminbot.Mocks;

  M.register('GET', '/adminbot/:tenant_id/reports/:key', async (_b, _o, params) => {
    const key = params && params[1];
    const reports = {
      daily_sales: {
        key: 'daily_sales',
        title: 'Kunlik tushum',
        period: 'Oxirgi 7 kun',
        rows: [
          { label: 'Dushanba',  value: 1_250_000 },
          { label: 'Seshanba',  value: 1_450_000 },
          { label: 'Chorshanba', value: 1_100_000 },
          { label: 'Payshanba', value: 1_850_000 },
          { label: 'Juma',      value: 2_300_000 },
          { label: 'Shanba',    value: 2_750_000 },
          { label: 'Yakshanba', value: 1_950_000 },
        ],
        total: 12_650_000,
        format: 'money',
      },
      top_products: {
        key: 'top_products',
        title: 'Eng ko\'p sotilgan',
        period: 'Bu hafta',
        rows: [
          { label: 'Cappuccino',    value: 142 },
          { label: 'Latte',          value: 118 },
          { label: 'Americano',      value: 96 },
          { label: 'Mocha',          value: 73 },
          { label: 'Espresso',       value: 54 },
        ],
        total: 483,
        format: 'count',
      },
      customer_summary: {
        key: 'customer_summary',
        title: 'Mijozlar xulosasi',
        period: 'Bu oy',
        rows: [
          { label: 'Yangi mijozlar',    value: 28 },
          { label: 'Qaytuvchi mijozlar', value: 156 },
          { label: 'Faol mijozlar',      value: 412 },
          { label: 'O\'rta chek',        value: 145_000, format: 'money' },
        ],
        format: 'mixed',
      },
    };
    const r = reports[key];
    if (!r) { const e = new Error('Hisobot topilmadi'); e.status = 404; throw e; }
    return r;
  });
})();
