/**
 * mocks/catalog.js — Kategoriyalar va mahsulotlar.
 */
(function () {
  'use strict';
  if (!window.Adminbot || !window.Adminbot.Mocks) return;
  const M = window.Adminbot.Mocks;
  const { Utils } = window.Adminbot.Core;

  const _categories = [
    { id: 'cat_1', name: 'Issiq ichimliklar', icon: '☕', products_count: 8 },
    { id: 'cat_2', name: 'Salqin ichimliklar', icon: '🥤', products_count: 6 },
    { id: 'cat_3', name: 'Deserlar', icon: '🍰', products_count: 5 },
    { id: 'cat_4', name: 'Salatlar', icon: '🥗', products_count: 4 },
  ];

  const _products = [];
  function buildProducts() {
    const names = {
      cat_1: ['Espresso', 'Americano', 'Cappuccino', 'Latte', 'Mocha', 'Flat White', 'Macchiato', 'Raf'],
      cat_2: ['Limonad', 'Mojito', 'Smuzi', 'Kompot', 'Coca-Cola', 'Sok'],
      cat_3: ['Tiramisu', 'Cheesecake', 'Brownie', 'Pancake', 'Yogurt'],
      cat_4: ['Sezar', 'Yunon', 'Greek', 'Kapris'],
    };
    let id = 1;
    for (const cat of _categories) {
      for (const n of names[cat.id] || []) {
        _products.push({
          id: `prod_${id++}`,
          category_id: cat.id,
          name: n,
          price: 15_000 + (id % 6) * 5_000,
          status: id % 7 === 0 ? 'out_of_stock' : 'active',
          image_url: null,
          variants: [],
          addons: [],
          created_at: new Date(Date.now() - id * 86400000).toISOString(),
        });
      }
    }
  }
  buildProducts();

  // === Categories ===
  M.register('GET', '/adminbot/:tenant_id/catalog/categories', async () => ({
    items: _categories, total: _categories.length,
  }));

  M.register('POST', '/adminbot/:tenant_id/catalog/categories', async (body) => {
    if (!body || !body.name) {
      const e = new Error('name majburiy'); e.status = 422; throw e;
    }
    const c = {
      id: `cat_${Utils.uuid().slice(0, 6)}`,
      name: body.name, icon: body.icon || '📦', products_count: 0,
    };
    _categories.push(c);
    return c;
  });

  M.register('PATCH', '/adminbot/:tenant_id/catalog/categories/:id', async (body, _opts, params) => {
    const id = params && params[1];
    const idx = _categories.findIndex(c => c.id === id);
    if (idx < 0) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
    _categories[idx] = { ..._categories[idx], ...body, id };
    return _categories[idx];
  });

  M.register('DELETE', '/adminbot/:tenant_id/catalog/categories/:id', async (_b, _o, params) => {
    const id = params && params[1];
    const idx = _categories.findIndex(c => c.id === id);
    if (idx < 0) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
    if (_categories[idx].products_count > 0) {
      const e = new Error('Kategoriyada mahsulot bor — avval ularni o\'chiring');
      e.status = 409; throw e;
    }
    _categories.splice(idx, 1);
    return null;
  });

  // === Products ===
  M.register('GET', '/adminbot/:tenant_id/catalog/products', async (_body, opts) => {
    const url = (opts && opts.url) || '';
    const q = new URLSearchParams(url.split('?')[1] || '');
    const categoryId = q.get('category_id');
    const cursor = q.get('cursor');
    const pageSize = Math.min(50, parseInt(q.get('page_size') || '20', 10));

    let filtered = _products;
    if (categoryId) filtered = filtered.filter(p => p.category_id === categoryId);
    let startIdx = 0;
    if (cursor) {
      const i = filtered.findIndex(p => p.id === cursor);
      if (i >= 0) startIdx = i + 1;
    }
    const items = filtered.slice(startIdx, startIdx + pageSize);
    const nextCursor = (startIdx + pageSize < filtered.length)
      ? items[items.length - 1].id : null;
    return { items, total: filtered.length, next_cursor: nextCursor, has_more: !!nextCursor };
  });

  M.register('POST', '/adminbot/:tenant_id/catalog/products', async (body) => {
    if (!body || !body.name) { const e = new Error('name majburiy'); e.status = 422; throw e; }
    if (!body.category_id) { const e = new Error('category_id majburiy'); e.status = 422; throw e; }
    const p = {
      id: `prod_${Utils.uuid().slice(0, 6)}`,
      category_id: body.category_id,
      name: body.name,
      price: parseInt(body.price, 10) || 0,
      status: body.status || 'active',
      image_url: body.image_url || null,
      variants: body.variants || [],
      addons: body.addons || [],
      created_at: new Date().toISOString(),
    };
    _products.push(p);
    const cat = _categories.find(c => c.id === p.category_id);
    if (cat) cat.products_count++;
    return p;
  });

  M.register('PATCH', '/adminbot/:tenant_id/catalog/products/:id', async (body, _o, params) => {
    const id = params && params[1];
    const idx = _products.findIndex(p => p.id === id);
    if (idx < 0) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
    _products[idx] = { ..._products[idx], ...body, id };
    return _products[idx];
  });

  M.register('DELETE', '/adminbot/:tenant_id/catalog/products/:id', async (_b, _o, params) => {
    const id = params && params[1];
    const idx = _products.findIndex(p => p.id === id);
    if (idx < 0) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
    const cat = _categories.find(c => c.id === _products[idx].category_id);
    if (cat) cat.products_count = Math.max(0, cat.products_count - 1);
    _products.splice(idx, 1);
    return null;
  });

  // === Image upload (mock — faqat data URL qaytaradi) ===
  M.register('POST', '/adminbot/:tenant_id/catalog/upload', async (body) => {
    if (!body || !body.data_url) { const e = new Error('data_url majburiy'); e.status = 422; throw e; }
    return {
      url: body.data_url,   // mock'da to'g'ridan-to'g'ri qaytaramiz
      uploaded_at: new Date().toISOString(),
    };
  });

  window.__mockCatalogState = { categories: _categories, products: _products };
})();
