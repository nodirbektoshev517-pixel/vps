/**
 * mocks/bootstrap.js — bootstrap javobi.
 *
 * GET /adminbot/{tenant_id}/bootstrap → kim, qaysi tenant, qaysi biznes,
 *   PIN holati, permissions, feature flags
 *
 * URL'dagi tenant_id faqat hint. Bu mock'da uni qaytaramiz xolos.
 * Real backend o'z auth bilan tasdiqlaydi.
 *
 * URL parametrlari bilan sozlash mumkin (test/dev):
 *   ?biz=shop|fastfood|restaurant|supplier|appointment_service|custom_production|courier_service
 *   ?role=owner|manager|staff
 *   ?pin=on|off       (PIN o'rnatilganmi)
 *   ?pin_locked=on    (boshlanish holati lock'da)
 */
(function () {
  'use strict';
  if (!window.Adminbot || !window.Adminbot.Mocks) return;
  const M = window.Adminbot.Mocks;
  const { Utils } = window.Adminbot.Core;

  function permissionsFor(role) {
    if (role === 'owner') return ['*'];
    if (role === 'manager') {
      return [
        'dashboard.view', 'orders.view', 'orders.update',
        'staff.view', 'customers.view', 'reports.view',
        'broadcast.send', 'catalog.*',
      ];
    }
    // staff (default)
    return [
      'dashboard.view', 'orders.view', 'orders.update',
      'customers.view',
    ];
  }

  // Bir handler — ikkita path:
  //   /adminbot/:tenant_id/bootstrap — "yangi" konvensiya (kelajakdagi target)
  //   /admin/bootstrap               — services.js hozir shu yo'lni chaqiradi
  //                                    (admin_panel.py mavjud backend bilan mos)
  async function bootstrapHandler(_body, _opts, params) {
    const { Startup, Auth } = window.Adminbot.Core;
    const tenantHint = (params && params[0])
      || (Auth && Auth.getSession().tenant_id)
      || 'demo_tenant';
    const biz = (Startup && Startup.get('biz')) || 'shop';
    const role = (Startup && Startup.get('role')) || 'owner';
    const pinOn = !!(Startup && Startup.get('pin'));
    const pinLocked = !!(Startup && Startup.get('pin_locked'));

    return {
      tenant: {
        id: tenantHint,
        name: 'Demo biznes',
        business_type: biz,
        status: 'active',
        created_at: '2025-01-15T10:00:00Z',
      },
      // Backend "me", mock'da ham ikkala kalit beramiz — auth.js
      // ikkalasini ham qabul qiladi (forward-compat).
      me: {
        id: 'usr_demo',
        telegram_id: 123456789,
        first_name: 'Demo',
        last_name: 'Admin',
        username: 'demo_admin',
        role: role,
        permissions: permissionsFor(role),
        avatar_url: null,
      },
      user: {
        id: 'usr_demo',
        telegram_id: 123456789,
        first_name: 'Demo',
        last_name: 'Admin',
        username: 'demo_admin',
        role: role,
        permissions: permissionsFor(role),
        avatar_url: null,
      },
      pin: {
        required: pinOn,
        locked: pinOn && pinLocked,
        timeout_min: 5,
      },
      notifications: { unread_count: 0, last_event_id: null },
      feature_flags: { broadcast_enabled: true, reports_enabled: true },
    };
  }

  M.register('GET', '/adminbot/:tenant_id/bootstrap', bootstrapHandler);
  M.register('GET', '/admin/bootstrap', bootstrapHandler);
})();
