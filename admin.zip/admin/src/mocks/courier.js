/**
 * mocks/courier.js — Courier biznes turi uchun mock'lar (Bosqich 3.D).
 *
 * Resurslar: couriers, deliveries (yetkazib berishlar).
 * Real-time: courier.location_updated, courier.status_changed, delivery.assigned.
 *
 * LiveTracker komponent shu event'lardan foydalanadi — POLLING YO'Q.
 */
(function () {
  'use strict';
  if (!window.Adminbot || !window.Adminbot.Mocks) return;
  const M = window.Adminbot.Mocks;
  const { Utils } = window.Adminbot.Core;

  // === Kuryerlar ===
  const _couriers = [
    { id: 'crr_1', first_name: 'Akmal',  last_name: 'Karimov',  phone: '+998901111111', vehicle: 'Moto',  status: 'available', current_lat: 41.31, current_lng: 69.28, last_seen_at: new Date().toISOString(), today_deliveries: 4 },
    { id: 'crr_2', first_name: 'Bahodir', last_name: 'Yusupov',  phone: '+998902222222', vehicle: 'Bike', status: 'on_route',  current_lat: 41.32, current_lng: 69.27, last_seen_at: new Date().toISOString(), today_deliveries: 6 },
    { id: 'crr_3', first_name: 'Diyor',   last_name: 'Toshmatov', phone: '+998903333333', vehicle: 'Car',  status: 'busy',     current_lat: 41.30, current_lng: 69.29, last_seen_at: new Date().toISOString(), today_deliveries: 3 },
    { id: 'crr_4', first_name: 'Sardor',  last_name: 'Olimov',    phone: '+998904444444', vehicle: 'Moto', status: 'offline', current_lat: null, current_lng: null, last_seen_at: new Date(Date.now() - 3600000).toISOString(), today_deliveries: 2 },
    { id: 'crr_5', first_name: 'Otabek',  last_name: 'Nazarov',   phone: '+998905555555', vehicle: 'Moto', status: 'available',current_lat: 41.33, current_lng: 69.26, last_seen_at: new Date().toISOString(), today_deliveries: 5 },
  ];

  M.register('GET', '/adminbot/:tenant_id/courier/couriers', async (_b, opts) => {
    const url = (opts && opts.url) || '';
    const q = new URLSearchParams(url.split('?')[1] || '');
    const status = q.get('status');
    let filtered = _couriers;
    if (status && status !== 'all') filtered = filtered.filter(c => c.status === status);
    return { items: filtered, total: filtered.length };
  });

  M.register('PATCH', '/adminbot/:tenant_id/courier/couriers/:id/status', async (body, _o, params) => {
    const id = params && params[1];
    const c = _couriers.find(x => x.id === id);
    if (!c) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
    if (!['available', 'on_route', 'busy', 'offline'].includes(body && body.status)) {
      const e = new Error('Noto\'g\'ri status'); e.status = 422; throw e;
    }
    c.status = body.status;
    return c;
  });

  // === Yetkazib berishlar (deliveries) ===
  const _deliveries = [];
  for (let i = 1; i <= 14; i++) {
    _deliveries.push({
      id: `dlv_${i}`,
      order_id: `ord_external_${i}`,
      order_number: 5000 + i,
      customer_name: ['Ali K.', 'Madina Y.', 'Bekzod S.', 'Sevara M.'][i % 4],
      pickup_address: 'Do\'kon, Toshkent',
      delivery_address: `Toshkent, ${['Chilonzor', 'Yunusobod', 'Mirobod', 'Sergeli'][i % 4]} ${i + 10}-${i + 5}`,
      delivery_lat: 41.30 + (i % 5) * 0.01,
      delivery_lng: 69.27 + (i % 5) * 0.01,
      courier_id: i % 4 === 0 ? null : `crr_${(i % 5) + 1}`,
      status: i % 4 === 0 ? 'pending_assignment' : (['assigned', 'on_route', 'delivered', 'assigned'][i % 4]),
      total: 80_000 + i * 25_000,
      created_at: new Date(Date.now() - i * 3600000).toISOString(),
      assigned_at: i % 4 === 0 ? null : new Date(Date.now() - i * 1800000).toISOString(),
    });
  }
  _deliveries.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

  M.register('GET', '/adminbot/:tenant_id/courier/deliveries', async (_b, opts) => {
    const url = (opts && opts.url) || '';
    const q = new URLSearchParams(url.split('?')[1] || '');
    const status = q.get('status');
    const cursor = q.get('cursor');
    const pageSize = Math.min(50, parseInt(q.get('page_size') || '20', 10));
    let filtered = _deliveries;
    if (status && status !== 'all') filtered = filtered.filter(d => d.status === status);
    let startIdx = 0;
    if (cursor) {
      const i = filtered.findIndex(d => d.id === cursor);
      if (i >= 0) startIdx = i + 1;
    }
    const items = filtered.slice(startIdx, startIdx + pageSize);
    const nextCursor = (startIdx + pageSize < filtered.length)
      ? items[items.length - 1].id : null;
    return { items, total: filtered.length, next_cursor: nextCursor, has_more: !!nextCursor };
  });

  M.register('POST', '/adminbot/:tenant_id/courier/deliveries/:id/assign',
    async (body, _o, params) => {
      const id = params && params[1];
      const d = _deliveries.find(x => x.id === id);
      if (!d) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
      const courierId = body && body.courier_id;
      const c = _couriers.find(x => x.id === courierId);
      if (!c) { const e = new Error('Kuryer topilmadi'); e.status = 404; throw e; }
      if (c.status === 'offline') {
        const e = new Error('Oflayn kuryerga tayinlab bo\'lmaydi'); e.status = 409; throw e;
      }
      d.courier_id = courierId;
      d.status = 'assigned';
      d.assigned_at = new Date().toISOString();
      c.status = 'on_route';
      // Event push
      setTimeout(() => {
        if (typeof window.__mockPushEvent === 'function') {
          window.__mockPushEvent({
            id: `evt_${Utils.uuid().slice(0, 8)}`,
            type: 'delivery.assigned',
            entity_id: d.id,
            payload: { id: d.id, courier_id: courierId, status: d.status },
            created_at: new Date().toISOString(),
          });
        }
      }, 30);
      return d;
    });

  // Dev helper: kuryer lokatsiyasini "yangilash"
  // (real app'da bu Telegram bot orqali kuryerdan keladi, polling YO'Q)
  window.__mockCourierLocation = function (courierId, lat, lng) {
    const c = _couriers.find(x => x.id === courierId);
    if (!c) return null;
    c.current_lat = lat;
    c.current_lng = lng;
    c.last_seen_at = new Date().toISOString();
    if (typeof window.__mockPushEvent === 'function') {
      window.__mockPushEvent({
        id: `evt_${Utils.uuid().slice(0, 8)}`,
        type: 'courier.location_updated',
        entity_id: c.id,
        payload: { id: c.id, lat, lng, last_seen_at: c.last_seen_at },
        created_at: new Date().toISOString(),
      });
    }
    return c;
  };

  window.__mockCourierState = { couriers: _couriers, deliveries: _deliveries };
})();
