/**
 * mocks/appointment.js — Appointment biznes turi uchun mock'lar (Bosqich 3.B).
 *
 * Resurslar: services, specialists, appointments, walk_in_queue.
 */
(function () {
  'use strict';
  if (!window.Adminbot || !window.Adminbot.Mocks) return;
  const M = window.Adminbot.Mocks;
  const { Utils } = window.Adminbot.Core;

  // === Xizmatlar ===
  const _services = [
    { id: 'svc_1', name: 'Soch olish (erkak)',    duration_min: 30, price: 60_000,  active: true },
    { id: 'svc_2', name: 'Soch olish (ayol)',      duration_min: 60, price: 150_000, active: true },
    { id: 'svc_3', name: 'Manikyur',                duration_min: 45, price: 100_000, active: true },
    { id: 'svc_4', name: 'Pedikyur',                duration_min: 60, price: 150_000, active: true },
    { id: 'svc_5', name: 'Bo\'yash (oddiy)',        duration_min: 90, price: 250_000, active: true },
  ];

  M.register('GET', '/adminbot/:tenant_id/appointment/services', async () =>
    ({ items: _services, total: _services.length }));

  M.register('POST', '/adminbot/:tenant_id/appointment/services', async (body) => {
    if (!body || !body.name) { const e = new Error('name majburiy'); e.status = 422; throw e; }
    const s = {
      id: `svc_${Utils.uuid().slice(0, 6)}`,
      name: body.name,
      duration_min: parseInt(body.duration_min, 10) || 30,
      price: parseInt(body.price, 10) || 0,
      active: body.active !== false,
    };
    _services.push(s);
    return s;
  });

  M.register('PATCH', '/adminbot/:tenant_id/appointment/services/:id', async (body, _o, params) => {
    const id = params && params[1];
    const idx = _services.findIndex(s => s.id === id);
    if (idx < 0) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
    _services[idx] = { ..._services[idx], ...body, id };
    return _services[idx];
  });

  M.register('DELETE', '/adminbot/:tenant_id/appointment/services/:id', async (_b, _o, params) => {
    const id = params && params[1];
    const idx = _services.findIndex(s => s.id === id);
    if (idx < 0) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
    _services.splice(idx, 1);
    return null;
  });

  // === Mutaxassislar ===
  const _specialists = [
    { id: 'spc_1', first_name: 'Aziz',  last_name: 'Karimov',  services: ['svc_1'],           working_hours: '09:00-18:00', active: true },
    { id: 'spc_2', first_name: 'Lola',  last_name: 'Yusupova', services: ['svc_2', 'svc_5'], working_hours: '10:00-19:00', active: true },
    { id: 'spc_3', first_name: 'Dilfuza', last_name: 'Olimova',services: ['svc_3', 'svc_4'], working_hours: '09:00-17:00', active: true },
  ];

  M.register('GET', '/adminbot/:tenant_id/appointment/specialists', async () =>
    ({ items: _specialists, total: _specialists.length }));

  M.register('POST', '/adminbot/:tenant_id/appointment/specialists', async (body) => {
    if (!body || !body.first_name) { const e = new Error('first_name majburiy'); e.status = 422; throw e; }
    const s = {
      id: `spc_${Utils.uuid().slice(0, 6)}`,
      first_name: body.first_name, last_name: body.last_name || '',
      services: body.services || [],
      working_hours: body.working_hours || '09:00-18:00',
      active: body.active !== false,
    };
    _specialists.push(s);
    return s;
  });

  M.register('PATCH', '/adminbot/:tenant_id/appointment/specialists/:id', async (body, _o, params) => {
    const id = params && params[1];
    const idx = _specialists.findIndex(s => s.id === id);
    if (idx < 0) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
    _specialists[idx] = { ..._specialists[idx], ...body, id };
    return _specialists[idx];
  });

  M.register('DELETE', '/adminbot/:tenant_id/appointment/specialists/:id', async (_b, _o, params) => {
    const id = params && params[1];
    const idx = _specialists.findIndex(s => s.id === id);
    if (idx < 0) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
    _specialists.splice(idx, 1);
    return null;
  });

  // === Uchrashuvlar ===
  const _appointments = [];
  const custNames = ['Bahodir T.', 'Saida Y.', 'Olim K.', 'Madina O.', 'Sherzod A.'];
  for (let i = 1; i <= 14; i++) {
    const start = new Date();
    start.setHours(9 + (i % 9), (i * 15) % 60, 0, 0);
    if (i > 7) start.setDate(start.getDate() + 1);   // ertaga ham
    const svc = _services[i % _services.length];
    _appointments.push({
      id: `apt_${i}`,
      number: 3000 + i,
      customer_name: custNames[i % custNames.length],
      customer_phone: `+99890123${(4000 + i).toString().padStart(4, '0')}`,
      service_id: svc.id,
      service_name: svc.name,
      specialist_id: _specialists[i % _specialists.length].id,
      start_time: start.toISOString(),
      duration_min: svc.duration_min,
      status: ['scheduled', 'in_progress', 'completed', 'cancelled', 'no_show'][i % 5],
      created_at: new Date(Date.now() - i * 86400000).toISOString(),
    });
  }
  _appointments.sort((a, b) => new Date(a.start_time) - new Date(b.start_time));

  const APT_TRANSITIONS = {
    scheduled:   ['in_progress', 'cancelled', 'no_show'],
    in_progress: ['completed', 'cancelled'],
    completed:   [],
    cancelled:   [],
    no_show:     [],
  };

  M.register('GET', '/adminbot/:tenant_id/appointment/appointments', async (_b, opts) => {
    const url = (opts && opts.url) || '';
    const q = new URLSearchParams(url.split('?')[1] || '');
    const status = q.get('status');
    const date = q.get('date');
    const specialistId = q.get('specialist_id');
    let filtered = _appointments;
    if (status && status !== 'all') filtered = filtered.filter(a => a.status === status);
    if (specialistId) filtered = filtered.filter(a => a.specialist_id === specialistId);
    if (date) {
      const target = new Date(date).toDateString();
      filtered = filtered.filter(a => new Date(a.start_time).toDateString() === target);
    }
    return { items: filtered, total: filtered.length };
  });

  M.register('PATCH', '/adminbot/:tenant_id/appointment/appointments/:id/status',
    async (body, _o, params) => {
      const id = params && params[1];
      const a = _appointments.find(x => x.id === id);
      if (!a) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
      const allowed = APT_TRANSITIONS[a.status] || [];
      if (!allowed.includes(body && body.status)) {
        const e = new Error(`Transition ruxsat etilmagan: ${a.status} → ${body.status}`);
        e.status = 409; throw e;
      }
      a.status = body.status;
      return a;
    });

  // === Walk-in queue ===
  const _walkIn = [
    { id: 'wlk_1', customer_name: 'Mehmon-1', service_id: 'svc_1', queued_at: new Date(Date.now() - 600000).toISOString(), estimated_wait_min: 15 },
    { id: 'wlk_2', customer_name: 'Mehmon-2', service_id: 'svc_3', queued_at: new Date(Date.now() - 300000).toISOString(), estimated_wait_min: 25 },
  ];

  M.register('GET', '/adminbot/:tenant_id/appointment/walk-in', async () =>
    ({ items: _walkIn, total: _walkIn.length }));

  M.register('POST', '/adminbot/:tenant_id/appointment/walk-in', async (body) => {
    if (!body || !body.customer_name) { const e = new Error('customer_name majburiy'); e.status = 422; throw e; }
    const w = {
      id: `wlk_${Utils.uuid().slice(0, 6)}`,
      customer_name: body.customer_name,
      service_id: body.service_id || null,
      queued_at: new Date().toISOString(),
      estimated_wait_min: 10 + _walkIn.length * 5,
    };
    _walkIn.push(w);
    return w;
  });

  M.register('DELETE', '/adminbot/:tenant_id/appointment/walk-in/:id', async (_b, _o, params) => {
    const id = params && params[1];
    const idx = _walkIn.findIndex(w => w.id === id);
    if (idx < 0) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
    _walkIn.splice(idx, 1);
    return null;
  });

  window.__mockAppointmentState = { services: _services, specialists: _specialists, appointments: _appointments, walkIn: _walkIn };
})();
