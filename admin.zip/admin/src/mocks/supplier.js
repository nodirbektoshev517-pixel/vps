/**
 * mocks/supplier.js — Supplier biznes turi uchun maxsus mock'lar.
 *
 * BalanceLedger, TierAssigner, CreditLimitManager, InviteCodeGenerator,
 * ShopApprover komponentlari shu endpoint'lardan foydalanadi.
 */
(function () {
  'use strict';
  if (!window.Adminbot || !window.Adminbot.Mocks) return;
  const M = window.Adminbot.Mocks;
  const { Utils } = window.Adminbot.Core;

  // === Balance operations (immutable audit log) ===
  const _operations = [];
  for (let i = 0; i < 18; i++) {
    const isCredit = i % 3 === 0;
    const before = 5_000_000 + (i * 350_000);
    const amount = (i + 1) * 75_000 + (i * 23_000);
    _operations.unshift({
      id: `op_${i + 1}`,
      shop_id: `shop_${(i % 5) + 1}`,
      shop_name: ['Mevali do\'kon', 'Tongni Kut', 'Aroma', 'Cool Drinks', 'Sweet Life'][i % 5],
      actor_id: 'usr_demo',
      actor_name: 'Demo Owner',
      operation_type: isCredit ? 'credit' : 'debit',
      amount,
      reason: isCredit ? 'Yetkazib berish' : 'To\'lov',
      before_balance: before,
      after_balance: isCredit ? before + amount : before - amount,
      created_at: new Date(Date.now() - i * 3600000 * 6).toISOString(),
    });
  }

  M.register('GET', '/adminbot/:tenant_id/supplier/balance', async (_body, opts) => {
    const url = (opts && opts.url) || '';
    const q = new URLSearchParams(url.split('?')[1] || '');
    const shopId = q.get('shop_id');
    const cursor = q.get('cursor');
    const pageSize = Math.min(50, parseInt(q.get('page_size') || '20', 10));

    let filtered = _operations;
    if (shopId) filtered = filtered.filter(o => o.shop_id === shopId);
    let startIdx = 0;
    if (cursor) {
      const i = filtered.findIndex(o => o.id === cursor);
      if (i >= 0) startIdx = i + 1;
    }
    const items = filtered.slice(startIdx, startIdx + pageSize);
    const nextCursor = (startIdx + pageSize < filtered.length)
      ? items[items.length - 1].id : null;
    return { items, total: filtered.length, next_cursor: nextCursor, has_more: !!nextCursor };
  });

  M.register('POST', '/adminbot/:tenant_id/supplier/balance/operation', async (body) => {
    if (!body || !body.shop_id || !body.amount || !body.operation_type) {
      const e = new Error('shop_id, amount, operation_type majburiy');
      e.status = 422; throw e;
    }
    const lastForShop = _operations.find(o => o.shop_id === body.shop_id);
    const before = lastForShop ? lastForShop.after_balance : 0;
    const amount = Math.abs(parseInt(body.amount, 10));
    const after = body.operation_type === 'credit' ? before + amount : before - amount;
    const op = {
      id: `op_${Utils.uuid().slice(0, 8)}`,
      shop_id: body.shop_id,
      shop_name: body.shop_name || body.shop_id,
      actor_id: 'usr_demo',
      actor_name: 'Demo Owner',
      operation_type: body.operation_type,
      amount,
      reason: body.reason || '',
      before_balance: before,
      after_balance: after,
      created_at: new Date().toISOString(),
    };
    _operations.unshift(op);
    return op;
  });

  // === Shops (dukonlar — supplier'ning mijozlari) ===
  const _shops = [
    { id: 'shop_1', name: 'Mevali do\'kon',  tier: 'gold',     credit_limit: 10_000_000, balance: 2_350_000, status: 'active' },
    { id: 'shop_2', name: 'Tongni Kut',     tier: 'silver',   credit_limit: 5_000_000,  balance: 850_000,   status: 'active' },
    { id: 'shop_3', name: 'Aroma',          tier: 'gold',     credit_limit: 8_000_000,  balance: 1_200_000, status: 'active' },
    { id: 'shop_4', name: 'Cool Drinks',    tier: 'bronze',   credit_limit: 2_000_000,  balance: 450_000,   status: 'active' },
    { id: 'shop_5', name: 'Sweet Life',     tier: 'silver',   credit_limit: 5_000_000,  balance: 1_750_000, status: 'active' },
  ];

  M.register('GET', '/adminbot/:tenant_id/supplier/shops', async () => ({
    items: _shops, total: _shops.length,
  }));

  // === Tier assign ===
  M.register('PATCH', '/adminbot/:tenant_id/supplier/shops/:id/tier', async (body, _o, params) => {
    const id = params && params[1];
    const shop = _shops.find(s => s.id === id);
    if (!shop) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
    if (!['bronze', 'silver', 'gold', 'platinum'].includes(body && body.tier)) {
      const e = new Error('Noto\'g\'ri tier'); e.status = 422; throw e;
    }
    shop.tier = body.tier;
    return shop;
  });

  // === Credit limit ===
  M.register('PATCH', '/adminbot/:tenant_id/supplier/shops/:id/credit-limit', async (body, _o, params) => {
    const id = params && params[1];
    const shop = _shops.find(s => s.id === id);
    if (!shop) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
    const lim = parseInt(body && body.credit_limit, 10);
    if (isNaN(lim) || lim < 0) {
      const e = new Error('Noto\'g\'ri credit_limit'); e.status = 422; throw e;
    }
    shop.credit_limit = lim;
    return shop;
  });

  // === Invite codes ===
  const _invites = [];
  M.register('GET', '/adminbot/:tenant_id/supplier/invites', async () => ({
    items: _invites,
  }));

  M.register('POST', '/adminbot/:tenant_id/supplier/invites', async (body) => {
    const code = 'INV-' + Math.random().toString(36).slice(2, 8).toUpperCase();
    const inv = {
      id: `inv_${Utils.uuid().slice(0, 8)}`,
      code,
      tier_preset: (body && body.tier_preset) || 'bronze',
      credit_limit_preset: parseInt(body && body.credit_limit_preset, 10) || 2_000_000,
      created_at: new Date().toISOString(),
      expires_at: new Date(Date.now() + 7 * 86400000).toISOString(),
      used_at: null,
      used_by: null,
    };
    _invites.unshift(inv);
    return inv;
  });

  M.register('DELETE', '/adminbot/:tenant_id/supplier/invites/:id', async (_b, _o, params) => {
    const id = params && params[1];
    const idx = _invites.findIndex(i => i.id === id);
    if (idx < 0) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
    _invites.splice(idx, 1);
    return null;
  });

  // === Pending shops (tasdiqlanmagan ro'yxatlar) ===
  const _pending = [
    { id: 'pend_1', name: 'Yangi do\'kon 1', owner_phone: '+998901112233', invite_code: 'INV-X8Y2K1', created_at: new Date(Date.now() - 86400000).toISOString() },
    { id: 'pend_2', name: 'Tez Yetkazib',   owner_phone: '+998902223344', invite_code: 'INV-A2B3C4', created_at: new Date(Date.now() - 86400000 * 2).toISOString() },
    { id: 'pend_3', name: 'Sayt do\'kon',   owner_phone: '+998903334455', invite_code: 'INV-Q9R7T2', created_at: new Date(Date.now() - 3600000 * 6).toISOString() },
  ];

  M.register('GET', '/adminbot/:tenant_id/supplier/pending-shops', async () => ({
    items: _pending,
  }));

  M.register('POST', '/adminbot/:tenant_id/supplier/pending-shops/:id/approve', async (_b, _o, params) => {
    const id = params && params[1];
    const idx = _pending.findIndex(p => p.id === id);
    if (idx < 0) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
    const removed = _pending.splice(idx, 1)[0];
    _shops.push({
      id: `shop_${_shops.length + 1}`,
      name: removed.name, tier: 'bronze', credit_limit: 2_000_000,
      balance: 0, status: 'active',
    });
    return { ok: true };
  });

  M.register('POST', '/adminbot/:tenant_id/supplier/pending-shops/:id/reject', async (_b, _o, params) => {
    const id = params && params[1];
    const idx = _pending.findIndex(p => p.id === id);
    if (idx < 0) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
    _pending.splice(idx, 1);
    return { ok: true };
  });
})();
