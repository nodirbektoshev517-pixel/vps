/**
 * mocks/inbox.js — buyurtmalar (Inbox) mock.
 *
 * Universal shakl (barcha biznes turlari uchun bir xil):
 *   - GET    /adminbot/{tenant}/inbox?status={s}&cursor={c}&page_size={n}
 *   - PATCH  /adminbot/{tenant}/items/{id}/status   { status: 'accepted' }
 *
 * Pagination: cursor-based (oxirgi olingan item ID dan keyin).
 * Status update yangi event chiqaradi (boshqa session/qurilmalarga tarqaladi).
 *
 * Dev console'da yangi buyurtma simulyatsiyasi:
 *   window.__mockNewOrder()   // tasodifiy yangi order
 */
(function () {
  'use strict';
  if (!window.Adminbot || !window.Adminbot.Mocks) return;
  const M = window.Adminbot.Mocks;
  const { Utils, Events } = window.Adminbot.Core;

  // === Mock holat ===
  const customers = [
    { name: 'Ali Karimov',       phone: '+998901234567', address: 'Toshkent, Chilonzor 12-25' },
    { name: 'Dilshod Tursunov',  phone: '+998902345678', address: 'Toshkent, Yunusobod 14-3' },
    { name: 'Madina Yusupova',   phone: '+998903456789', address: 'Toshkent, Mirzo Ulug\'bek 8-17' },
    { name: 'Bekzod Saidov',     phone: '+998904567890', address: 'Toshkent, Sergeli 22-101' },
    { name: 'Zarina Olimova',    phone: '+998905678901', address: 'Toshkent, Yakkasaroy 5-44' },
    { name: 'Jamshid Yusupov',   phone: '+998906789012', address: 'Toshkent, Mirobod 17-9' },
    { name: 'Nodira Kamalova',   phone: '+998907890123', address: 'Toshkent, Shayxontohur 3-12' },
    { name: 'Rustam Ahmedov',    phone: '+998908901234', address: 'Toshkent, Bektemir 19-7' },
  ];

  function pickCustomer() { return customers[Math.floor(Math.random() * customers.length)]; }

  function buildOrder(i, status = 'new', minutesAgo = 0) {
    const cust = pickCustomer();
    const createdAt = new Date(Date.now() - minutesAgo * 60 * 1000);
    return {
      id: `ord_${i}`,
      number: 1000 + i,
      status,
      customer_name: cust.name,
      customer_phone: cust.phone,
      delivery_address: cust.address,
      payment_method: ['cash', 'card', 'click'][i % 3],
      items_count: 1 + (i % 5),
      total: 50_000 + ((i * 17) % 20) * 25_000,
      currency: 'UZS',
      note: i % 4 === 0 ? 'Tezroq yetkazing iltimos' : null,
      created_at: createdAt.toISOString(),
      updated_at: createdAt.toISOString(),
    };
  }

  // Boshlang'ich 32 ta order — har xil status va vaqtda
  const STATUSES = ['new', 'accepted', 'preparing', 'ready', 'on_delivery', 'delivered', 'cancelled'];
  const _orders = [];
  for (let i = 1; i <= 32; i++) {
    const s = STATUSES[(i * 3) % STATUSES.length];
    _orders.push(buildOrder(i, s, i * 12));
  }
  // Yangi tartibda saqlanadi (eng yangi birinchi)
  _orders.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

  let _nextId = _orders.length + 1;

  // === GET inbox (paginatsiya) ===
  M.register('GET', '/adminbot/:tenant_id/inbox', async (_body, opts) => {
    const url = (opts && opts.url) || '';
    const q = new URLSearchParams(url.split('?')[1] || '');
    const status = q.get('status');                       // ixtiyoriy filter
    const cursor = q.get('cursor');                       // oxirgi ko'rilgan ID
    const pageSize = Math.min(50, parseInt(q.get('page_size') || '20', 10) || 20);

    let filtered = _orders;
    if (status && status !== 'all') {
      filtered = filtered.filter(o => o.status === status);
    }
    let startIdx = 0;
    if (cursor) {
      const idx = filtered.findIndex(o => o.id === cursor);
      if (idx >= 0) startIdx = idx + 1;
    }
    const items = filtered.slice(startIdx, startIdx + pageSize);
    const nextCursor = (startIdx + pageSize < filtered.length)
      ? items[items.length - 1].id
      : null;

    return {
      items,
      total: filtered.length,
      next_cursor: nextCursor,
      has_more: !!nextCursor,
    };
  });

  // === PATCH status ===
  // Status transition qoidalari — mock backend tomonidan tasdiqlanadi
  const TRANSITIONS = {
    new:           ['accepted', 'cancelled'],
    accepted:      ['preparing', 'cancelled'],
    preparing:     ['ready', 'cancelled'],
    ready:         ['on_delivery', 'delivered', 'cancelled'],
    on_delivery:   ['delivered', 'cancelled'],
    delivered:     [],
    cancelled:     [],
  };

  M.register('PATCH', '/adminbot/:tenant_id/items/:id/status', async (body, _opts, params) => {
    const id = params && params[1];
    const idx = _orders.findIndex(o => o.id === id);
    if (idx < 0) {
      const e = new Error('Buyurtma topilmadi'); e.status = 404; throw e;
    }
    const order = _orders[idx];
    const newStatus = body && body.status;
    if (!newStatus) {
      const e = new Error('status majburiy'); e.status = 422; throw e;
    }
    const allowed = TRANSITIONS[order.status] || [];
    if (!allowed.includes(newStatus)) {
      const e = new Error(
        `Status o'tishi ruxsat etilmagan: ${order.status} → ${newStatus}`
      );
      e.status = 409;
      throw e;
    }
    // Yangilash
    order.status = newStatus;
    order.updated_at = new Date().toISOString();

    // Boshqa session/qurilmalarga event push qilamiz (mock'da local emulation)
    setTimeout(() => {
      if (typeof window.__mockPushEvent === 'function') {
        window.__mockPushEvent({
          id: `evt_${Utils.uuid().slice(0, 8)}`,
          type: 'order.status_changed',
          entity_type: 'order',
          entity_id: order.id,
          payload: { id: order.id, status: order.status, updated_at: order.updated_at },
          created_at: new Date().toISOString(),
        });
      }
    }, 30);

    return order;
  });

  // === Dev helper: yangi buyurtma simulyatsiyasi ===
  // Brauzer console'idan chaqirish mumkin:
  //   window.__mockNewOrder()
  window.__mockNewOrder = function () {
    const order = buildOrder(_nextId++, 'new', 0);
    _orders.unshift(order);  // eng yangi - birinchi
    if (typeof window.__mockPushEvent === 'function') {
      window.__mockPushEvent({
        id: `evt_${Utils.uuid().slice(0, 8)}`,
        type: 'order.created',
        entity_type: 'order',
        entity_id: order.id,
        payload: order,
        created_at: new Date().toISOString(),
      });
    }
    return order;
  };

  // Testlar uchun
  window.__mockInboxState = {
    get orders() { return _orders; },
    reset() { /* test sandbox uchun */ },
  };
})();
