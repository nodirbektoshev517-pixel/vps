/**
 * mocks/events.js — Events sync va ack mock.
 *
 * Bu DOIMIY POLLING uchun emas. Frontend faqat:
 *   - app boot
 *   - focus/visibility return
 *   - user "Yangilash" bosganda
 *   - muhim write actiondan keyin
 * chaqiradi (cooldown bilan).
 */
(function () {
  'use strict';
  if (!window.Adminbot || !window.Adminbot.Mocks) return;
  const M = window.Adminbot.Mocks;

  // Bo'sh — mock mode'da real-time aloqa __mockPushEvent orqali bo'ladi.
  // syncSince bo'sh ro'yxat qaytarish — Bosqich 1 uchun yetarli.
  M.register('GET', '/adminbot/:tenant_id/events', async () => ({
    events: [],
    last_event_id: null,
  }));

  M.register('POST', '/adminbot/:tenant_id/events/:id/ack', async () => ({ ok: true }));
})();
