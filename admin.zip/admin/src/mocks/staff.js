/**
 * mocks/staff.js — Xodimlar ro'yxati va CRUD mock.
 */
(function () {
  'use strict';
  if (!window.Adminbot || !window.Adminbot.Mocks) return;
  const M = window.Adminbot.Mocks;
  const { Utils } = window.Adminbot.Core;

  const _staff = [
    {
      id: 'stf_1',
      first_name: 'Ali',
      last_name: 'Karimov',
      role: 'owner',
      telegram_username: 'ali_owner',
      phone: '+998901112233',
      permissions: ['*'],
      created_at: '2025-01-15T10:00:00Z',
      is_self: true,
    },
    {
      id: 'stf_2',
      first_name: 'Dilshod',
      last_name: 'Tursunov',
      role: 'manager',
      telegram_username: 'dilshod_m',
      phone: '+998902223344',
      permissions: ['orders.*', 'customers.view', 'reports.view'],
      created_at: '2025-02-10T11:30:00Z',
    },
    {
      id: 'stf_3',
      first_name: 'Madina',
      last_name: 'Yusupova',
      role: 'staff',
      telegram_username: 'madina_y',
      phone: '+998903334455',
      permissions: ['orders.view', 'orders.update'],
      created_at: '2025-03-22T09:15:00Z',
    },
    {
      id: 'stf_4',
      first_name: 'Bekzod',
      last_name: 'Saidov',
      role: 'courier',
      telegram_username: 'bekzod_courier',
      phone: '+998904445566',
      permissions: ['deliveries.view', 'deliveries.update'],
      created_at: '2025-04-05T08:00:00Z',
    },
  ];

  M.register('GET', '/adminbot/:tenant_id/staff', async () => ({
    items: _staff,
    total: _staff.length,
  }));

  M.register('POST', '/adminbot/:tenant_id/staff', async (body) => {
    if (!body || !body.first_name) {
      const e = new Error('first_name majburiy');
      e.status = 422;
      throw e;
    }
    const newStaff = {
      id: 'stf_' + Utils.uuid().slice(0, 8),
      first_name: body.first_name,
      last_name: body.last_name || '',
      role: body.role || 'staff',
      telegram_username: body.telegram_username || null,
      phone: body.phone || null,
      permissions: body.permissions || [],
      created_at: new Date().toISOString(),
    };
    _staff.push(newStaff);
    return newStaff;
  });

  M.register('PATCH', '/adminbot/:tenant_id/staff/:id', async (body, _opts, params) => {
    const id = params && params[1];
    const idx = _staff.findIndex(s => s.id === id);
    if (idx < 0) {
      const e = new Error('Xodim topilmadi');
      e.status = 404;
      throw e;
    }
    _staff[idx] = { ..._staff[idx], ...body, id };
    return _staff[idx];
  });

  M.register('DELETE', '/adminbot/:tenant_id/staff/:id', async (_body, _opts, params) => {
    const id = params && params[1];
    const idx = _staff.findIndex(s => s.id === id);
    if (idx < 0) {
      const e = new Error('Xodim topilmadi');
      e.status = 404;
      throw e;
    }
    if (_staff[idx].is_self) {
      const e = new Error('O\'zingizni o\'chira olmaysiz');
      e.status = 403;
      throw e;
    }
    _staff.splice(idx, 1);
    return null;
  });

  window.__mockStaffState = _staff;
})();
