/**
 * mocks/restaurant.js — Restaurant biznes turi uchun mock'lar (Bosqich 3.A).
 *
 * Resurslar: tables, reservations, banquets.
 * Real-time: table.status_changed, reservation.created, reservation.status_changed.
 */
(function () {
  'use strict';
  if (!window.Adminbot || !window.Adminbot.Mocks) return;
  const M = window.Adminbot.Mocks;
  const { Utils } = window.Adminbot.Core;

  // === Stollar (zal sxemasi) ===
  const _tables = [];
  const HALLS = [
    { id: 'hall_main', name: 'Asosiy zal',  capacity: 60 },
    { id: 'hall_vip',  name: 'VIP zal',     capacity: 24 },
  ];
  // 12 ta stol generatsiya — 2 zalda
  for (let i = 1; i <= 12; i++) {
    const inVip = i > 8;
    _tables.push({
      id: `tbl_${i}`,
      number: i,
      hall_id: inVip ? 'hall_vip' : 'hall_main',
      seats: inVip ? 6 : (2 + (i % 3) * 2),                // 2,4,6,...
      x: ((i - 1) % 4) * 25,                                // pozitsiya % (UI uchun)
      y: Math.floor((i - 1) / 4) * 30,
      status: ['free', 'reserved', 'occupied', 'free', 'cleaning'][i % 5],
    });
  }

  M.register('GET', '/adminbot/:tenant_id/restaurant/tables', async () => ({
    items: _tables, total: _tables.length, halls: HALLS,
  }));

  M.register('PATCH', '/adminbot/:tenant_id/restaurant/tables/:id/status', async (body, _o, params) => {
    const id = params && params[1];
    const t = _tables.find(x => x.id === id);
    if (!t) { const e = new Error('Stol topilmadi'); e.status = 404; throw e; }
    if (!['free', 'reserved', 'occupied', 'cleaning'].includes(body && body.status)) {
      const e = new Error('Noto\'g\'ri status'); e.status = 422; throw e;
    }
    t.status = body.status;
    setTimeout(() => {
      if (typeof window.__mockPushEvent === 'function') {
        window.__mockPushEvent({
          id: `evt_${Utils.uuid().slice(0, 8)}`,
          type: 'table.status_changed',
          entity_type: 'table',
          entity_id: t.id,
          payload: { id: t.id, status: t.status },
          created_at: new Date().toISOString(),
        });
      }
    }, 30);
    return t;
  });

  // === Bronlar (reservations) ===
  const _reservations = [];
  const customerNames = ['Olim Karimov', 'Sevara Yusupova', 'Akmal Tursunov', 'Madina Olimova'];
  for (let i = 1; i <= 16; i++) {
    const when = new Date(Date.now() + (i - 8) * 3600000 * 4);
    _reservations.push({
      id: `res_${i}`,
      number: 2000 + i,
      customer_name: customerNames[i % customerNames.length],
      customer_phone: `+9989012345${(i + 10).toString().padStart(2, '0')}`,
      party_size: 2 + (i % 6),
      table_id: i <= _tables.length ? `tbl_${i}` : null,
      reservation_time: when.toISOString(),
      status: ['requested', 'confirmed', 'seated', 'completed', 'cancelled'][i % 5],
      deposit: i % 3 === 0 ? 100_000 : 0,
      special_requests: i % 5 === 0 ? 'Tug\'ilgan kun, tort kerak' : null,
      created_at: new Date(Date.now() - i * 3600000 * 3).toISOString(),
    });
  }
  _reservations.sort((a, b) => new Date(b.reservation_time) - new Date(a.reservation_time));

  // Status transitions
  const RES_TRANSITIONS = {
    requested:  ['confirmed', 'cancelled'],
    confirmed:  ['seated', 'no_show', 'cancelled'],
    seated:     ['completed'],
    completed:  [],
    cancelled:  [],
    no_show:    [],
  };

  M.register('GET', '/adminbot/:tenant_id/restaurant/reservations', async (_b, opts) => {
    const url = (opts && opts.url) || '';
    const q = new URLSearchParams(url.split('?')[1] || '');
    const status = q.get('status');
    const cursor = q.get('cursor');
    const pageSize = Math.min(50, parseInt(q.get('page_size') || '20', 10));
    let filtered = _reservations;
    if (status && status !== 'all') filtered = filtered.filter(r => r.status === status);
    let startIdx = 0;
    if (cursor) {
      const i = filtered.findIndex(r => r.id === cursor);
      if (i >= 0) startIdx = i + 1;
    }
    const items = filtered.slice(startIdx, startIdx + pageSize);
    const nextCursor = (startIdx + pageSize < filtered.length)
      ? items[items.length - 1].id : null;
    return { items, total: filtered.length, next_cursor: nextCursor, has_more: !!nextCursor };
  });

  M.register('PATCH', '/adminbot/:tenant_id/restaurant/reservations/:id/status',
    async (body, _o, params) => {
      const id = params && params[1];
      const r = _reservations.find(x => x.id === id);
      if (!r) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
      const allowed = RES_TRANSITIONS[r.status] || [];
      if (!allowed.includes(body && body.status)) {
        const e = new Error(`Transition ruxsat etilmagan: ${r.status} → ${body.status}`);
        e.status = 409; throw e;
      }
      r.status = body.status;
      // Stol holatini ham yangilash
      if (r.status === 'seated' && r.table_id) {
        const t = _tables.find(x => x.id === r.table_id);
        if (t) t.status = 'occupied';
      } else if (r.status === 'completed' && r.table_id) {
        const t = _tables.find(x => x.id === r.table_id);
        if (t) t.status = 'cleaning';
      }
      return r;
    });

  // Dev helper
  window.__mockNewReservation = function () {
    const r = {
      id: `res_${_reservations.length + 100}`,
      number: 2000 + _reservations.length + 1,
      customer_name: customerNames[Math.floor(Math.random() * customerNames.length)],
      customer_phone: '+998901234500',
      party_size: 2 + Math.floor(Math.random() * 6),
      table_id: null,
      reservation_time: new Date(Date.now() + 7200000).toISOString(),
      status: 'requested',
      deposit: 0,
      special_requests: null,
      created_at: new Date().toISOString(),
    };
    _reservations.unshift(r);
    if (typeof window.__mockPushEvent === 'function') {
      window.__mockPushEvent({
        id: `evt_${Utils.uuid().slice(0, 8)}`,
        type: 'reservation.created',
        entity_type: 'reservation',
        entity_id: r.id,
        payload: r,
        created_at: new Date().toISOString(),
      });
    }
    return r;
  };

  // === Banketlar (banquets) ===
  const _banquets = [
    {
      id: 'bnq_1', name: 'Karimovlar to\'yi', date: new Date(Date.now() + 86400000 * 7).toISOString(),
      guest_count: 80, hall_id: 'hall_main', tables_assigned: ['tbl_1', 'tbl_2', 'tbl_3', 'tbl_4'],
      menu_summary: 'Plov, kabob, salatlar', contact_phone: '+998901234567', status: 'confirmed',
    },
    {
      id: 'bnq_2', name: 'Korporativ kechki', date: new Date(Date.now() + 86400000 * 3).toISOString(),
      guest_count: 24, hall_id: 'hall_vip', tables_assigned: ['tbl_9', 'tbl_10'],
      menu_summary: 'Steaks, sharbat', contact_phone: '+998901112233', status: 'requested',
    },
  ];

  M.register('GET', '/adminbot/:tenant_id/restaurant/banquets', async () => ({
    items: _banquets, total: _banquets.length,
  }));

  M.register('POST', '/adminbot/:tenant_id/restaurant/banquets', async (body) => {
    if (!body || !body.name) { const e = new Error('name majburiy'); e.status = 422; throw e; }
    const b = {
      id: `bnq_${Utils.uuid().slice(0, 6)}`,
      name: body.name,
      date: body.date || new Date().toISOString(),
      guest_count: body.guest_count || 0,
      hall_id: body.hall_id || 'hall_main',
      tables_assigned: body.tables_assigned || [],
      menu_summary: body.menu_summary || '',
      contact_phone: body.contact_phone || '',
      status: 'requested',
    };
    _banquets.push(b);
    return b;
  });

  M.register('PATCH', '/adminbot/:tenant_id/restaurant/banquets/:id', async (body, _o, params) => {
    const id = params && params[1];
    const idx = _banquets.findIndex(b => b.id === id);
    if (idx < 0) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
    _banquets[idx] = { ..._banquets[idx], ...body, id };
    return _banquets[idx];
  });

  M.register('DELETE', '/adminbot/:tenant_id/restaurant/banquets/:id', async (_b, _o, params) => {
    const id = params && params[1];
    const idx = _banquets.findIndex(b => b.id === id);
    if (idx < 0) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
    _banquets.splice(idx, 1);
    return null;
  });

  window.__mockRestaurantState = { tables: _tables, reservations: _reservations, banquets: _banquets, halls: HALLS };
})();
