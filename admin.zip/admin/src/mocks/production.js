/**
 * mocks/production.js — Custom production biznes turi uchun (Bosqich 3.C).
 *
 * Resurslar: briefs (technical briefs/orders), on_site_dispatches, price_proposals.
 * Stage advancing — buyurtmaning ishlab chiqarish bosqichi.
 */
(function () {
  'use strict';
  if (!window.Adminbot || !window.Adminbot.Mocks) return;
  const M = window.Adminbot.Mocks;
  const { Utils } = window.Adminbot.Core;

  const _briefs = [];
  const customers = ['Karimovlar oilasi', 'Aliyeva Madina', 'Tursunov Bekzod', 'Olimov Sardor'];
  const types = ['Mebel — divan', 'Mebel — oshxona', 'Eshik — yog\'och', 'Pardalar', 'Gilam', 'Yotoq xona'];
  for (let i = 1; i <= 12; i++) {
    _briefs.push({
      id: `brf_${i}`,
      number: 4000 + i,
      customer_name: customers[i % customers.length],
      customer_phone: `+99890${(1000000 + i * 1234).toString().slice(0, 7)}`,
      product_type: types[i % types.length],
      description: `Talab ${i}: o'lchamlar va material tafsilotlari shart.`,
      images: [],
      stage: ['brief_review', 'proposal_sent', 'approved', 'design', 'production', 'finishing', 'delivery', 'completed', 'cancelled'][i % 9],
      proposed_price: i % 9 < 2 ? null : (1_000_000 + i * 350_000),
      agreed_price: i % 9 >= 3 ? (1_000_000 + i * 350_000) : null,
      created_at: new Date(Date.now() - i * 86400000 * 2).toISOString(),
      target_delivery_at: new Date(Date.now() + i * 86400000 * 5).toISOString(),
    });
  }
  _briefs.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

  // Stage transition jadvali
  const STAGE_TRANSITIONS = {
    brief_review:  ['proposal_sent', 'cancelled'],
    proposal_sent: ['approved', 'cancelled'],
    approved:      ['design'],
    design:        ['production', 'cancelled'],
    production:    ['finishing'],
    finishing:     ['delivery'],
    delivery:      ['completed'],
    completed:     [],
    cancelled:     [],
  };

  M.register('GET', '/adminbot/:tenant_id/production/briefs', async (_b, opts) => {
    const url = (opts && opts.url) || '';
    const q = new URLSearchParams(url.split('?')[1] || '');
    const stage = q.get('stage');
    const cursor = q.get('cursor');
    const pageSize = Math.min(50, parseInt(q.get('page_size') || '20', 10));
    let filtered = _briefs;
    if (stage && stage !== 'all') filtered = filtered.filter(b => b.stage === stage);
    let startIdx = 0;
    if (cursor) {
      const i = filtered.findIndex(b => b.id === cursor);
      if (i >= 0) startIdx = i + 1;
    }
    const items = filtered.slice(startIdx, startIdx + pageSize);
    const nextCursor = (startIdx + pageSize < filtered.length)
      ? items[items.length - 1].id : null;
    return { items, total: filtered.length, next_cursor: nextCursor, has_more: !!nextCursor };
  });

  M.register('GET', '/adminbot/:tenant_id/production/briefs/:id', async (_b, _o, params) => {
    const id = params && params[1];
    const b = _briefs.find(x => x.id === id);
    if (!b) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
    return b;
  });

  M.register('PATCH', '/adminbot/:tenant_id/production/briefs/:id/stage',
    async (body, _o, params) => {
      const id = params && params[1];
      const b = _briefs.find(x => x.id === id);
      if (!b) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
      const allowed = STAGE_TRANSITIONS[b.stage] || [];
      if (!allowed.includes(body && body.stage)) {
        const e = new Error(`Stage transition ruxsat etilmagan: ${b.stage} → ${body.stage}`);
        e.status = 409; throw e;
      }
      b.stage = body.stage;
      // Real-time event
      setTimeout(() => {
        if (typeof window.__mockPushEvent === 'function') {
          window.__mockPushEvent({
            id: `evt_${Utils.uuid().slice(0, 8)}`,
            type: 'brief.stage_changed',
            entity_id: b.id,
            payload: { id: b.id, stage: b.stage },
            created_at: new Date().toISOString(),
          });
        }
      }, 30);
      return b;
    });

  // === Price proposals ===
  M.register('POST', '/adminbot/:tenant_id/production/briefs/:id/proposal',
    async (body, _o, params) => {
      const id = params && params[1];
      const b = _briefs.find(x => x.id === id);
      if (!b) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
      const price = parseInt(body && body.price, 10);
      if (!price || price <= 0) {
        const e = new Error('price majburiy va musbat bo\'lishi kerak'); e.status = 422; throw e;
      }
      if (b.stage !== 'brief_review') {
        const e = new Error('Faqat brief_review bosqichida taklif yuborilishi mumkin');
        e.status = 409; throw e;
      }
      b.proposed_price = price;
      b.stage = 'proposal_sent';
      return b;
    });

  // === On-site dispatches ===
  const _dispatches = [
    { id: 'dsp_1', brief_id: 'brf_1', worker_name: 'Sherzod usta', address: 'Toshkent, Yunusobod 14-3', scheduled_at: new Date(Date.now() + 86400000).toISOString(), purpose: 'O\'lcham olish', status: 'scheduled' },
    { id: 'dsp_2', brief_id: 'brf_2', worker_name: 'Akmal usta',   address: 'Toshkent, Chilonzor 8-12', scheduled_at: new Date(Date.now() + 86400000 * 2).toISOString(), purpose: 'O\'rnatish', status: 'completed' },
  ];

  M.register('GET', '/adminbot/:tenant_id/production/dispatches', async () =>
    ({ items: _dispatches, total: _dispatches.length }));

  M.register('POST', '/adminbot/:tenant_id/production/dispatches', async (body) => {
    if (!body || !body.brief_id || !body.scheduled_at) {
      const e = new Error('brief_id va scheduled_at majburiy'); e.status = 422; throw e;
    }
    const d = {
      id: `dsp_${Utils.uuid().slice(0, 6)}`,
      brief_id: body.brief_id,
      worker_name: body.worker_name || 'Belgilanmagan',
      address: body.address || '',
      scheduled_at: body.scheduled_at,
      purpose: body.purpose || 'O\'lcham olish',
      status: 'scheduled',
    };
    _dispatches.push(d);
    return d;
  });

  M.register('PATCH', '/adminbot/:tenant_id/production/dispatches/:id/status',
    async (body, _o, params) => {
      const id = params && params[1];
      const d = _dispatches.find(x => x.id === id);
      if (!d) { const e = new Error('Topilmadi'); e.status = 404; throw e; }
      if (!['scheduled', 'in_progress', 'completed', 'cancelled'].includes(body && body.status)) {
        const e = new Error('Noto\'g\'ri status'); e.status = 422; throw e;
      }
      d.status = body.status;
      return d;
    });

  window.__mockProductionState = { briefs: _briefs, dispatches: _dispatches };
})();
