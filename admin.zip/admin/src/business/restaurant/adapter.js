/**
 * business/restaurant/adapter.js — Restoran biznes turi.
 *
 * SOF DEKLARATIV. Function YO'Q.
 *
 * Restoran asosiy operatsiyasi: stollar holati + bronlar + buyurtmalar.
 *  - Tables (TableMap) — hozirgi holat (bo'sh/band/tozalanmoqda)
 *  - Reservations (InboxList + ReservationCard) — kelishi rejalashtirilgan
 *  - Orders (InboxList + OrderCard) — buyurtmalar (table/pickup/delivery)
 *  - Banquets — voqea/to'y bronlari (multi-table)
 *
 * Reservation status oqimi: requested → confirmed → seated → completed
 *  yoki cancelled / no_show
 *
 * Order status oqimi: created → accepted → preparing → ready → delivered
 *  yoki canceled har joyda
 */
(function () {
  'use strict';

  window.Adminbot.Business.restaurant = {
    business_type: 'restaurant',
    label: 'Restoran',

    enabled_components: [
      // Infrastructure
      'AuthGate', 'PinGate', 'LockScreen', 'BottomNav',
      'Dashboard', 'SettingsView', 'StaffManager',
      // Inbox bloki — reservations va orders uchun ishlatiladi (data_source orqali)
      'InboxList',
      // Reservations
      'ReservationCard', 'SpecialRequestsBlock', 'DepositStatusBlock', 'PartyInfoBlock',
      // Orders (yangi)
      'OrderCard', 'OrderStatusBadge',
      // Restaurant-spetsifik
      'TableMap', 'BanquetManager', 'HallStatusBoard',
      // Menyu
      'CategoryCRUD', 'ProductCRUD', 'ImageUploader',
      'VariantsBlock', 'AddonsBlock',
      // Hisobot va boshqaruv
      'ReportsView', 'NotificationsBroadcast', 'EventsLog',
    ],

    component_configs: {
      Dashboard: {
        stat_cards: ['todays_reservations', 'occupied_tables', 'revenue', 'avg_party_size'],
      },

      InboxList: {
        // KALIT QISMI: data_source — generic InboxList'ni reservations'ga ulash
        data_source: { service: 'restaurant', method: 'listReservations' },
        status_kind: 'reservation',        // Labels uchun
        status_field: 'status',            // backend filter parametri
        created_event: 'reservation.created',
        status_changed_event: 'reservation.status_changed',
        item_card: 'ReservationCard',
        statuses: ['requested', 'confirmed', 'seated', 'completed', 'cancelled', 'no_show'],
        default_status: 'requested',
        page_size: 20,
        terms: { items: 'Bronlar', item: 'Bron' },
      },

      ReservationCard: {
        extensions: ['special_requests', 'deposit_status', 'party_info'],
        primary_actions: {
          requested: ['confirmed'],
          confirmed: ['seated'],
          seated:    ['completed'],
        },
      },

      // Restoran ofitsianti uchun status oqimi.
      // delivered = yakuniy (hozir to'lov bosqichi yo'q, keyin qo'shiladi)
      OrderCard: {
        extensions: ['note'],
        primary_actions: {
          created:    ['accepted', 'canceled'],
          accepted:   ['preparing', 'canceled'],
          preparing:  ['ready', 'canceled'],
          ready:      ['delivered'],
          // delivered va canceled — yakuniy, tugma yo'q
        },
      },

      // Restoran sessiyalari (Phase 1).
      // Backend transitions: bill_requested -> closing -> closed.
      // Action tugma labellari Labels.SESSION_STATUS'dan keladi:
      //   'closing' -> "Yopilmoqda", 'closed' -> "Yopilgan"
      SessionCard: {
        primary_actions: {
          open:           [],
          bill_requested: ['closing'],
          closing:        ['closed'],
          closed:         [],
          abandoned:      [],
        },
      },

      TableMap: {
        // Adapter terms ichida zal nomlari ham bo'lishi mumkin (mock backend bermasa)
      },

      BanquetManager: {
        terms: { banquets: 'Banketlar' },
      },

      CategoryCRUD: { terms: { catalog: 'Menyu' } },
      ProductCRUD: {
        extensions: ['variants', 'addons'],
        terms: { item: 'Taom', items: 'Taomlar' },
      },

      ReportsView: {
        reports: ['daily_sales', 'top_products', 'reservation_summary', 'hall_occupancy'],
      },

      StaffManager: { terms: { staff: 'Xodimlar' } },
      SettingsView: { sections: ['profile', 'pin', 'notifications', 'theme', 'about'] },
    },

    routes: [
      // BottomNav (5 ta) — operativ ko'rinishlar oldinda
      { key: 'dashboard',    component: 'Dashboard',         icon: '🏠', label: 'Bosh',        permission: 'dashboard.view' },
      { key: 'reservations', component: 'InboxList',         icon: '📅', label: 'Bronlar',     permission: 'reservations.view' },
      { key: 'tables',       component: 'TableMap',          icon: '🪑', label: 'Stollar',     permission: 'restaurant.tables.view' },
      { key: 'catalog',      component: 'CategoryCRUD',      icon: '🍽️', label: 'Menyu',       permission: 'catalog.view' },
      { key: 'settings',     component: 'SettingsView',      icon: '⚙️', label: 'Sozlama' },
      // Secondary:
      { key: 'orders',       component: 'InboxList',              icon: '📋', label: 'Buyurtmalar',     permission: 'orders.view',    secondary: true,
        config: {
          data_source: { service: 'inbox', method: 'list' },
          status_kind: 'order',
          status_field: 'status',
          created_event: 'order.created',
          status_changed_event: 'order.status_changed',
          item_card: 'OrderCard',
          statuses: ['created', 'accepted', 'preparing', 'ready', 'delivered', 'canceled'],
          default_status: 'all',
          page_size: 20,
          terms: { items: 'Buyurtmalar', item: 'Buyurtma' },
        },
      },
      { key: 'sessions',     component: 'InboxList',              icon: '🧾', label: 'Sessiyalar',      permission: 'orders.view',    secondary: true,
        config: {
          data_source: { service: 'restaurantSessions', method: 'list' },
          status_kind: 'session',
          status_field: 'status',
          created_event: 'restaurant_session.created',
          status_changed_event: 'restaurant_session.status_changed',
          item_card: 'SessionCard',
          statuses: ['open', 'bill_requested', 'closing'],
          default_status: 'all',
          page_size: 20,
          terms: { items: 'Sessiyalar', item: 'Sessiya' },
        },
      },
      { key: 'hall_status',  component: 'HallStatusBoard',        icon: '📊', label: 'Zal holati',      permission: 'restaurant.tables.view', secondary: true },
      { key: 'banquets',     component: 'BanquetManager',         icon: '🎉', label: 'Banketlar',       permission: 'restaurant.banquets.manage', secondary: true },
      { key: 'reports',      component: 'ReportsView',            icon: '📊', label: 'Hisobotlar',      permission: 'reports.view',   secondary: true },
      { key: 'broadcast',    component: 'NotificationsBroadcast', icon: '📢', label: 'Xabar yuborish',  permission: 'broadcast.send', secondary: true },
      { key: 'staff',        component: 'StaffManager',           icon: '👤', label: 'Xodimlar',        permission: 'staff.view',     secondary: true },
      { key: 'audit',        component: 'EventsLog',              icon: '📋', label: 'Audit jurnali',   permission: 'audit.view',     secondary: true },
    ],
  };
})();
