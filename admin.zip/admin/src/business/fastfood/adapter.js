/**
 * business/fastfood/adapter.js — Fastfood biznes turi uchun adapter.
 *
 * SOF DEKLARATIV. Function YO'Q.
 *
 * Fastfood — eng sodda biznes turi:
 *   - Pickup (mijoz keladi yoki zalda iste'mol qiladi), yetkazib berish YO'Q
 *   - Status oqimi: new → accepted → preparing → ready → completed
 *   - Mijoz profili tahlili YO'Q (asosan anonim buyurtmalar)
 *   - Yetkazib berish manzili YO'Q (extension o'chirilgan)
 *   - Menyu: variantlar (porsion: kichik/o'rta/katta) va qo'shimchalar (sous, ichimlik) muhim
 */
(function () {
  'use strict';

  window.Adminbot.Business.fastfood = {
    business_type: 'fastfood',
    label: 'Fastfood',

    enabled_components: [
      // Infrastructure
      'AuthGate', 'PinGate', 'LockScreen', 'BottomNav',
      'Dashboard', 'SettingsView', 'StaffManager',
      // Inbox bloki (yetkazish manzili extension'siz)
      'InboxList', 'OrderCard', 'OrderStatusBadge',
      'PaymentBlock', 'NoteBlock',
      // Katalog — variantlar va qo'shimchalar fastfood uchun muhim
      'CategoryCRUD', 'ProductCRUD', 'ImageUploader',
      'VariantsBlock', 'AddonsBlock',
      // Hisobot va boshqaruv
      'ReportsView', 'NotificationsBroadcast', 'EventsLog',
    ],

    component_configs: {
      Dashboard: {
        // Fastfood operativ — daromad va o'rtacha xizmat vaqti muhim
        stat_cards: ['todays_orders', 'new_orders', 'revenue', 'avg_prep_time'],
      },

      InboxList: {
        item_card: 'OrderCard',
        // delivery'siz status oqimi
        statuses: ['new', 'accepted', 'preparing', 'ready', 'completed', 'cancelled'],
        default_status: 'new',
        page_size: 20,
        terms: { item: 'Buyurtma', items: 'Buyurtmalar' },
      },

      OrderCard: {
        // Pickup biznes — manzil YO'Q
        extensions: ['payment_method', 'note'],
        primary_actions: {
          new:       ['accepted'],
          accepted:  ['preparing'],
          preparing: ['ready'],
          ready:     ['completed'],
        },
        // Status label override — fastfood kontekstida "Tayyor" = "Olib ketishga tayyor"
        terms: { ready: 'Olib ketishga tayyor', completed: 'Berildi' },
      },

      CategoryCRUD: {
        terms: { catalog: 'Menyu' },
      },

      ProductCRUD: {
        // Menyu uchun variantlar va qo'shimchalar — markaziy
        extensions: ['variants', 'addons'],
        terms: { item: 'Taom', items: 'Taomlar' },
      },

      ReportsView: {
        // Mijoz hisoboti YO'Q (anonim) — operativ ko'rsatkichlarga e'tibor
        reports: ['daily_sales', 'top_products', 'hourly_load'],
      },

      StaffManager: {
        terms: { staff: 'Xodimlar' },
      },

      SettingsView: {
        sections: ['profile', 'pin', 'notifications', 'theme', 'about'],
      },
    },

    routes: [
      // BottomNav (4 ta — shop'dan 1 ta kam, mijozlar yo'q)
      { key: 'dashboard',  component: 'Dashboard',              icon: '🏠', label: 'Bosh',         permission: 'dashboard.view' },
      { key: 'orders',     component: 'InboxList',              icon: '🍔', label: 'Buyurtmalar',  permission: 'orders.view' },
      { key: 'catalog',    component: 'CategoryCRUD',           icon: '📋', label: 'Menyu',        permission: 'catalog.view' },
      { key: 'settings',   component: 'SettingsView',           icon: '⚙️', label: 'Sozlama' },
      // Secondary (settings ichida "Boshqa bo'limlar"):
      { key: 'reports',    component: 'ReportsView',            icon: '📊', label: 'Hisobotlar',     permission: 'reports.view',   secondary: true },
      { key: 'broadcast',  component: 'NotificationsBroadcast', icon: '📢', label: 'Xabar yuborish', permission: 'broadcast.send', secondary: true },
      { key: 'staff',      component: 'StaffManager',           icon: '👤', label: 'Xodimlar',       permission: 'staff.view',     secondary: true },
      { key: 'audit',      component: 'EventsLog',              icon: '📋', label: 'Audit jurnali',  permission: 'audit.view',     secondary: true },
    ],
  };
})();
