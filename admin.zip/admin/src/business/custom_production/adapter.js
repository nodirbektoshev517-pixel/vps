/**
 * business/custom_production/adapter.js — Buyurtma ishlab chiqarish biznes turi.
 *
 * SOF DEKLARATIV. Function YO'Q.
 *
 * Misol: mebel ustaxonasi, eshik ishlab chiqarish, ko'rpa-yostiq, pardalar.
 *
 * "Statik katalog" YO'Q — har buyurtma noyob (brief asosida).
 *
 * Brief stage oqimi (9 bosqich):
 *   brief_review → proposal_sent → approved → design → production
 *      → finishing → delivery → completed
 *  Yoki istalgan boshlang'ich bosqichdan: cancelled
 */
(function () {
  'use strict';

  window.Adminbot.Business.custom_production = {
    business_type: 'custom_production',
    label: 'Buyurtma ishlab chiqarish',

    enabled_components: [
      // Infrastructure
      'AuthGate', 'PinGate', 'LockScreen', 'BottomNav',
      'Dashboard', 'SettingsView', 'StaffManager',
      // Inbox bloki — briefs uchun (data_source + BriefCard)
      'InboxList',
      // Production-spetsifik (3.C)
      'BriefCard', 'TechBriefViewer', 'StageAdvancer', 'PriceProposalSender', 'OnSiteDispatch',
      // Hisobot va boshqaruv
      'ReportsView', 'NotificationsBroadcast', 'EventsLog',
      // Mijoz — qaytaruvchi mijozlar uchun
      'CustomerList', 'CustomerProfile',
    ],

    component_configs: {
      Dashboard: {
        stat_cards: ['active_briefs', 'in_production', 'revenue', 'avg_lead_time'],
      },

      InboxList: {
        // Briefs'ni listing — InboxList generic'i shu yerda kuchli ko'rinadi
        data_source: { service: 'production', method: 'listBriefs' },
        status_kind: 'production',          // Labels.PRODUCTION_STAGE
        status_field: 'stage',              // backend filter parametri (status emas — stage)
        created_event: 'brief.created',
        status_changed_event: 'brief.stage_changed',
        item_card: 'BriefCard',
        // 9 bosqich + 'cancelled'
        statuses: [
          'brief_review', 'proposal_sent', 'approved', 'design',
          'production', 'finishing', 'delivery', 'completed', 'cancelled',
        ],
        default_status: 'brief_review',
        page_size: 20,
        terms: { items: 'Topshiriqlar', item: 'Topshiriq' },
      },

      BriefCard: {
        terms: { brief: 'Topshiriq' },
      },

      OnSiteDispatch: {
        terms: { dispatches: 'Tashriflar' },
      },

      CustomerList: { terms: { customers: 'Mijozlar' } },

      ReportsView: {
        reports: ['daily_briefs', 'stage_distribution', 'lead_time_summary', 'revenue_by_type'],
      },

      StaffManager: { terms: { staff: 'Xodimlar' } },
      SettingsView: { sections: ['profile', 'pin', 'notifications', 'theme', 'about'] },
    },

    routes: [
      // BottomNav (4 ta — statik katalog yo'q)
      { key: 'dashboard',  component: 'Dashboard',      icon: '🏠', label: 'Bosh',         permission: 'dashboard.view' },
      { key: 'briefs',     component: 'InboxList',      icon: '📐', label: 'Topshiriqlar', permission: 'production.briefs.view' },
      { key: 'dispatches', component: 'OnSiteDispatch', icon: '🛠️', label: 'Tashriflar',  permission: 'production.dispatch.manage' },
      { key: 'settings',   component: 'SettingsView',   icon: '⚙️', label: 'Sozlama' },
      // Secondary:
      { key: 'customers',  component: 'CustomerList',           icon: '👤', label: 'Mijozlar',        permission: 'customers.view',  secondary: true },
      { key: 'reports',    component: 'ReportsView',            icon: '📊', label: 'Hisobotlar',      permission: 'reports.view',    secondary: true },
      { key: 'broadcast',  component: 'NotificationsBroadcast', icon: '📢', label: 'Xabar yuborish',  permission: 'broadcast.send',  secondary: true },
      { key: 'staff',      component: 'StaffManager',           icon: '🧑‍🔧', label: 'Xodimlar',       permission: 'staff.view',      secondary: true },
      { key: 'audit',      component: 'EventsLog',              icon: '📋', label: 'Audit jurnali',   permission: 'audit.view',      secondary: true },
    ],
  };
})();
