/**
 * business/registry.js — biznes turi → adapter map.
 *
 * Bu fayl barcha adapterlardan KEYIN yuklanadi (build.py shu tartibni
 * ta'minlaydi). Adapterlar window.Adminbot.Business[business_type] ga
 * yozadi, biz ularni mantiqiy interfeys orqali olamiz.
 */
(function () {
  'use strict';

  /**
   * Adapter olish.
   * @param {string} businessType
   * @returns {object|null}
   */
  function get(businessType) {
    if (!businessType) return null;
    return window.Adminbot.Business[businessType] || null;
  }

  /**
   * Ro'yxatdagi barcha biznes turlari.
   */
  function list() {
    return Object.keys(window.Adminbot.Business).filter(k => {
      const a = window.Adminbot.Business[k];
      return a && a.business_type;
    });
  }

  /**
   * Adapter validatsiyasi — sof deklarativlikni tekshirish.
   * Agar adapter ichida function topilsa, console.warn chiqaramiz.
   * (Test fayli buni qattiqroq tekshiradi.)
   */
  function validatePurity(adapter) {
    if (!adapter) return { ok: false, reason: 'adapter null' };
    const violations = [];
    function check(obj, path) {
      if (typeof obj === 'function') {
        violations.push(path + ' = function (taqiqlangan)');
        return;
      }
      if (obj && typeof obj === 'object') {
        for (const k of Object.keys(obj)) {
          check(obj[k], path + '.' + k);
        }
      }
    }
    check(adapter, adapter.business_type || 'adapter');
    return {
      ok: violations.length === 0,
      violations,
    };
  }

  window.Adminbot.Core.BusinessRegistry = { get, list, validatePurity };
})();
