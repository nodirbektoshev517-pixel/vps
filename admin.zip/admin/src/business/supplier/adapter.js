/**
 * business/supplier/adapter.js — Supplier (B2B ulgurji) biznes turi.
 *
 * SOF DEKLARATIV. Function YO'Q.
 *
 * Supplier — qaramogʻidagi do'konlarga (downstream) ulgurji mahsulot beradi.
 * Asosiy operatsion vazifa: do'konlarning balans, kredit, tier'ini boshqarish.
 *
 * Status oqimi: new → accepted → shipped → completed / cancelled
 *  (consumer terms 'on_delivery', 'delivered' YO'Q — bu B2B).
 */
(function () {
  'use strict';

  window.Adminbot.Business.supplier = {
    business_type: 'supplier',
    label: 'Yetkazib beruvchi',

    enabled_components: [
      // Infrastructure
      'AuthGate', 'PinGate', 'LockScreen', 'BottomNav',
      'Dashboard', 'SettingsView', 'StaffManager',
      // Inbox (do'konlardan buyurtmalar)
      'InboxList', 'OrderCard', 'OrderStatusBadge', 'NoteBlock', 'PaymentBlock',
      // Katalog
      'CategoryCRUD', 'ProductCRUD', 'ImageUploader',
      'VariantsBlock', 'AddonsBlock',
      // Supplier-spetsifik (2.5)
      'TierAssigner', 'CreditLimitManager', 'BalanceLedger', 'BalanceOperation',
      'InviteCodeGenerator', 'ShopApprover',
      // Hisobot va boshqaruv
      'ReportsView', 'NotificationsBroadcast', 'EventsLog',
    ],

    component_configs: {
      Dashboard: {
        stat_cards: ['todays_orders', 'new_orders', 'revenue', 'active_shops'],
      },

      InboxList: {
        item_card: 'OrderCard',
        // B2B status oqimi (shipped, on_delivery/delivered emas)
        statuses: ['new', 'accepted', 'shipped', 'completed', 'cancelled'],
        default_status: 'new',
        page_size: 20,
        terms: { item: 'Buyurtma', items: 'Buyurtmalar' },
      },

      OrderCard: {
        // B2B uchun manzil va yetkazib berish bor (yuk), lekin "shipped" status
        extensions: ['delivery_address', 'payment_method', 'note'],
        primary_actions: {
          new:      ['accepted'],
          accepted: ['shipped'],
          shipped:  ['completed'],
        },
      },

      CategoryCRUD: { terms: { catalog: 'Ulgurji katalog' } },
      ProductCRUD: {
        extensions: ['variants', 'addons'],
        terms: { item: 'Mahsulot', items: 'Mahsulotlar' },
      },

      TierAssigner: {
        // Bronze (5%), Silver (10%), Gold (15%), Platinum (20%) — discount darajalari
        terms: { shops: 'Do\'konlar' },
      },

      CreditLimitManager: {
        terms: { credit_limit: 'Kredit limiti' },
      },

      BalanceLedger: {
        terms: { balance: 'Balans' },
      },

      ReportsView: {
        // Supplier-spetsifik: do'konlar bo'yicha hisobotlar
        reports: ['daily_sales', 'top_shops', 'tier_distribution', 'credit_usage'],
      },

      StaffManager: { terms: { staff: 'Xodimlar' } },
      SettingsView: { sections: ['profile', 'pin', 'notifications', 'theme', 'about'] },
    },

    routes: [
      // BottomNav (5 ta)
      { key: 'dashboard',    component: 'Dashboard',     icon: '🏠', label: 'Bosh',        permission: 'dashboard.view' },
      { key: 'orders',       component: 'InboxList',     icon: '📦', label: 'Buyurtmalar', permission: 'orders.view' },
      { key: 'shops',        component: 'TierAssigner',  icon: '🏪', label: 'Do\'konlar',  permission: 'shops.view' },
      { key: 'catalog',      component: 'CategoryCRUD',  icon: '📋', label: 'Katalog',     permission: 'catalog.view' },
      { key: 'settings',     component: 'SettingsView',  icon: '⚙️', label: 'Sozlama' },
      // Secondary (settings ichida "Boshqa bo'limlar"):
      { key: 'balance',      component: 'BalanceLedger',         icon: '💰', label: 'Balans tarixi',   permission: 'supplier.balance.view',  secondary: true },
      { key: 'credit',       component: 'CreditLimitManager',    icon: '🏦', label: 'Kredit limiti',    permission: 'supplier.credit.manage', secondary: true },
      { key: 'invites',      component: 'InviteCodeGenerator',   icon: '🔑', label: 'Taklif kodlari',   permission: 'supplier.invites.manage', secondary: true },
      { key: 'pending',      component: 'ShopApprover',          icon: '✅', label: 'Kutilayotgan',     permission: 'supplier.shops.approve',  secondary: true },
      { key: 'reports',      component: 'ReportsView',            icon: '📊', label: 'Hisobotlar',       permission: 'reports.view',   secondary: true },
      { key: 'broadcast',    component: 'NotificationsBroadcast', icon: '📢', label: 'Xabar yuborish',   permission: 'broadcast.send', secondary: true },
      { key: 'staff',        component: 'StaffManager',           icon: '👤', label: 'Xodimlar',         permission: 'staff.view',     secondary: true },
      { key: 'audit',        component: 'EventsLog',              icon: '📋', label: 'Audit jurnali',    permission: 'audit.view',     secondary: true },
    ],
  };
})();
