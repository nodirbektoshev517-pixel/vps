/**
 * business/shop/adapter.js — Shop biznes turi uchun adapter.
 *
 * SOF DEKLARATIV. Hech qanday function, mantiq yoki komponent.
 */
(function () {
  'use strict';

  window.Adminbot.Business.shop = {
    business_type: 'shop',
    label: 'Do\'kon',

    enabled_components: [
      // Infrastructure
      'AuthGate', 'PinGate', 'LockScreen', 'BottomNav',
      'Dashboard', 'SettingsView', 'StaffManager',
      // Inbox bloki (2.1)
      'InboxList', 'OrderCard', 'OrderStatusBadge',
      'AddressBlock', 'PaymentBlock', 'NoteBlock',
      // Katalog (2.2)
      'CategoryCRUD', 'ProductCRUD', 'ImageUploader',
      'VariantsBlock', 'AddonsBlock',
      // Mijozlar va hisobotlar (2.3)
      'CustomerList', 'CustomerProfile', 'ReportsView',
      'OrdersHistoryBlock',
      // Boshqaruv (2.4)
      'NotificationsBroadcast', 'EventsLog',
    ],

    component_configs: {
      Dashboard: {
        stat_cards: ['todays_orders', 'new_orders', 'revenue', 'customers'],
      },

      InboxList: {
        item_card: 'OrderCard',
        statuses: ['new', 'accepted', 'preparing', 'ready', 'on_delivery', 'delivered', 'cancelled'],
        default_status: 'new',
        page_size: 20,
        terms: { item: 'Buyurtma', items: 'Buyurtmalar' },
      },

      OrderCard: {
        extensions: ['delivery_address', 'payment_method', 'note'],
        primary_actions: {
          new:         ['accepted'],
          accepted:    ['preparing'],
          preparing:   ['ready'],
          ready:       ['on_delivery'],
          on_delivery: ['delivered'],
        },
      },

      CategoryCRUD: {
        terms: { catalog: 'Katalog' },
      },

      ProductCRUD: {
        extensions: ['variants', 'addons'],
      },

      CustomerList: {
        terms: { customers: 'Mijozlar' },
      },

      CustomerProfile: {
        extensions: ['orders_history'],
      },

      ReportsView: {
        reports: ['daily_sales', 'top_products', 'customer_summary'],
      },

      StaffManager: {
        terms: { staff: 'Xodimlar' },
      },

      SettingsView: {
        sections: ['profile', 'pin', 'notifications', 'theme', 'about'],
      },
    },

    routes: [
      { key: 'dashboard',  component: 'Dashboard',              icon: '🏠', label: 'Bosh',         permission: 'dashboard.view' },
      { key: 'orders',     component: 'InboxList',              icon: '📦', label: 'Buyurtmalar',  permission: 'orders.view' },
      { key: 'catalog',    component: 'CategoryCRUD',           icon: '🛍️', label: 'Katalog',      permission: 'catalog.view' },
      { key: 'customers',  component: 'CustomerList',           icon: '👥', label: 'Mijozlar',     permission: 'customers.view' },
      { key: 'settings',   component: 'SettingsView',           icon: '⚙️', label: 'Sozlama' },
      // Secondary (BottomNav'ga kirmaydi — settings ichidan ochiladi):
      { key: 'reports',    component: 'ReportsView',            icon: '📊', label: 'Hisobotlar',   permission: 'reports.view',   secondary: true },
      { key: 'broadcast',  component: 'NotificationsBroadcast', icon: '📢', label: 'Xabar yuborish', permission: 'broadcast.send', secondary: true },
      { key: 'staff',      component: 'StaffManager',           icon: '👤', label: 'Xodimlar',     permission: 'staff.view',     secondary: true },
      { key: 'audit',      component: 'EventsLog',              icon: '📋', label: 'Audit jurnali', permission: 'audit.view',     secondary: true },
    ],
  };
})();
