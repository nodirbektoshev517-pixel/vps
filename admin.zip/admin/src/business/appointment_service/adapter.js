/**
 * business/appointment_service/adapter.js — Servis biznesi (uchrashuv asosli).
 *
 * SOF DEKLARATIV. Function YO'Q.
 *
 * Misol: soch turmaklash, manikyur, kosmetologiya, klinikalar, repetitorlik.
 *
 * Asosiy operatsiya: bugungi kun jadvali (CalendarView), xizmatlar va mutaxassislar.
 *
 * Appointment status oqimi: scheduled → in_progress → completed
 *  yoki cancelled / no_show
 */
(function () {
  'use strict';

  window.Adminbot.Business.appointment_service = {
    business_type: 'appointment_service',
    label: 'Servis',

    enabled_components: [
      // Infrastructure
      'AuthGate', 'PinGate', 'LockScreen', 'BottomNav',
      'Dashboard', 'SettingsView', 'StaffManager',
      // Inbox bloki — appointments uchun (data_source orqali)
      'InboxList',
      // Appointment-spetsifik (3.B)
      'CalendarView', 'ServiceCRUD', 'SpecialistCRUD',
      'AppointmentCard', 'WalkInQueue',
      // Hisobot va boshqaruv
      'ReportsView', 'NotificationsBroadcast', 'EventsLog',
      // Mijoz — uchrashuv biznesida foydali (qaytaruvchi mijozlar)
      'CustomerList', 'CustomerProfile', 'OrdersHistoryBlock',
    ],

    component_configs: {
      Dashboard: {
        stat_cards: ['todays_appointments', 'in_progress', 'revenue', 'specialists_busy'],
      },

      InboxList: {
        // Generic InboxList'ni appointments'ga ulash
        data_source: { service: 'appointment', method: 'listAppointments' },
        status_kind: 'appointment',
        status_field: 'status',
        created_event: 'appointment.created',
        status_changed_event: 'appointment.status_changed',
        item_card: 'AppointmentCard',
        statuses: ['scheduled', 'in_progress', 'completed', 'cancelled', 'no_show'],
        default_status: 'scheduled',
        page_size: 20,
        terms: { items: 'Uchrashuvlar', item: 'Uchrashuv' },
      },

      AppointmentCard: {
        primary_actions: {
          scheduled:   ['in_progress'],
          in_progress: ['completed'],
        },
      },

      CalendarView: {
        terms: { calendar: 'Kun jadvali' },
      },

      ServiceCRUD: {
        terms: { services: 'Xizmatlar', item: 'Xizmat' },
      },

      SpecialistCRUD: {
        terms: { specialists: 'Mutaxassislar' },
      },

      WalkInQueue: {
        terms: { queue: 'Navbat' },
      },

      CustomerList: { terms: { customers: 'Mijozlar' } },
      CustomerProfile: { extensions: ['orders_history'] },

      ReportsView: {
        reports: ['daily_sales', 'top_services', 'specialist_load', 'customer_summary'],
      },

      StaffManager: { terms: { staff: 'Xodimlar' } },
      SettingsView: { sections: ['profile', 'pin', 'notifications', 'theme', 'about'] },
    },

    routes: [
      // BottomNav (5 ta) — kun jadvali oldinda, eng tez-tez kerakli
      { key: 'dashboard',    component: 'Dashboard',     icon: '🏠', label: 'Bosh',          permission: 'dashboard.view' },
      { key: 'calendar',     component: 'CalendarView',  icon: '📅', label: 'Jadval',         permission: 'appointments.view' },
      { key: 'appointments', component: 'InboxList',     icon: '📋', label: 'Uchrashuvlar',   permission: 'appointments.view' },
      { key: 'services',     component: 'ServiceCRUD',   icon: '✂️', label: 'Xizmatlar',      permission: 'appointment.services.manage' },
      { key: 'settings',     component: 'SettingsView',  icon: '⚙️', label: 'Sozlama' },
      // Secondary:
      { key: 'specialists',  component: 'SpecialistCRUD',         icon: '👨‍⚕️', label: 'Mutaxassislar',  permission: 'appointment.specialists.manage', secondary: true },
      { key: 'walkin',       component: 'WalkInQueue',            icon: '👥', label: 'Navbat',          permission: 'appointment.walkin.manage', secondary: true },
      { key: 'customers',    component: 'CustomerList',           icon: '👤', label: 'Mijozlar',        permission: 'customers.view',  secondary: true },
      { key: 'reports',      component: 'ReportsView',            icon: '📊', label: 'Hisobotlar',      permission: 'reports.view',    secondary: true },
      { key: 'broadcast',    component: 'NotificationsBroadcast', icon: '📢', label: 'Xabar yuborish',  permission: 'broadcast.send',  secondary: true },
      { key: 'staff',        component: 'StaffManager',           icon: '🧑‍💼', label: 'Xodimlar',       permission: 'staff.view',      secondary: true },
      { key: 'audit',        component: 'EventsLog',              icon: '📋', label: 'Audit jurnali',  permission: 'audit.view',      secondary: true },
    ],
  };
})();
