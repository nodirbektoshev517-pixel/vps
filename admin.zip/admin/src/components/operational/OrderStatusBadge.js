/**
 * OrderStatusBadge.js — buyurtma statusi badge.
 *
 * Yagona vazifa: status kalitini olib, Labels.formatStatus orqali
 * label va badge variant'ni topadi va `.badge` primitivini chiqaradi.
 *
 * Adapter `terms` config bilan label'ni override qila oladi:
 *   OrderCard: { terms: { delivered: 'Yetib bordi' } }
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { computed } = Vue;
  const { Labels } = window.Adminbot.Core;

  window.Adminbot.Components.OrderStatusBadge = {
    name: 'OrderStatusBadge',
    props: {
      status: { type: String, required: true },
      terms:  { type: Object, default: () => ({}) },
      kind:   { type: String, default: 'order' },   // order | reservation
    },
    setup(props) {
      const info = computed(() => Labels.formatStatus(props.status, props.kind, props.terms));
      return { info };
    },
    template: `
      <span
        class="badge"
        :class="'badge--' + info.badge"
        :data-status="status"
      >{{ info.label }}</span>
    `,
  };
})();
