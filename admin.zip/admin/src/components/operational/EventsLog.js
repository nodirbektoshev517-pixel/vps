/**
 * EventsLog.js — audit log ko'rinishi.
 *
 * Backend audit log immutable. Frontend faqat o'qiydi va ko'rsatadi.
 * Filter: event type (broadcast.sent, order.cancelled, h.k.).
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils } = window.Adminbot.Core;

  const TYPE_ICONS = {
    'order.status_changed': '🔁',
    'order.cancelled':      '❌',
    'product.created':      '➕',
    'product.updated':      '✏️',
    'category.deleted':     '🗑',
    'staff.created':        '👤',
    'broadcast.sent':       '📢',
    'settings.changed':     '⚙️',
    'login.success':        '🔓',
  };

  window.Adminbot.Components.EventsLog = {
    name: 'EventsLog',
    setup() {
      const items = ref([]);
      const loading = ref(true);
      const loadingMore = ref(false);
      const cursor = ref(null);
      const hasMore = ref(false);
      const error = ref(null);
      const typeFilter = ref('all');
      const seenIds = new Set();

      const types = computed(() => ['all', ...Object.keys(TYPE_ICONS)]);

      async function load(append = false) {
        if (append) loadingMore.value = true;
        else loading.value = true;
        try {
          const r = await Services.audit.list({
            type: typeFilter.value,
            cursor: append ? cursor.value : null,
            page_size: 20,
          });
          const newItems = (r && r.items) || [];
          if (append) {
            const toAdd = newItems.filter(it => !seenIds.has(it.id));
            toAdd.forEach(it => seenIds.add(it.id));
            items.value = items.value.concat(toAdd);
          } else {
            seenIds.clear();
            newItems.forEach(it => seenIds.add(it.id));
            items.value = newItems;
          }
          cursor.value = r && r.next_cursor;
          hasMore.value = !!(r && r.has_more);
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; loadingMore.value = false; }
      }

      function changeFilter(t) {
        if (t === typeFilter.value) return;
        typeFilter.value = t;
        load();
      }

      function iconFor(t) { return TYPE_ICONS[t] || '📝'; }
      function shortType(t) {
        return t === 'all' ? 'Hammasi' : t.split('.').slice(-1)[0];
      }

      onMounted(load);
      return {
        items, loading, loadingMore, hasMore, error, typeFilter, types,
        changeFilter, iconFor, shortType,
        relativeTime: Utils.relativeTime,
        loadMore: () => load(true),
      };
    },
    template: `
      <div class="page" data-component="events-log">
        <h1 class="heading">Audit jurnali</h1>
        <div class="subheading">Tizimda nima sodir bo'lganini ko'ring.</div>

        <div class="cluster" style="overflow-x: auto;" data-component="audit-filters">
          <button
            v-for="t in types" :key="t"
            type="button"
            class="chip"
            :class="{ 'chip--active': typeFilter === t }"
            :data-type-filter="t"
            @click="changeFilter(t)"
          >{{ shortType(t) }}</button>
        </div>

        <div v-if="loading && !items.length" class="list">
          <div v-for="i in 5" :key="i" class="list__row">
            <div class="skeleton" style="width: 32px; height: 32px;"></div>
            <div class="list__main">
              <div class="skeleton" style="width: 70%; height: 12px;"></div>
              <div class="skeleton" style="width: 40%; height: 10px; margin-top: 6px;"></div>
            </div>
          </div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else-if="items.length" class="list">
          <div
            v-for="item in items" :key="item.id"
            class="list__row"
            :data-audit-id="item.id"
          >
            <div class="list__icon">{{ iconFor(item.type) }}</div>
            <div class="list__main">
              <div class="list__title">{{ item.summary }}</div>
              <div class="list__subtitle">{{ item.actor_name }} • {{ relativeTime(item.created_at) }}</div>
            </div>
          </div>
          <button
            v-if="hasMore"
            class="btn btn--secondary btn--block"
            data-action="load-more-audit"
            :disabled="loadingMore"
            @click="loadMore"
          >{{ loadingMore ? 'Yuklanmoqda...' : 'Yana yuklash' }}</button>
        </div>

        <div v-else class="empty">
          <div class="empty__icon">📋</div>
          <div class="empty__title">Jurnal bo'sh</div>
        </div>
      </div>
    `,
  };
})();
