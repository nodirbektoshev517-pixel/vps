/**
 * TechBriefViewer.js — Buyurtma uchun texnik topshiriqni ko'rish.
 *
 * Custom production'da mijoz nima xohlayotgani, o'lchamlari, materiallari
 * brief deb yoziladi. Bu komponent shu briefni ko'rsatadi va stage'ni
 * boshqarish uchun StageAdvancer'ni ichida ishlatadi.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted, watch } = Vue;
  const { Services, Utils, Labels, Composables } = window.Adminbot.Core;

  window.Adminbot.Components.TechBriefViewer = {
    name: 'TechBriefViewer',
    props: { briefId: { type: String, default: null } },
    emits: ['back', 'updated'],
    setup(props, { emit }) {
      const brief = ref(null);
      const loading = ref(true);
      const error = ref(null);

      async function load() {
        if (!props.briefId) return;
        loading.value = true;
        try {
          brief.value = await Services.production.getBrief(props.briefId);
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; }
      }

      function stageInfo(s) { return Labels.formatStatus(s, 'production'); }

      // Real-time
      const { subscribe } = Composables.useEvents();
      function onStageChanged(ev) {
        const p = ev && ev.payload;
        if (!p || !p.id) return;
        if (brief.value && brief.value.id === p.id) {
          brief.value = { ...brief.value, ...p };
        }
      }

      onMounted(() => {
        load();
        subscribe('brief.stage_changed', onStageChanged);
      });
      watch(() => props.briefId, load);

      function onUpdated(updated) {
        if (updated && brief.value && updated.id === brief.value.id) {
          brief.value = { ...brief.value, ...updated };
          emit('updated', updated);
        }
      }

      return {
        brief, loading, error, stageInfo, onUpdated,
        back: () => emit('back'),
        formatMoney: Utils.formatMoney,
        formatDate: (d) => Utils.formatDate(d, { time: false }),
        relativeTime: Utils.relativeTime,
      };
    },
    template: `
      <div class="page" data-component="tech-brief-viewer">
        <div class="row">
          <button type="button" class="btn btn--ghost btn--icon btn--sm"
            data-action="back" @click="back" aria-label="Orqaga">←</button>
          <h1 class="heading">Topshiriq</h1>
        </div>

        <div v-if="loading && !brief" class="card">
          <div class="skeleton" style="width: 60%; height: 18px;"></div>
          <div class="skeleton" style="width: 80%; height: 12px; margin-top: 12px;"></div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else-if="brief" class="stack" :data-brief-id="brief.id">
          <div class="card">
            <div class="cluster cluster--between">
              <div class="stack stack--tight">
                <div class="text-medium" style="font-size: var(--text-lg);">#{{ brief.number }}</div>
                <div class="text-muted text-sm">{{ brief.product_type }}</div>
              </div>
              <span class="badge" :class="'badge--' + stageInfo(brief.stage).badge" :data-stage="brief.stage">
                {{ stageInfo(brief.stage).label }}
              </span>
            </div>

            <div class="stack stack--tight" style="margin-top: var(--space-3);">
              <div class="row">
                <span style="font-size: var(--icon-md)">👤</span>
                <span class="text-sm">{{ brief.customer_name }}</span>
              </div>
              <div class="row">
                <span style="font-size: var(--icon-md)">📞</span>
                <span class="text-sm">{{ brief.customer_phone }}</span>
              </div>
              <div class="row" v-if="brief.target_delivery_at">
                <span style="font-size: var(--icon-md)">📅</span>
                <span class="text-sm">Yetkazib berish: {{ formatDate(brief.target_delivery_at) }}</span>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="text-medium">Tavsifi</div>
            <div class="text-sm" style="margin-top: var(--space-2);">{{ brief.description }}</div>
          </div>

          <div class="card">
            <div class="cluster cluster--between">
              <div>
                <div class="text-muted text-sm">Taklif qilingan narx</div>
                <div class="text-bold">
                  {{ brief.proposed_price ? formatMoney(brief.proposed_price) : '—' }}
                </div>
              </div>
              <div>
                <div class="text-muted text-sm">Kelishilgan narx</div>
                <div class="text-bold">
                  {{ brief.agreed_price ? formatMoney(brief.agreed_price) : '—' }}
                </div>
              </div>
            </div>
          </div>

          <!-- Stage advance -->
          <StageAdvancer :brief="brief" @updated="onUpdated" />

          <!-- Proposal sender (faqat brief_review bosqichida) -->
          <PriceProposalSender v-if="brief.stage === 'brief_review'"
            :brief="brief" @updated="onUpdated" />
        </div>
      </div>
    `,
  };
})();
