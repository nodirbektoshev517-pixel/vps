/**
 * BanquetManager.js — banket/voqea zakazlarini boshqarish.
 *
 * Banket = ko'p stolli voqea (to'y, korporativ, h.k.) menyu va aniq vaqt bilan.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils, Permissions, Actions, Labels, UI } = window.Adminbot.Core;

  window.Adminbot.Components.BanquetManager = {
    name: 'BanquetManager',
    setup() {
      const items = ref([]);
      const halls = ref([]);
      const loading = ref(true);
      const error = ref(null);
      const editing = ref(null);
      const canManage = computed(() => Permissions.can('restaurant.banquets.manage'));

      async function loadHalls() {
        try {
          const r = await Services.restaurant.listTables();
          halls.value = (r && r.halls) || [];
        } catch (e) {}
      }

      async function load() {
        loading.value = true;
        try {
          const r = await Services.restaurant.listBanquets();
          items.value = (r && r.items) || [];
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; }
      }

      function startCreate() {
        if (!Permissions.require('restaurant.banquets.manage', 'Banket qo\'shish')) return;
        editing.value = {
          name: '', date: new Date().toISOString().slice(0, 16),
          guest_count: 0, hall_id: halls.value[0] && halls.value[0].id || '',
          menu_summary: '', contact_phone: '',
        };
      }
      function startEdit(b) {
        if (!Permissions.require('restaurant.banquets.manage', 'Banket tahrirlash')) return;
        editing.value = { ...b, date: b.date && b.date.slice(0, 16) };
      }
      function cancelEdit() { editing.value = null; }

      async function saveEdit() {
        const d = editing.value;
        if (!d || !d.name) { UI.toast('Banket nomi majburiy', { type: 'warn' }); return; }
        const isNew = !d.id;
        const payload = { ...d, date: new Date(d.date).toISOString() };
        await Actions.runAction({
          permission: 'restaurant.banquets.manage',
          action: () => isNew
            ? Services.restaurant.createBanquet(payload)
            : Services.restaurant.updateBanquet(d.id, payload),
          onSuccess: async () => { editing.value = null; await load(); },
          successMessage: isNew ? 'Qo\'shildi' : 'Yangilandi',
        });
      }

      async function remove(b) {
        await Actions.runAction({
          permission: 'restaurant.banquets.manage',
          confirm: {
            title: 'O\'chirishni tasdiqlang',
            body: `"${b.name}" o'chirilsinmi?`,
            confirmText: 'O\'chirish', cancelText: 'Bekor',
          },
          action: () => Services.restaurant.deleteBanquet(b.id),
          onSuccess: async () => { await load(); },
          successMessage: 'O\'chirildi',
        });
      }

      function hallName(id) {
        const h = halls.value.find(x => x.id === id);
        return h ? h.name : id;
      }
      function statusInfo(s) { return Labels.formatStatus(s, 'reservation'); }

      onMounted(async () => { await loadHalls(); await load(); });

      return {
        items, halls, loading, error, editing, canManage,
        startCreate, startEdit, cancelEdit, saveEdit, remove,
        hallName, statusInfo,
        formatDate: (d) => Utils.formatDate(d, { time: true }),
      };
    },
    template: `
      <div class="page" data-component="banquet-manager">
        <div class="cluster cluster--between">
          <h1 class="heading">Banketlar</h1>
          <button
            v-if="canManage"
            type="button"
            class="btn btn--primary btn--sm"
            data-action="add-banquet"
            @click="startCreate"
          >+ Yangi</button>
        </div>

        <div v-if="loading && !items.length" class="stack">
          <div v-for="i in 2" :key="i" class="card">
            <div class="skeleton" style="width: 60%; height: 16px;"></div>
            <div class="skeleton" style="width: 40%; height: 12px; margin-top: 8px;"></div>
          </div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else-if="items.length" class="stack">
          <div
            v-for="b in items" :key="b.id"
            class="card"
            :data-banquet-id="b.id"
          >
            <div class="cluster cluster--between">
              <div class="stack stack--tight">
                <div class="text-medium" style="font-size: var(--text-lg);">{{ b.name }}</div>
                <div class="text-muted text-sm">{{ formatDate(b.date) }}</div>
              </div>
              <span class="badge" :class="'badge--' + statusInfo(b.status).badge">
                {{ statusInfo(b.status).label }}
              </span>
            </div>
            <div class="stack stack--tight" style="margin-top: var(--space-3);">
              <div class="row">
                <span style="font-size: var(--icon-md)">👥</span>
                <span class="text-sm">{{ b.guest_count }} mehmon • {{ hallName(b.hall_id) }}</span>
              </div>
              <div v-if="b.menu_summary" class="row">
                <span style="font-size: var(--icon-md)">🍽️</span>
                <span class="text-sm">{{ b.menu_summary }}</span>
              </div>
            </div>
            <div v-if="canManage" class="cluster cluster--end" style="margin-top: var(--space-3);">
              <button class="btn btn--ghost btn--sm" :data-action="'edit-bnq-' + b.id" @click="startEdit(b)">Tahrirlash</button>
              <button class="btn btn--ghost btn--sm text-danger" :data-action="'del-bnq-' + b.id" @click="remove(b)">O'chirish</button>
            </div>
          </div>
        </div>

        <div v-else class="empty">
          <div class="empty__icon">🎉</div>
          <div class="empty__title">Banket yo'q</div>
        </div>

        <div v-if="editing" class="overlay" @click.self="cancelEdit" data-component="banquet-form">
          <div class="sheet">
            <div class="sheet__handle"></div>
            <div class="sheet__header">
              <div class="sheet__title">{{ editing.id ? 'Tahrirlash' : 'Yangi banket' }}</div>
            </div>
            <div class="stack">
              <div class="field">
                <label class="field__label">Nomi</label>
                <input type="text" v-model="editing.name" data-field="bnq-name" />
              </div>
              <div class="field">
                <label class="field__label">Sana va vaqt</label>
                <input type="datetime-local" v-model="editing.date" data-field="bnq-date" />
              </div>
              <div class="field">
                <label class="field__label">Mehmonlar soni</label>
                <input type="number" v-model.number="editing.guest_count" data-field="bnq-guests" />
              </div>
              <div class="field">
                <label class="field__label">Zal</label>
                <select v-model="editing.hall_id" data-field="bnq-hall">
                  <option v-for="h in halls" :key="h.id" :value="h.id">{{ h.name }}</option>
                </select>
              </div>
              <div class="field">
                <label class="field__label">Menyu</label>
                <input type="text" v-model="editing.menu_summary" placeholder="Plov, kabob, salatlar" data-field="bnq-menu" />
              </div>
              <div class="field">
                <label class="field__label">Aloqa telefoni</label>
                <input type="tel" v-model="editing.contact_phone" data-field="bnq-phone" />
              </div>
              <div class="cluster cluster--end">
                <button class="btn btn--secondary" @click="cancelEdit">Bekor</button>
                <button class="btn btn--primary" data-action="save-banquet" @click="saveEdit">Saqlash</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    `,
  };
})();
