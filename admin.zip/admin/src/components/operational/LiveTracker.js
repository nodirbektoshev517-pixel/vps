/**
 * LiveTracker.js — Kuryer pozitsiyalarini push orqali kuzatuv.
 *
 * MUHIM: polling YO'Q. Faqat `courier.location_updated` event'iga
 * subscribe — backend telegram bot orqali kuryerdan keladi.
 *
 * Map<courier_id, {lat, lng, last_seen}> da saqlanadi va ro'yxat sifatida
 * ko'rsatiladi (real xarita kutubxonasi yo'q — sodda).
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils, Labels, Composables } = window.Adminbot.Core;

  window.Adminbot.Components.LiveTracker = {
    name: 'LiveTracker',
    setup() {
      const couriers = ref([]);
      const loading = ref(true);
      const error = ref(null);
      // Map kuryer_id -> {lat, lng, last_seen_at}
      const positions = ref(new Map());
      // Idempotency uchun ko'rilgan event id'lari
      const seenEventIds = new Set();

      async function load() {
        loading.value = true;
        try {
          const r = await Services.courier.listCouriers();
          couriers.value = (r && r.items) || [];
          // Boshlang'ich pozitsiyalar
          const init = new Map();
          for (const c of couriers.value) {
            if (c.current_lat != null && c.current_lng != null) {
              init.set(c.id, {
                lat: c.current_lat,
                lng: c.current_lng,
                last_seen_at: c.last_seen_at,
              });
            }
          }
          positions.value = init;
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; }
      }

      // Faqat onlayn kuryerlar (offline'lar — pozitsiyasi yo'q)
      const trackedCouriers = computed(() => {
        return couriers.value
          .filter(c => c.status !== 'offline')
          .map(c => {
            const pos = positions.value.get(c.id);
            return {
              ...c,
              lat: pos ? pos.lat : c.current_lat,
              lng: pos ? pos.lng : c.current_lng,
              last_seen_at: pos ? pos.last_seen_at : c.last_seen_at,
            };
          });
      });

      function statusInfo(s) { return Labels.formatStatus(s, 'courier'); }
      const fullName = (c) => `${c.first_name} ${c.last_name || ''}`.trim();
      const initials = Utils.initials;

      function formatCoords(lat, lng) {
        if (lat == null || lng == null) return '—';
        return `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
      }

      // Real-time event handler — idempotent
      const { subscribe } = Composables.useEvents();
      function onLocationUpdated(ev) {
        if (!ev || !ev.id) return;
        if (seenEventIds.has(ev.id)) return;       // duplikat o'tkazib yuborish
        seenEventIds.add(ev.id);
        const p = ev.payload || {};
        if (!p.id) return;
        // Pozitsiyani yangilash (yangi Map — reaktivlik uchun)
        const next = new Map(positions.value);
        next.set(p.id, {
          lat: p.lat,
          lng: p.lng,
          last_seen_at: p.last_seen_at || new Date().toISOString(),
        });
        positions.value = next;
      }
      function onStatusChanged(ev) {
        const p = ev && ev.payload;
        if (!p || !p.id) return;
        const idx = couriers.value.findIndex(c => c.id === p.id);
        if (idx >= 0) couriers.value[idx] = { ...couriers.value[idx], ...p };
      }

      onMounted(() => {
        load();
        subscribe('courier.location_updated', onLocationUpdated);
        subscribe('courier.status_changed', onStatusChanged);
      });

      return {
        trackedCouriers, loading, error, statusInfo, fullName, initials,
        formatCoords, relativeTime: Utils.relativeTime,
      };
    },
    template: `
      <div class="page" data-component="live-tracker">
        <h1 class="heading">Kuryer kuzatuvi</h1>
        <div class="text-muted text-sm" style="margin-bottom: var(--space-3);">
          Pozitsiya — kuryer Telegram bot orqali yuborgan oxirgi nuqta. Yangilanish push orqali.
        </div>

        <div v-if="loading && !trackedCouriers.length" class="list">
          <div v-for="i in 3" :key="i" class="list__row">
            <div class="skeleton" style="width: 40px; height: 40px; border-radius: 50%;"></div>
            <div class="list__main">
              <div class="skeleton" style="width: 60%; height: 14px;"></div>
            </div>
          </div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else-if="trackedCouriers.length" class="list" data-component="tracker-positions">
          <div
            v-for="c in trackedCouriers" :key="c.id"
            class="list__row"
            :data-courier-id="c.id"
            :data-lat="c.lat"
            :data-lng="c.lng"
          >
            <div class="avatar">{{ initials(c) }}</div>
            <div class="list__main">
              <div class="list__title">{{ fullName(c) }}</div>
              <div class="list__subtitle">
                📍 {{ formatCoords(c.lat, c.lng) }}
                <span v-if="c.last_seen_at"> • {{ relativeTime(c.last_seen_at) }}</span>
              </div>
            </div>
            <span class="badge" :class="'badge--' + statusInfo(c.status).badge">
              {{ statusInfo(c.status).label }}
            </span>
          </div>
        </div>

        <div v-else class="empty">
          <div class="empty__icon">🛰️</div>
          <div class="empty__title">Onlayn kuryer yo'q</div>
        </div>
      </div>
    `,
  };
})();
