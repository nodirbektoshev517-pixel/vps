/**
 * InboxList.js — universal buyurtmalar ro'yxati.
 *
 * Performance qoidalari (§7):
 *   - Birinchi yuklash: page_size (sukut 20)
 *   - Filter — server-side (cursor reset)
 *   - "Yana yuklash" — cursor pagination
 *   - Real-time: order.created → ro'yxat boshiga prepend (idempotent)
 *   - Status update event → mavjud item'ni yangilash
 *   - Template ichida og'ir filter/sort YO'Q — computed ishlatamiz
 *   - Event listener'lar auto-cleanup (Composables.useEvents)
 *
 * Biznes turini BILMAYDI. Adapter:
 *   - statuses: filter chip'lar
 *   - default_status: boshlang'ich filter
 *   - page_size
 *   - item_card: qaysi kartochka komponenti (default 'OrderCard')
 *   - data_source: { service, method } — qaysi service'ni chaqirish (default inbox.list)
 *   - status_field: 'status' yoki 'stage' (default 'status')
 *   - status_kind: Labels lookup uchun (default 'order'; reservation/appointment/production)
 *   - created_event: real-time push event nomi (default 'order.created')
 *   - status_changed_event: status update event (default 'order.status_changed')
 *   - terms: "Buyurtma" → "Bron" h.k.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted, watch } = Vue;
  const { Services, Utils, Cache, Labels, Composables, I18n } = window.Adminbot.Core;

  window.Adminbot.Components.InboxList = {
    name: 'InboxList',
    props: {
      config: { type: Object, default: () => ({}) },
    },
    setup(props) {
      // === Konfiguratsiya ===
      const statuses = computed(() => {
        const list = (props.config && props.config.statuses) || [];
        return ['all', ...list];
      });
      const itemCardName = computed(() =>
        (props.config && props.config.item_card) || 'OrderCard'
      );
      const pageSize = (props.config && props.config.page_size) || 20;
      const defaultStatus = (props.config && props.config.default_status) || 'all';
      const terms = computed(() => (props.config && props.config.terms) || {});

      // Generic data_source (sukut: Services.inbox.list)
      const dataSource = computed(() =>
        (props.config && props.config.data_source) || { service: 'inbox', method: 'list' }
      );
      const statusField = computed(() =>
        (props.config && props.config.status_field) || 'status'
      );
      const statusKind = computed(() =>
        (props.config && props.config.status_kind) || 'order'
      );
      const createdEvent = computed(() =>
        (props.config && props.config.created_event) || 'order.created'
      );
      const statusChangedEvent = computed(() =>
        (props.config && props.config.status_changed_event) || 'order.status_changed'
      );

      const titleText = computed(() => I18n.plural(terms.value, 'items', 'Buyurtmalar'));

      // Child item card uchun adapter config'ini olish
      // (masalan adapter.component_configs.OrderCard — extensions, primary_actions)
      const childConfig = computed(() => {
        const adapter = window.Adminbot.Runtime.adapter;
        if (!adapter) return {};
        const name = itemCardName.value;
        return (adapter.component_configs && adapter.component_configs[name]) || {};
      });

      // === State ===
      const currentStatus = ref(defaultStatus);
      const items = ref([]);              // hozir ko'rsatilayotgan ro'yxat
      const cursor = ref(null);            // keyingi sahifa cursor
      const hasMore = ref(false);
      const loading = ref(false);
      const loadingMore = ref(false);
      const error = ref(null);

      // Idempotency uchun ko'rilgan ID'lar
      const seenIds = new Set();

      function statusInfo(key) {
        if (key === 'all') return { label: 'Hammasi', badge: 'neutral' };
        return Labels.formatStatus(key, statusKind.value, terms.value);
      }

      // === Yuklash ===
      async function load(opts = {}) {
        const { append = false } = opts;
        if (append) loadingMore.value = true;
        else loading.value = true;
        error.value = null;
        try {
          const ds = dataSource.value;
          const svc = Services[ds.service];
          const method = svc && svc[ds.method];
          if (typeof method !== 'function') {
            throw new Error(`Service topilmadi: ${ds.service}.${ds.method}`);
          }
          // Status field — 'status' yoki 'stage'
          const params = {
            cursor: append ? cursor.value : null,
            page_size: pageSize,
          };
          params[statusField.value] = currentStatus.value;
          const resp = await method.call(svc, params);
          const newItems = (resp && resp.items) || [];
          if (append) {
            // Idempotent qo'shish
            const toAdd = newItems.filter(it => !seenIds.has(it.id));
            toAdd.forEach(it => seenIds.add(it.id));
            items.value = items.value.concat(toAdd);
          } else {
            // Reset
            seenIds.clear();
            newItems.forEach(it => seenIds.add(it.id));
            items.value = newItems;
          }
          cursor.value = resp && resp.next_cursor;
          hasMore.value = !!(resp && resp.has_more);
        } catch (e) {
          error.value = Utils.errorText(e);
        } finally {
          loading.value = false;
          loadingMore.value = false;
        }
      }

      function changeFilter(status) {
        if (status === currentStatus.value) return;
        currentStatus.value = status;
        // Cache'ni invalidate qilamiz (Bosqich 2.2'da Cache.fetch ishlatsak)
        Cache.invalidate('inbox:');
        load({ append: false });
      }

      // === Real-time event handler'lar ===
      // §7: idempotent — bir event ikki marta kelsa duplikat qo'shilmaydi
      function onItemCreated(event) {
        const item = event && event.payload;
        if (!item || !item.id) return;
        if (seenIds.has(item.id)) return;     // duplikat
        // Faqat agar current filter mos kelsa, ro'yxatga qo'shamiz
        const itemStatus = item[statusField.value];
        if (currentStatus.value !== 'all' && currentStatus.value !== itemStatus) {
          return;
        }
        seenIds.add(item.id);
        items.value = [item, ...items.value];
      }

      function onItemStatusChanged(event) {
        const p = event && event.payload;
        if (!p || !p.id) return;
        const idx = items.value.findIndex(it => it.id === p.id);
        if (idx < 0) return;
        const newStatus = p[statusField.value];
        // Yangi status filterda yo'q bo'lsa, item'ni ro'yxatdan olib tashlaymiz
        if (currentStatus.value !== 'all' && newStatus !== currentStatus.value) {
          items.value = items.value.filter(it => it.id !== p.id);
          seenIds.delete(p.id);
          return;
        }
        // Aks holda yangilash
        const updated = { ...items.value[idx], ...p };
        items.value = items.value.slice(0, idx).concat([updated]).concat(items.value.slice(idx + 1));
      }

      // ItemCard `updated` event'ini (lokal action javobini) ham qabul qilamiz
      function onItemUpdated(updated) {
        if (!updated || !updated.id) return;
        const idx = items.value.findIndex(it => it.id === updated.id);
        if (idx < 0) return;
        const newStatus = updated[statusField.value];
        if (currentStatus.value !== 'all' && newStatus !== currentStatus.value) {
          items.value = items.value.filter(it => it.id !== updated.id);
          seenIds.delete(updated.id);
          return;
        }
        items.value = items.value.slice(0, idx).concat([updated]).concat(items.value.slice(idx + 1));
      }

      // === Setup event listener'lari (auto-cleanup) ===
      const { subscribe } = Composables.useEvents();

      onMounted(() => {
        load();
        subscribe(createdEvent.value, onItemCreated);
        subscribe(statusChangedEvent.value, onItemStatusChanged);
      });

      return {
        statuses, currentStatus, items, cursor, hasMore,
        loading, loadingMore, error,
        itemCardName, titleText, terms, childConfig,
        statusInfo, changeFilter, loadMore: () => load({ append: true }),
        onItemUpdated,
      };
    },
    template: `
      <div class="page">
        <h1 class="heading">{{ titleText }}</h1>

        <!-- Status filter chip'lar -->
        <div class="cluster" data-component="inbox-filters">
          <button
            v-for="s in statuses" :key="s"
            type="button"
            class="chip"
            :class="{ 'chip--active': currentStatus === s }"
            :data-status-filter="s"
            @click="changeFilter(s)"
          >{{ statusInfo(s).label }}</button>
        </div>

        <!-- Skeleton (birinchi yuklash) -->
        <div v-if="loading && !items.length" class="stack">
          <div v-for="i in 3" :key="i" class="card">
            <div class="skeleton" style="height: 18px; width: 40%;"></div>
            <div class="skeleton" style="height: 12px; width: 60%; margin-top: 8px;"></div>
            <div class="skeleton" style="height: 12px; width: 80%; margin-top: 12px;"></div>
          </div>
        </div>

        <!-- Xato -->
        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <!-- Ro'yxat -->
        <div v-else-if="items.length" class="stack" data-component="inbox-list">
          <component
            v-for="order in items"
            :key="order.id"
            :is="itemCardName"
            :order="order"
            :config="childConfig"
            @updated="onItemUpdated"
          />
          <button
            v-if="hasMore"
            type="button"
            class="btn btn--secondary btn--block"
            data-action="load-more"
            :disabled="loadingMore"
            @click="loadMore"
          >{{ loadingMore ? 'Yuklanmoqda...' : 'Yana yuklash' }}</button>
        </div>

        <!-- Bo'sh holat -->
        <div v-else class="empty">
          <div class="empty__icon">📭</div>
          <div class="empty__title">{{ titleText }} yo'q</div>
          <div class="empty__hint">
            {{ currentStatus === 'all' ? 'Hali buyurtma kelmagan.' : 'Bu filtrda hech narsa yo\\'q.' }}
          </div>
        </div>
      </div>
    `,
  };
})();
