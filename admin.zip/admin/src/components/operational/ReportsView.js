/**
 * ReportsView.js — hisobotlar.
 *
 * Adapter `ReportsView.reports: ['daily_sales', 'top_products', ...]` deklare qiladi.
 * Komponent har bittasini Services.reports.fetch(key) bilan oladi va render qiladi.
 *
 * Universal — chart kutubxonasi shart emas (sodda ro'yxat + total).
 * Bosqich 3'da Recharts/Chart.js bilan kengaytirilishi mumkin.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils } = window.Adminbot.Core;

  window.Adminbot.Components.ReportsView = {
    name: 'ReportsView',
    props: { config: { type: Object, default: () => ({}) } },
    setup(props) {
      const reports = ref([]);
      const loading = ref(true);
      const error = ref(null);

      const wantKeys = computed(() => (props.config && props.config.reports) || ['daily_sales']);

      async function load() {
        loading.value = true;
        try {
          const results = await Promise.allSettled(
            wantKeys.value.map(k => Services.reports.fetch(k))
          );
          reports.value = results
            .map((r, i) => r.status === 'fulfilled' ? r.value : null)
            .filter(Boolean);
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; }
      }

      function fmtValue(row, defaultFormat) {
        const f = row.format || defaultFormat;
        if (f === 'money') return Utils.formatMoney(row.value);
        return new Intl.NumberFormat('uz-UZ').format(row.value);
      }

      onMounted(load);
      return { reports, loading, error, fmtValue, Utils };
    },
    template: `
      <div class="page">
        <h1 class="heading">Hisobotlar</h1>

        <div v-if="loading && !reports.length" class="stack">
          <div v-for="i in 2" :key="i" class="card">
            <div class="skeleton" style="width: 40%; height: 18px;"></div>
            <div class="skeleton" style="width: 70%; height: 12px; margin-top: 12px;"></div>
            <div class="skeleton" style="width: 70%; height: 12px; margin-top: 8px;"></div>
          </div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else-if="reports.length" class="stack" data-component="reports-list">
          <div
            v-for="r in reports" :key="r.key"
            class="card"
            :data-report-key="r.key"
          >
            <div class="cluster cluster--between">
              <div class="stack stack--tight">
                <div class="text-medium" style="font-size: var(--text-lg);">{{ r.title }}</div>
                <div class="text-muted text-sm">{{ r.period }}</div>
              </div>
              <div v-if="r.total != null" class="text-bold">{{ fmtValue({ value: r.total }, r.format) }}</div>
            </div>
            <div class="stack stack--tight" style="margin-top: var(--space-3);">
              <div
                v-for="row in r.rows" :key="row.label"
                class="cluster cluster--between"
              >
                <div class="text-sm">{{ row.label }}</div>
                <div class="text-sm text-medium">{{ fmtValue(row, r.format) }}</div>
              </div>
            </div>
          </div>
        </div>

        <div v-else class="empty">
          <div class="empty__icon">📊</div>
          <div class="empty__title">Hisobot yo'q</div>
        </div>
      </div>
    `,
  };
})();
