/**
 * InviteCodeGenerator.js — Yangi do'konlarni ro'yxatdan o'tkazish uchun
 * taklif kodlari yaratish.
 *
 * Kod tier_preset va credit_limit_preset bilan keladi — do'kon ro'yxatdan
 * o'tib, owner tasdiqlasa, do'kon shu preset bilan ochiladi.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils, Permissions, Actions, UI } = window.Adminbot.Core;

  const TIERS = [
    { value: 'bronze',   label: 'Bronza' },
    { value: 'silver',   label: 'Kumush' },
    { value: 'gold',     label: 'Oltin' },
    { value: 'platinum', label: 'Platina' },
  ];

  window.Adminbot.Components.InviteCodeGenerator = {
    name: 'InviteCodeGenerator',
    setup() {
      const invites = ref([]);
      const loading = ref(true);
      const error = ref(null);
      const editing = ref(null);
      const canManage = computed(() => Permissions.can('supplier.invite.manage'));

      async function load() {
        loading.value = true;
        try {
          const r = await Services.supplier.listInvites();
          invites.value = (r && r.items) || [];
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; }
      }

      function startCreate() {
        if (!Permissions.require('supplier.invite.manage', 'Invite yaratish')) return;
        editing.value = { tier_preset: 'bronze', credit_limit_preset: 2_000_000 };
      }
      function cancelEdit() { editing.value = null; }

      async function saveInvite() {
        await Actions.runAction({
          permission: 'supplier.invite.manage',
          action: () => Services.supplier.createInvite(editing.value),
          onSuccess: async () => { editing.value = null; await load(); },
          successMessage: 'Invite yaratildi',
        });
      }

      async function removeInvite(inv) {
        await Actions.runAction({
          permission: 'supplier.invite.manage',
          confirm: {
            title: 'O\'chirishni tasdiqlang',
            body: `Kod "${inv.code}" o'chirilsinmi?`,
            confirmText: 'O\'chirish', cancelText: 'Bekor',
          },
          action: () => Services.supplier.deleteInvite(inv.id),
          onSuccess: async () => { await load(); },
          successMessage: 'O\'chirildi',
        });
      }

      async function copyCode(code) {
        try {
          await navigator.clipboard.writeText(code);
          UI.toast('Nusxalandi', { type: 'success' });
        } catch (e) {
          UI.toast('Nusxalab bo\'lmadi', { type: 'warn' });
        }
      }

      onMounted(load);
      return {
        invites, loading, error, editing, TIERS, canManage,
        startCreate, cancelEdit, saveInvite, removeInvite, copyCode,
        formatMoney: Utils.formatMoney,
        formatDate: (d) => Utils.formatDate(d, { time: false }),
      };
    },
    template: `
      <div class="page" data-component="invite-codes">
        <div class="cluster cluster--between">
          <h1 class="heading">Taklif kodlari</h1>
          <button
            v-if="canManage"
            type="button"
            class="btn btn--primary btn--sm"
            data-action="add-invite"
            @click="startCreate"
          >+ Yangi</button>
        </div>

        <div v-if="loading" class="list">
          <div v-for="i in 3" :key="i" class="list__row">
            <div class="skeleton" style="width: 50%; height: 14px;"></div>
          </div>
        </div>
        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>
        <div v-else-if="invites.length" class="stack">
          <div
            v-for="inv in invites" :key="inv.id"
            class="card"
            :data-invite-id="inv.id"
          >
            <div class="cluster cluster--between">
              <div class="stack stack--tight">
                <div class="text-medium" style="font-family: var(--font-mono); font-size: var(--text-lg);">
                  {{ inv.code }}
                </div>
                <div class="text-muted text-sm">
                  {{ inv.tier_preset }} • {{ formatMoney(inv.credit_limit_preset) }} • {{ formatDate(inv.expires_at) }} gacha
                </div>
              </div>
              <div class="row">
                <button
                  type="button"
                  class="btn btn--ghost btn--icon btn--sm"
                  :data-action="'copy-' + inv.id"
                  @click="copyCode(inv.code)"
                  aria-label="Nusxalash"
                >📋</button>
                <button
                  v-if="canManage"
                  type="button"
                  class="btn btn--ghost btn--icon btn--sm"
                  :data-action="'del-invite-' + inv.id"
                  @click="removeInvite(inv)"
                  aria-label="O'chirish"
                >🗑</button>
              </div>
            </div>
          </div>
        </div>
        <div v-else class="empty">
          <div class="empty__icon">🎟️</div>
          <div class="empty__title">Kod yo'q</div>
        </div>

        <!-- New invite form -->
        <div v-if="editing" class="overlay" @click.self="cancelEdit" data-component="invite-form">
          <div class="sheet">
            <div class="sheet__handle"></div>
            <div class="sheet__header">
              <div class="sheet__title">Yangi taklif kodi</div>
            </div>
            <div class="stack">
              <div class="field">
                <label class="field__label">Boshlang'ich tier</label>
                <select v-model="editing.tier_preset" data-field="tier-preset">
                  <option v-for="t in TIERS" :key="t.value" :value="t.value">{{ t.label }}</option>
                </select>
              </div>
              <div class="field">
                <label class="field__label">Boshlang'ich kredit limit (so'm)</label>
                <input type="number" v-model.number="editing.credit_limit_preset" data-field="credit-preset" />
              </div>
              <div class="cluster cluster--end">
                <button class="btn btn--secondary" @click="cancelEdit">Bekor</button>
                <button class="btn btn--primary" data-action="save-invite" @click="saveInvite">Yaratish</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    `,
  };
})();
