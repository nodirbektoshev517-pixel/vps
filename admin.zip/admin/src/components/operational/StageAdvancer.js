/**
 * StageAdvancer.js — buyurtmaning ishlab chiqarish bosqichini ilgarilatish.
 *
 * Bosqich transition jadval mock backend tomonidan majburiy.
 * (409 noto'g'ri transitionda).
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { computed } = Vue;
  const { Services, Actions, Labels, Permissions } = window.Adminbot.Core;

  // Mock backend bilan mos transition'lar (UI uchun mahalliy nusxa)
  const NEXT_STAGES = {
    brief_review:  ['proposal_sent', 'cancelled'],
    proposal_sent: ['approved', 'cancelled'],
    approved:      ['design'],
    design:        ['production', 'cancelled'],
    production:    ['finishing'],
    finishing:     ['delivery'],
    delivery:      ['completed'],
    completed:     [],
    cancelled:     [],
  };

  window.Adminbot.Components.StageAdvancer = {
    name: 'StageAdvancer',
    props: { brief: { type: Object, required: true } },
    emits: ['updated'],
    setup(props, { emit }) {
      const canManage = computed(() => Permissions.can('production.stage.manage'));
      const nextStages = computed(() => {
        const list = NEXT_STAGES[props.brief && props.brief.stage] || [];
        return list.map(s => ({ key: s, ...Labels.formatStatus(s, 'production') }));
      });

      async function advance(toStage) {
        await Actions.runAction({
          permission: 'production.stage.manage',
          confirm: {
            title: 'Bosqichni o\'zgartirish',
            body: `${Labels.formatStatus(props.brief.stage, 'production').label} → ${Labels.formatStatus(toStage, 'production').label}`,
            confirmText: 'O\'zgartirish', cancelText: 'Bekor',
          },
          action: () => Services.production.advanceStage(props.brief.id, toStage),
          onSuccess: (updated) => emit('updated', updated),
          successMessage: 'Bosqich yangilandi',
        });
      }

      return { canManage, nextStages, advance };
    },
    template: `
      <div v-if="canManage && nextStages.length" class="card" data-component="stage-advancer">
        <div class="text-medium">Keyingi bosqich</div>
        <div class="cluster" style="margin-top: var(--space-3); flex-wrap: wrap;">
          <button
            v-for="s in nextStages" :key="s.key"
            type="button"
            class="btn btn--primary btn--sm"
            :data-advance-stage="s.key"
            @click="advance(s.key)"
          >→ {{ s.label }}</button>
        </div>
      </div>
    `,
  };
})();
