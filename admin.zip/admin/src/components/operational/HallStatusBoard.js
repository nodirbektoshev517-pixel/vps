/**
 * HallStatusBoard.js — zal holati dashboardi.
 *
 * Har zal uchun: jami stollar, har holat soni, jami band o'rinlar.
 * Yengil, faqat o'qish — tezkor xulosa.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils, Labels, Composables } = window.Adminbot.Core;

  window.Adminbot.Components.HallStatusBoard = {
    name: 'HallStatusBoard',
    setup() {
      const tables = ref([]);
      const halls = ref([]);
      const loading = ref(true);
      const error = ref(null);

      async function load() {
        loading.value = true;
        try {
          const r = await Services.restaurant.listTables();
          tables.value = (r && r.items) || [];
          halls.value = (r && r.halls) || [];
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; }
      }

      // Har zal uchun statistika
      const hallStats = computed(() => {
        const stats = {};
        for (const h of halls.value) {
          stats[h.id] = {
            hall: h,
            total: 0,
            free: 0,
            reserved: 0,
            occupied: 0,
            cleaning: 0,
            occupied_seats: 0,
          };
        }
        for (const t of tables.value) {
          const s = stats[t.hall_id];
          if (!s) continue;
          s.total++;
          if (s[t.status] != null) s[t.status]++;
          if (t.status === 'occupied' || t.status === 'reserved') {
            s.occupied_seats += t.seats || 0;
          }
        }
        return Object.values(stats);
      });

      function statusInfo(s) { return Labels.formatStatus(s, 'table'); }

      // Real-time
      const { subscribe } = Composables.useEvents();
      function onTableChanged(ev) {
        const p = ev && ev.payload;
        if (!p || !p.id) return;
        const idx = tables.value.findIndex(t => t.id === p.id);
        if (idx >= 0) tables.value[idx] = { ...tables.value[idx], ...p };
      }

      onMounted(() => {
        load();
        subscribe('table.status_changed', onTableChanged);
      });

      return { hallStats, halls, loading, error, statusInfo };
    },
    template: `
      <div class="page" data-component="hall-status-board">
        <h1 class="heading">Zal holati</h1>

        <div v-if="loading && !hallStats.length" class="stack">
          <div v-for="i in 2" :key="i" class="card">
            <div class="skeleton" style="height: 60px;"></div>
          </div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else class="stack">
          <div v-for="s in hallStats" :key="s.hall.id" class="card" :data-hall-id="s.hall.id">
            <div class="cluster cluster--between">
              <div class="text-medium" style="font-size: var(--text-lg);">{{ s.hall.name }}</div>
              <div class="text-muted text-sm">
                {{ s.occupied_seats }} / {{ s.hall.capacity }} o'rin
              </div>
            </div>
            <div class="grid grid--4" style="margin-top: var(--space-3);">
              <div class="stack stack--tight" style="text-align: center;">
                <div class="text-bold" style="font-size: var(--text-xl); color: var(--color-success);">{{ s.free }}</div>
                <div class="text-muted text-sm">{{ statusInfo('free').label }}</div>
              </div>
              <div class="stack stack--tight" style="text-align: center;">
                <div class="text-bold" style="font-size: var(--text-xl); color: var(--color-warning);">{{ s.reserved }}</div>
                <div class="text-muted text-sm">{{ statusInfo('reserved').label }}</div>
              </div>
              <div class="stack stack--tight" style="text-align: center;">
                <div class="text-bold" style="font-size: var(--text-xl); color: var(--color-danger);">{{ s.occupied }}</div>
                <div class="text-muted text-sm">{{ statusInfo('occupied').label }}</div>
              </div>
              <div class="stack stack--tight" style="text-align: center;">
                <div class="text-bold" style="font-size: var(--text-xl); color: var(--color-info);">{{ s.cleaning }}</div>
                <div class="text-muted text-sm">{{ statusInfo('cleaning').label }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `,
  };
})();
