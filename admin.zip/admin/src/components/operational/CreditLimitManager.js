/**
 * CreditLimitManager.js — har do'kon uchun kredit limiti boshqaruvi.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils, Permissions, Actions, UI } = window.Adminbot.Core;

  window.Adminbot.Components.CreditLimitManager = {
    name: 'CreditLimitManager',
    setup() {
      const shops = ref([]);
      const loading = ref(true);
      const error = ref(null);
      const editing = ref(null);
      const canManage = computed(() => Permissions.can('supplier.credit.manage'));

      async function load() {
        loading.value = true;
        try {
          const r = await Services.supplier.listShops();
          shops.value = (r && r.items) || [];
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; }
      }

      function startEdit(shop) {
        if (!Permissions.require('supplier.credit.manage', 'Kredit limiti')) return;
        editing.value = { id: shop.id, name: shop.name, credit_limit: shop.credit_limit };
      }
      function cancelEdit() { editing.value = null; }

      async function saveLimit() {
        const d = editing.value;
        if (!d || d.credit_limit < 0) {
          UI.toast('Manfiy limit kiritib bo\'lmaydi', { type: 'warn' });
          return;
        }
        await Actions.runAction({
          permission: 'supplier.credit.manage',
          action: () => Services.supplier.setCreditLimit(d.id, d.credit_limit),
          onSuccess: async () => { editing.value = null; await load(); },
          successMessage: 'Limit yangilandi',
        });
      }

      onMounted(load);
      return {
        shops, loading, error, editing, canManage,
        startEdit, cancelEdit, saveLimit,
        formatMoney: Utils.formatMoney,
      };
    },
    template: `
      <div class="page" data-component="credit-limits">
        <h1 class="heading">Kredit limitlari</h1>

        <div v-if="loading" class="list">
          <div v-for="i in 3" :key="i" class="list__row">
            <div class="skeleton" style="width: 60%; height: 14px;"></div>
          </div>
        </div>
        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>
        <div v-else-if="shops.length" class="list">
          <div
            v-for="s in shops" :key="s.id"
            class="list__row"
            :data-shop-id="s.id"
          >
            <div class="list__icon">🏦</div>
            <div class="list__main">
              <div class="list__title">{{ s.name }}</div>
              <div class="list__subtitle">Balans: {{ formatMoney(s.balance) }}</div>
            </div>
            <div class="list__trail text-medium">{{ formatMoney(s.credit_limit) }}</div>
            <button
              v-if="canManage"
              type="button"
              class="btn btn--ghost btn--icon btn--sm"
              :data-action="'edit-limit-' + s.id"
              @click="startEdit(s)"
              aria-label="Tahrirlash"
            >✎</button>
          </div>
        </div>
        <div v-else class="empty">
          <div class="empty__icon">🏦</div>
          <div class="empty__title">Do'konlar yo'q</div>
        </div>

        <!-- Edit -->
        <div v-if="editing" class="overlay" @click.self="cancelEdit" data-component="limit-form">
          <div class="sheet">
            <div class="sheet__handle"></div>
            <div class="sheet__header">
              <div class="sheet__title">{{ editing.name }}</div>
            </div>
            <div class="stack">
              <div class="field">
                <label class="field__label">Kredit limiti (so'm)</label>
                <input type="number" v-model.number="editing.credit_limit" min="0" data-field="limit-amount" />
              </div>
              <div class="cluster cluster--end">
                <button class="btn btn--secondary" @click="cancelEdit">Bekor</button>
                <button class="btn btn--primary" data-action="save-limit" @click="saveLimit">Saqlash</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    `,
  };
})();
