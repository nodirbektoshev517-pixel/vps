/**
 * CustomerList.js — mijozlar ro'yxati.
 * Search, pagination. Tap → CustomerProfile.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils } = window.Adminbot.Core;

  window.Adminbot.Components.CustomerList = {
    name: 'CustomerList',
    props: { config: { type: Object, default: () => ({}) } },
    setup(props) {
      const loading = ref(true);
      const error = ref(null);
      const customers = ref([]);
      const cursor = ref(null);
      const hasMore = ref(false);
      const loadingMore = ref(false);
      const search = ref('');
      const seenIds = new Set();
      const selected = ref(null);     // CustomerProfile subview

      const terms = computed(() => (props.config && props.config.terms) || {});
      const titleText = computed(() => terms.value.customers || 'Mijozlar');

      async function load(append = false) {
        if (append) loadingMore.value = true;
        else loading.value = true;
        try {
          const r = await Services.customers.list({
            q: search.value,
            cursor: append ? cursor.value : null,
            page_size: 20,
          });
          const newItems = (r && r.items) || [];
          if (append) {
            const toAdd = newItems.filter(it => !seenIds.has(it.id));
            toAdd.forEach(it => seenIds.add(it.id));
            customers.value = customers.value.concat(toAdd);
          } else {
            seenIds.clear();
            newItems.forEach(it => seenIds.add(it.id));
            customers.value = newItems;
          }
          cursor.value = r && r.next_cursor;
          hasMore.value = !!(r && r.has_more);
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; loadingMore.value = false; }
      }

      // Search uchun debounced reload
      const debouncedReload = Utils.debounce(() => load(false), 400);
      function onSearchInput() { debouncedReload(); }

      function openCustomer(c) { selected.value = c; }
      function back() { selected.value = null; }

      onMounted(() => load());

      return {
        loading, error, customers, hasMore, loadingMore, search, selected,
        titleText, terms,
        onSearchInput, openCustomer, back,
        loadMore: () => load(true),
        fullName: (c) => [c.first_name, c.last_name].filter(Boolean).join(' '),
        initials: Utils.initials,
        formatMoney: Utils.formatMoney,
        relativeTime: Utils.relativeTime,
      };
    },
    template: `
      <div v-if="selected">
        <CustomerProfile :customer="selected" @back="back" />
      </div>
      <div v-else class="page">
        <h1 class="heading">{{ titleText }}</h1>

        <div class="field">
          <input
            type="text"
            v-model="search"
            placeholder="Ism yoki telefon orqali izlash..."
            data-field="search"
            @input="onSearchInput"
          />
        </div>

        <div v-if="loading && !customers.length" class="list">
          <div v-for="i in 4" :key="i" class="list__row">
            <div class="skeleton" style="width: 40px; height: 40px; border-radius: 50%;"></div>
            <div class="list__main">
              <div class="skeleton" style="width: 60%; height: 12px;"></div>
              <div class="skeleton" style="width: 40%; height: 10px; margin-top: 6px;"></div>
            </div>
          </div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else-if="customers.length" class="list" data-component="customer-list">
          <div
            v-for="c in customers" :key="c.id"
            class="list__row list__row--interactive"
            :data-customer-id="c.id"
            @click="openCustomer(c)"
          >
            <div class="avatar">{{ initials(c) }}</div>
            <div class="list__main">
              <div class="list__title">{{ fullName(c) }}</div>
              <div class="list__subtitle">{{ c.phone }} • {{ c.orders_count }} ta buyurtma</div>
            </div>
            <div class="list__trail">{{ formatMoney(c.total_spent) }}</div>
            <div class="list__chevron">›</div>
          </div>
          <button
            v-if="hasMore"
            class="btn btn--secondary btn--block"
            data-action="load-more-customers"
            :disabled="loadingMore"
            @click="loadMore"
          >{{ loadingMore ? 'Yuklanmoqda...' : 'Yana yuklash' }}</button>
        </div>

        <div v-else class="empty">
          <div class="empty__icon">👥</div>
          <div class="empty__title">Mijozlar yo'q</div>
        </div>
      </div>
    `,
  };
})();
