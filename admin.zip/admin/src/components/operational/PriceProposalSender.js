/**
 * PriceProposalSender.js — buyurtma uchun narx taklif yuborish.
 *
 * Faqat brief_review bosqichida ishlatiladi. Yuborilgandan keyin stage
 * avtomatik proposal_sent'ga o'tadi.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed } = Vue;
  const { Services, Utils, Actions, Permissions, UI } = window.Adminbot.Core;

  window.Adminbot.Components.PriceProposalSender = {
    name: 'PriceProposalSender',
    props: { brief: { type: Object, required: true } },
    emits: ['updated'],
    setup(props, { emit }) {
      const price = ref(props.brief.proposed_price || 0);
      const canSend = computed(() =>
        Permissions.can('production.proposal.send') && price.value > 0
      );

      async function send() {
        if (!canSend.value) {
          UI.toast('Narxni kiriting', { type: 'warn' });
          return;
        }
        await Actions.runAction({
          permission: 'production.proposal.send',
          confirm: {
            title: 'Taklif yuborish',
            body: `${props.brief.customer_name}ga ${Utils.formatMoney(price.value)} narx yuborilsinmi?`,
            confirmText: 'Yuborish', cancelText: 'Bekor',
          },
          action: () => Services.production.sendProposal(props.brief.id, price.value),
          onSuccess: (updated) => emit('updated', updated),
          successMessage: 'Taklif yuborildi',
        });
      }

      return { price, canSend, send, formatMoney: Utils.formatMoney };
    },
    template: `
      <div class="card" data-component="proposal-sender">
        <div class="text-medium">Narx taklifi</div>
        <div class="text-muted text-sm" style="margin-top: var(--space-1);">
          Mijozga taklif yuborgandan keyin bosqich avtomatik o'zgaradi.
        </div>
        <div class="field" style="margin-top: var(--space-3);">
          <label class="field__label">Narx (so'm)</label>
          <input type="number" v-model.number="price" min="0" data-field="proposal-price" />
        </div>
        <button
          type="button"
          class="btn btn--primary btn--block"
          data-action="send-proposal"
          :disabled="!canSend"
          @click="send"
        >Taklifni yuborish</button>
      </div>
    `,
  };
})();
