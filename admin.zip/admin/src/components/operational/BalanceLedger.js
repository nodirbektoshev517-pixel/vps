/**
 * BalanceLedger.js — supplier balans operatsiyalari ro'yxati.
 *
 * Operatsiya qo'shish (credit/debit) yangi audit yozuvi yaratadi —
 * mavjudlarini o'zgartirmaydi. Bu §17 audit qoidasiga muvofiq.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils, Permissions, Actions, UI } = window.Adminbot.Core;

  window.Adminbot.Components.BalanceLedger = {
    name: 'BalanceLedger',
    setup() {
      const items = ref([]);
      const shops = ref([]);
      const loading = ref(true);
      const loadingMore = ref(false);
      const cursor = ref(null);
      const hasMore = ref(false);
      const error = ref(null);
      const shopFilter = ref('');
      const seenIds = new Set();
      const editing = ref(null);

      const canManage = computed(() => Permissions.can('supplier.balance.manage'));

      async function loadShops() {
        try {
          const r = await Services.supplier.listShops();
          shops.value = (r && r.items) || [];
        } catch (e) {}
      }

      async function load(append = false) {
        if (append) loadingMore.value = true;
        else loading.value = true;
        try {
          const r = await Services.supplier.listBalance({
            shop_id: shopFilter.value || null,
            cursor: append ? cursor.value : null,
            page_size: 20,
          });
          const newItems = (r && r.items) || [];
          if (append) {
            const toAdd = newItems.filter(it => !seenIds.has(it.id));
            toAdd.forEach(it => seenIds.add(it.id));
            items.value = items.value.concat(toAdd);
          } else {
            seenIds.clear();
            newItems.forEach(it => seenIds.add(it.id));
            items.value = newItems;
          }
          cursor.value = r && r.next_cursor;
          hasMore.value = !!(r && r.has_more);
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; loadingMore.value = false; }
      }

      function changeShopFilter() { load(); }

      function startCreate() {
        if (!Permissions.require('supplier.balance.manage', 'Operatsiya qo\'shish')) return;
        editing.value = {
          shop_id: shops.value[0] && shops.value[0].id || '',
          operation_type: 'credit',
          amount: 0,
          reason: '',
        };
      }
      function cancelEdit() { editing.value = null; }

      async function saveOperation() {
        const d = editing.value;
        if (!d || !d.shop_id || !d.amount || d.amount <= 0) {
          UI.toast('Do\'kon va summa to\'ldirilishi shart', { type: 'warn' });
          return;
        }
        const shop = shops.value.find(s => s.id === d.shop_id);
        await Actions.runAction({
          permission: 'supplier.balance.manage',
          confirm: {
            title: 'Operatsiyani tasdiqlang',
            body: `${shop ? shop.name : d.shop_id} — ${d.operation_type === 'credit' ? '+' : '−'}${Utils.formatMoney(d.amount)}`,
            confirmText: 'Tasdiqlash', cancelText: 'Bekor',
          },
          action: () => Services.supplier.addBalanceOperation({
            shop_id: d.shop_id,
            shop_name: shop && shop.name,
            operation_type: d.operation_type,
            amount: d.amount,
            reason: d.reason,
          }),
          onSuccess: async () => { editing.value = null; await load(); },
          successMessage: 'Operatsiya yozildi',
        });
      }

      onMounted(async () => { await loadShops(); load(); });
      return {
        items, shops, loading, loadingMore, hasMore, error, editing,
        shopFilter, canManage,
        changeShopFilter, startCreate, cancelEdit, saveOperation,
        loadMore: () => load(true),
        formatMoney: Utils.formatMoney,
      };
    },
    template: `
      <div class="page" data-component="balance-ledger">
        <div class="cluster cluster--between">
          <h1 class="heading">Balans tarixi</h1>
          <button
            v-if="canManage"
            type="button"
            class="btn btn--primary btn--sm"
            data-action="add-operation"
            @click="startCreate"
          >+ Operatsiya</button>
        </div>

        <div class="field">
          <label class="field__label">Do'kon</label>
          <select v-model="shopFilter" @change="changeShopFilter" data-field="shop-filter">
            <option value="">Hammasi</option>
            <option v-for="s in shops" :key="s.id" :value="s.id">{{ s.name }}</option>
          </select>
        </div>

        <div v-if="loading && !items.length" class="stack">
          <div v-for="i in 3" :key="i" class="card">
            <div class="skeleton" style="height: 14px; width: 50%;"></div>
            <div class="skeleton" style="height: 12px; width: 30%; margin-top: 8px;"></div>
          </div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else-if="items.length" class="stack">
          <BalanceOperation
            v-for="op in items"
            :key="op.id"
            :operation="op"
          />
          <button
            v-if="hasMore"
            class="btn btn--secondary btn--block"
            data-action="load-more-ops"
            :disabled="loadingMore"
            @click="loadMore"
          >{{ loadingMore ? 'Yuklanmoqda...' : 'Yana yuklash' }}</button>
        </div>

        <div v-else class="empty">
          <div class="empty__icon">💰</div>
          <div class="empty__title">Operatsiyalar yo'q</div>
        </div>

        <!-- Operation form overlay -->
        <div v-if="editing" class="overlay" @click.self="cancelEdit" data-component="operation-form">
          <div class="sheet">
            <div class="sheet__handle"></div>
            <div class="sheet__header">
              <div class="sheet__title">Yangi operatsiya</div>
            </div>
            <div class="stack">
              <div class="field">
                <label class="field__label">Do'kon</label>
                <select v-model="editing.shop_id" data-field="op-shop">
                  <option v-for="s in shops" :key="s.id" :value="s.id">{{ s.name }}</option>
                </select>
              </div>
              <div class="field">
                <label class="field__label">Turi</label>
                <select v-model="editing.operation_type" data-field="op-type">
                  <option value="credit">Kredit (+)</option>
                  <option value="debit">Debet (−)</option>
                </select>
              </div>
              <div class="field">
                <label class="field__label">Summa (so'm)</label>
                <input type="number" v-model.number="editing.amount" data-field="op-amount" />
              </div>
              <div class="field">
                <label class="field__label">Sabab</label>
                <input type="text" v-model="editing.reason" placeholder="Yetkazib berish / To'lov" data-field="op-reason" />
              </div>
              <div class="cluster cluster--end">
                <button class="btn btn--secondary" @click="cancelEdit">Bekor</button>
                <button class="btn btn--primary" data-action="save-operation" @click="saveOperation">Saqlash</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    `,
  };
})();
