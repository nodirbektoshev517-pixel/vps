/**
 * BriefCard.js — Production topshiriq qisqa kartochkasi.
 *
 * InboxList ichida ishlatiladi. OrderCard kabi pattern:
 *   - `order` prop (Vue generic — brief'ni shu nom bilan oladi)
 *   - `config` orqali adapter konfiguratsiyasi
 *   - StageAdvancer'ni ichida ishlatadi (faqat to'g'ridan-to'g'ri ko'rinish kerak bo'lsa)
 *
 * Bu komponent ko'ngillik — operator briefning summarisini ko'radi.
 * To'liq ko'rinish uchun TechBriefViewer ishlatiladi.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { computed } = Vue;
  const { Utils, Labels } = window.Adminbot.Core;

  window.Adminbot.Components.BriefCard = {
    name: 'BriefCard',
    props: {
      order: { type: Object, required: true },   // brief
      config: { type: Object, default: () => ({}) },
    },
    emits: ['updated', 'open'],
    setup(props, { emit }) {
      const brief = computed(() => props.order);
      const terms = computed(() => (props.config && props.config.terms) || {});
      const stageInfo = computed(() =>
        Labels.formatStatus(brief.value.stage, 'production', terms.value)
      );

      return {
        brief, stageInfo,
        formatMoney: Utils.formatMoney,
        formatDate: (d) => d ? Utils.formatDate(d, { time: false }) : '—',
        open: () => emit('open', brief.value),
      };
    },
    template: `
      <div class="card card--interactive"
        :data-brief-id="brief.id"
        :data-order-id="brief.id"
        @click="open"
        style="cursor: pointer;"
      >
        <div class="cluster cluster--between">
          <div class="stack stack--tight">
            <div class="text-medium" style="font-size: var(--text-lg);">#{{ brief.number }}</div>
            <div class="text-muted text-sm">{{ brief.customer_name }}</div>
          </div>
          <span class="badge" :class="'badge--' + stageInfo.badge" :data-stage="brief.stage">
            {{ stageInfo.label }}
          </span>
        </div>

        <div class="stack stack--tight" style="margin-top: var(--space-3);">
          <div class="row">
            <span style="font-size: var(--icon-md)">📦</span>
            <span class="text-sm">{{ brief.product_type }}</span>
          </div>
          <div v-if="brief.proposed_price" class="row">
            <span style="font-size: var(--icon-md)">💰</span>
            <span class="text-sm">{{ formatMoney(brief.proposed_price) }}</span>
          </div>
          <div v-if="brief.target_delivery_at" class="row">
            <span style="font-size: var(--icon-md)">📅</span>
            <span class="text-sm">{{ formatDate(brief.target_delivery_at) }}</span>
          </div>
        </div>
      </div>
    `,
  };
})();
