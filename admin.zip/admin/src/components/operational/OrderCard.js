/**
 * OrderCard.js — universal buyurtma kartochkasi.
 *
 * Biznes turini BILMAYDI. Adapter `component_configs.OrderCard` orqali:
 *   - extensions: qaysi qo'shimcha bloklar (kichik komponentlar) ko'rinadi
 *   - primary_actions: status → keyingi statuslar tugmasi
 *   - terms: label override (Labels.formatStatus ga uzatiladi)
 *
 * Variant 2: extension'lar — kichik komponentlar (AddressBlock, PaymentBlock, ...).
 * `<component :is="extMap[ext]">` orqali yuklanadi.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { computed } = Vue;
  const { Utils, Services, Actions, Labels } = window.Adminbot.Core;

  // Extension nomi → komponent nomi mapping
  // (Bosqich 2'da yangi extension qo'shilsa bu yerda qayd etiladi)
  const EXTENSION_MAP = {
    delivery_address: 'AddressBlock',
    payment_method:   'PaymentBlock',
    note:             'NoteBlock',
  };

  window.Adminbot.Components.OrderCard = {
    name: 'OrderCard',
    props: {
      order:  { type: Object, required: true },
      config: { type: Object, default: () => ({}) },
    },
    emits: ['updated'],
    setup(props, { emit }) {
      const extensions = computed(() => {
        const list = (props.config && props.config.extensions) || [];
        // Faqat ro'yxatdagi va EXTENSION_MAP'da mavjud bo'lganlarni qaytaramiz
        return list
          .map(name => ({ name, component: EXTENSION_MAP[name] }))
          .filter(e => !!e.component);
      });

      const primaryActions = computed(() => {
        const map = (props.config && props.config.primary_actions) || {};
        const next = map[props.order.status] || [];
        return next.map(status => ({
          status,
          ...Labels.formatStatus(status, 'order', props.config && props.config.terms),
        }));
      });

      const terms = computed(() => (props.config && props.config.terms) || {});

      const total = computed(() => Utils.formatMoney(props.order.total));
      const timeAgo = computed(() => Utils.relativeTime(props.order.created_at));

      async function advance(toStatus) {
        await Actions.runAction({
          permission: 'orders.update',
          actionLabel: `Statusni "${Labels.formatStatus(toStatus, 'order').label}" ga o'tkazish`,
          action: () => Services.inbox.updateStatus(props.order.id, toStatus),
          onSuccess: (updated) => {
            // Local optimistic update emas — backend qaytargan ob'ektni emit qilamiz,
            // parent (InboxList) lokal ro'yxatni yangilaydi.
            emit('updated', updated);
          },
          // success toast yo'q — UI'da status badge avtomatik yangilanadi
          silent: false,
          successMessage: 'Status yangilandi',
        });
      }

      return { extensions, primaryActions, terms, total, timeAgo, advance };
    },
    template: `
      <div class="card" :data-order-id="order.id">
        <!-- Yuqori qator: raqam + status -->
        <div class="cluster cluster--between">
          <div class="stack stack--tight">
            <div class="text-medium" style="font-size: var(--text-lg);">#{{ order.number }}</div>
            <div class="text-muted text-sm">{{ order.customer_name }}</div>
          </div>
          <OrderStatusBadge :status="order.status" :terms="terms" />
        </div>

        <!-- Extension bloklar (Variant 2 — har biri kichik komponent) -->
        <div v-if="extensions.length" class="stack stack--tight" style="margin-top: var(--space-3);">
          <component
            v-for="ext in extensions"
            :key="ext.name"
            :is="ext.component"
            :order="order"
          />
        </div>

        <!-- Pastki qator: vaqt + summa + action -->
        <div class="cluster cluster--between" style="margin-top: var(--space-3);">
          <div class="text-muted text-sm">{{ timeAgo }}</div>
          <div class="text-bold">{{ total }}</div>
        </div>

        <!-- Primary action (faqat keyingi status bo'lsa) -->
        <div v-if="primaryActions.length" class="cluster" style="margin-top: var(--space-3);">
          <button
            v-for="act in primaryActions"
            :key="act.status"
            type="button"
            class="btn btn--primary btn--sm btn--block"
            :data-action="'advance-to-' + act.status"
            @click="advance(act.status)"
          >{{ act.label }}</button>
        </div>
      </div>
    `,
  };
})();
