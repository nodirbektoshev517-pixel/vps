/**
 * ReservationCard.js — restoran bron kartochkasi.
 *
 * OrderCard kabi pattern — extension renderer va primary action.
 * Adapter `InboxList.item_card: 'ReservationCard'` orqali Inbox blokida ishlatiladi.
 *
 * Extension'lar: special_requests, deposit_status, party_info.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { computed } = Vue;
  const { Utils, Services, Actions, Labels } = window.Adminbot.Core;

  const EXTENSION_MAP = {
    special_requests: 'SpecialRequestsBlock',
    deposit_status:   'DepositStatusBlock',
    party_info:       'PartyInfoBlock',
  };

  window.Adminbot.Components.ReservationCard = {
    name: 'ReservationCard',
    props: {
      order: { type: Object, required: true },   // InboxList "order" deb chaqiradi
      config: { type: Object, default: () => ({}) },
    },
    emits: ['updated'],
    setup(props, { emit }) {
      // InboxList'ning generikligi uchun "order" deb keladi —
      // bu yerda uni reservation deb tushunamiz
      const reservation = computed(() => props.order);

      const extensions = computed(() => {
        const list = (props.config && props.config.extensions) || [];
        return list.map(name => ({ name, component: EXTENSION_MAP[name] })).filter(e => !!e.component);
      });

      const primaryActions = computed(() => {
        const map = (props.config && props.config.primary_actions) || {};
        const next = map[reservation.value.status] || [];
        return next.map(status => ({
          status,
          ...Labels.formatStatus(status, 'reservation', props.config && props.config.terms),
        }));
      });

      const terms = computed(() => (props.config && props.config.terms) || {});
      const partySize = computed(() => reservation.value.party_size || 0);
      const formattedTime = computed(() =>
        Utils.formatDate(reservation.value.reservation_time, { time: true })
      );
      const statusInfo = computed(() =>
        Labels.formatStatus(reservation.value.status, 'reservation', terms.value)
      );

      async function advance(toStatus) {
        await Actions.runAction({
          permission: 'reservations.update',
          actionLabel: `Status "${Labels.formatStatus(toStatus, 'reservation').label}"`,
          action: () => Services.restaurant.updateReservationStatus(reservation.value.id, toStatus),
          onSuccess: (updated) => emit('updated', updated),
          successMessage: 'Status yangilandi',
        });
      }

      return { reservation, extensions, primaryActions, terms, partySize, formattedTime, statusInfo, advance };
    },
    template: `
      <div class="card" :data-reservation-id="reservation.id" :data-order-id="reservation.id">
        <div class="cluster cluster--between">
          <div class="stack stack--tight">
            <div class="text-medium" style="font-size: var(--text-lg);">#{{ reservation.number }}</div>
            <div class="text-muted text-sm">{{ reservation.customer_name }}</div>
          </div>
          <span class="badge"
            :class="'badge--' + statusInfo.badge"
            :data-status="reservation.status"
          >{{ statusInfo.label }}</span>
        </div>

        <div class="stack stack--tight" style="margin-top: var(--space-3);">
          <div class="row">
            <span style="font-size: var(--icon-md)">🗓️</span>
            <span class="text-sm">{{ formattedTime }}</span>
          </div>
          <div class="row">
            <span style="font-size: var(--icon-md)">👥</span>
            <span class="text-sm">{{ partySize }} kishi</span>
            <span v-if="reservation.table_id" class="text-muted text-sm" style="margin-left: 6px;">
              • Stol: {{ reservation.table_id }}
            </span>
          </div>

          <component
            v-for="ext in extensions"
            :key="ext.name"
            :is="ext.component"
            :reservation="reservation"
          />
        </div>

        <div v-if="primaryActions.length" class="cluster" style="margin-top: var(--space-3);">
          <button
            v-for="act in primaryActions"
            :key="act.status"
            type="button"
            class="btn btn--primary btn--sm btn--block"
            :data-action="'advance-to-' + act.status"
            @click="advance(act.status)"
          >{{ act.label }}</button>
        </div>
      </div>
    `,
  };

  // Ekstension komponentlar — kichik, lokal qoladi
  window.Adminbot.Components.SpecialRequestsBlock = {
    name: 'SpecialRequestsBlock',
    props: { reservation: { type: Object, required: true } },
    template: `
      <div v-if="reservation.special_requests" class="row" data-ext="special_requests">
        <span style="font-size: var(--icon-md)">📝</span>
        <span class="text-sm" style="font-style: italic;">{{ reservation.special_requests }}</span>
      </div>
    `,
  };

  window.Adminbot.Components.DepositStatusBlock = {
    name: 'DepositStatusBlock',
    props: { reservation: { type: Object, required: true } },
    setup(props) {
      const { Utils } = window.Adminbot.Core;
      const has = window.Vue.computed(() => props.reservation && props.reservation.deposit > 0);
      const amount = window.Vue.computed(() => Utils.formatMoney(props.reservation.deposit || 0));
      return { has, amount };
    },
    template: `
      <div v-if="has" class="row" data-ext="deposit_status">
        <span style="font-size: var(--icon-md)">💰</span>
        <span class="text-sm">Avans: {{ amount }}</span>
      </div>
    `,
  };

  window.Adminbot.Components.PartyInfoBlock = {
    name: 'PartyInfoBlock',
    props: { reservation: { type: Object, required: true } },
    template: `
      <div class="row" data-ext="party_info">
        <span style="font-size: var(--icon-md)">📞</span>
        <span class="text-sm">{{ reservation.customer_phone }}</span>
      </div>
    `,
  };
})();
