/**
 * TierAssigner.js — supplier mijozlariga tier belgilash.
 *
 * 4 tier: bronze, silver, gold, platinum.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils, Permissions, Actions } = window.Adminbot.Core;

  const TIERS = [
    { value: 'bronze',   label: 'Bronza',  badge: 'neutral' },
    { value: 'silver',   label: 'Kumush',  badge: 'info' },
    { value: 'gold',     label: 'Oltin',   badge: 'warning' },
    { value: 'platinum', label: 'Platina', badge: 'primary' },
  ];

  window.Adminbot.Components.TierAssigner = {
    name: 'TierAssigner',
    setup() {
      const shops = ref([]);
      const loading = ref(true);
      const error = ref(null);
      const canManage = computed(() => Permissions.can('supplier.tier.manage'));

      async function load() {
        loading.value = true;
        try {
          const r = await Services.supplier.listShops();
          shops.value = (r && r.items) || [];
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; }
      }

      function tierInfo(t) { return TIERS.find(x => x.value === t) || TIERS[0]; }

      async function assignTier(shop, newTier) {
        if (shop.tier === newTier) return;
        await Actions.runAction({
          permission: 'supplier.tier.manage',
          confirm: {
            title: 'Tier o\'zgartirishni tasdiqlang',
            body: `${shop.name}: ${tierInfo(shop.tier).label} → ${tierInfo(newTier).label}`,
            confirmText: 'O\'zgartirish', cancelText: 'Bekor',
          },
          action: () => Services.supplier.setTier(shop.id, newTier),
          onSuccess: async () => { await load(); },
          successMessage: 'Tier yangilandi',
        });
      }

      onMounted(load);
      return { shops, loading, error, canManage, TIERS, tierInfo, assignTier };
    },
    template: `
      <div class="page" data-component="tier-assigner">
        <h1 class="heading">Tier belgilash</h1>
        <div class="subheading">Mijozlarga bronza/kumush/oltin/platina tier'larini belgilang.</div>

        <div v-if="loading" class="list">
          <div v-for="i in 3" :key="i" class="list__row">
            <div class="skeleton" style="width: 60%; height: 14px;"></div>
          </div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else-if="shops.length" class="stack">
          <div
            v-for="s in shops" :key="s.id"
            class="card"
            :data-shop-id="s.id"
          >
            <div class="cluster cluster--between">
              <div class="text-medium">{{ s.name }}</div>
              <span class="badge" :class="'badge--' + tierInfo(s.tier).badge">{{ tierInfo(s.tier).label }}</span>
            </div>
            <div v-if="canManage" class="cluster" style="margin-top: var(--space-3);">
              <button
                v-for="t in TIERS" :key="t.value"
                type="button"
                class="chip"
                :class="{ 'chip--active': s.tier === t.value }"
                :data-tier-btn="t.value"
                @click="assignTier(s, t.value)"
              >{{ t.label }}</button>
            </div>
          </div>
        </div>

        <div v-else class="empty">
          <div class="empty__icon">🎖️</div>
          <div class="empty__title">Do'konlar yo'q</div>
        </div>
      </div>
    `,
  };
})();
