/**
 * ServiceCRUD.js — appointment biznes turi xizmatlari (CRUD).
 *
 * Har xizmat: nom, davomiyligi (daq), narx, active flag.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils, Permissions, Actions, UI } = window.Adminbot.Core;

  window.Adminbot.Components.ServiceCRUD = {
    name: 'ServiceCRUD',
    setup() {
      const items = ref([]);
      const loading = ref(true);
      const error = ref(null);
      const editing = ref(null);
      const canManage = computed(() => Permissions.can('appointment.services.manage'));

      async function load() {
        loading.value = true;
        try {
          const r = await Services.appointment.listServices();
          items.value = (r && r.items) || [];
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; }
      }

      function startCreate() {
        if (!Permissions.require('appointment.services.manage', 'Xizmat qo\'shish')) return;
        editing.value = { name: '', duration_min: 30, price: 0, active: true };
      }
      function startEdit(s) {
        if (!Permissions.require('appointment.services.manage', 'Xizmat tahrirlash')) return;
        editing.value = { ...s };
      }
      function cancelEdit() { editing.value = null; }

      async function saveEdit() {
        const d = editing.value;
        if (!d || !d.name) { UI.toast('Nom majburiy', { type: 'warn' }); return; }
        const isNew = !d.id;
        await Actions.runAction({
          permission: 'appointment.services.manage',
          action: () => isNew
            ? Services.appointment.createService(d)
            : Services.appointment.updateService(d.id, d),
          onSuccess: async () => { editing.value = null; await load(); },
          successMessage: isNew ? 'Qo\'shildi' : 'Yangilandi',
        });
      }

      async function remove(s) {
        await Actions.runAction({
          permission: 'appointment.services.manage',
          confirm: {
            title: 'O\'chirishni tasdiqlang',
            body: `"${s.name}" o'chirilsinmi?`,
            confirmText: 'O\'chirish', cancelText: 'Bekor',
          },
          action: () => Services.appointment.deleteService(s.id),
          onSuccess: async () => { await load(); },
          successMessage: 'O\'chirildi',
        });
      }

      onMounted(load);

      return {
        items, loading, error, editing, canManage,
        startCreate, startEdit, cancelEdit, saveEdit, remove,
        formatMoney: Utils.formatMoney,
      };
    },
    template: `
      <div class="page" data-component="service-crud">
        <div class="cluster cluster--between">
          <h1 class="heading">Xizmatlar</h1>
          <button v-if="canManage" type="button" class="btn btn--primary btn--sm"
            data-action="add-service" @click="startCreate">+ Yangi</button>
        </div>

        <div v-if="loading && !items.length" class="list">
          <div v-for="i in 3" :key="i" class="list__row">
            <div class="list__main">
              <div class="skeleton" style="width: 50%; height: 14px;"></div>
            </div>
          </div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else-if="items.length" class="list">
          <div
            v-for="s in items" :key="s.id"
            class="list__row"
            :data-service-id="s.id"
          >
            <div class="list__icon">✂️</div>
            <div class="list__main">
              <div class="list__title">{{ s.name }}</div>
              <div class="list__subtitle">{{ s.duration_min }} daq • {{ formatMoney(s.price) }}</div>
            </div>
            <span v-if="!s.active" class="badge badge--neutral">Faol emas</span>
            <button v-if="canManage" type="button" class="btn btn--ghost btn--icon btn--sm"
              :data-action="'edit-svc-' + s.id" @click="startEdit(s)" aria-label="Tahrirlash">✎</button>
            <button v-if="canManage" type="button" class="btn btn--ghost btn--icon btn--sm"
              :data-action="'del-svc-' + s.id" @click="remove(s)" aria-label="O'chirish">🗑</button>
          </div>
        </div>

        <div v-else class="empty">
          <div class="empty__icon">✂️</div>
          <div class="empty__title">Xizmat yo'q</div>
        </div>

        <div v-if="editing" class="overlay" @click.self="cancelEdit" data-component="service-form">
          <div class="sheet">
            <div class="sheet__handle"></div>
            <div class="sheet__header">
              <div class="sheet__title">{{ editing.id ? 'Tahrirlash' : 'Yangi xizmat' }}</div>
            </div>
            <div class="stack">
              <div class="field">
                <label class="field__label">Nomi</label>
                <input type="text" v-model="editing.name" data-field="svc-name" />
              </div>
              <div class="field">
                <label class="field__label">Davomiyligi (daq)</label>
                <input type="number" v-model.number="editing.duration_min" min="5" max="480" data-field="svc-duration" />
              </div>
              <div class="field">
                <label class="field__label">Narx (so'm)</label>
                <input type="number" v-model.number="editing.price" min="0" data-field="svc-price" />
              </div>
              <div class="field">
                <label class="cluster">
                  <input type="checkbox" v-model="editing.active" data-field="svc-active" />
                  <span>Faol</span>
                </label>
              </div>
              <div class="cluster cluster--end">
                <button class="btn btn--secondary" @click="cancelEdit">Bekor</button>
                <button class="btn btn--primary" data-action="save-service" @click="saveEdit">Saqlash</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    `,
  };
})();
