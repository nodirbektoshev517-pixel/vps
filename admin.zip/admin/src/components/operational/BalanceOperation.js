/**
 * BalanceOperation.js — bitta balans operatsiyasi (immutable yozuv).
 *
 * BalanceLedger ichida ishlatiladi.
 * Audit shartlari (BOSQICH_2.md §17):
 *   - actor_id/name, operation_type, amount, reason
 *   - before_balance, after_balance, created_at
 *   - immutable log (frontend tahrirlamaydi)
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { computed } = Vue;
  const { Utils } = window.Adminbot.Core;

  window.Adminbot.Components.BalanceOperation = {
    name: 'BalanceOperation',
    props: { operation: { type: Object, required: true } },
    setup(props) {
      const isCredit = computed(() => props.operation.operation_type === 'credit');
      const sign = computed(() => isCredit.value ? '+' : '−');
      const cls = computed(() => isCredit.value ? 'text-success' : 'text-danger');
      return {
        isCredit, sign, cls,
        formatMoney: Utils.formatMoney,
        relativeTime: Utils.relativeTime,
      };
    },
    template: `
      <div class="card" :data-operation-id="operation.id">
        <div class="cluster cluster--between">
          <div class="stack stack--tight">
            <div class="text-medium">{{ operation.shop_name }}</div>
            <div class="text-muted text-sm">{{ operation.reason || (isCredit ? 'Kredit' : 'Debet') }}</div>
          </div>
          <div class="text-bold" :class="cls" style="font-size: var(--text-lg);">
            {{ sign }}{{ formatMoney(operation.amount) }}
          </div>
        </div>
        <div class="cluster cluster--between" style="margin-top: var(--space-2);">
          <div class="text-muted text-sm">
            {{ formatMoney(operation.before_balance) }} → {{ formatMoney(operation.after_balance) }}
          </div>
          <div class="text-muted text-sm">{{ relativeTime(operation.created_at) }}</div>
        </div>
        <div class="text-muted text-sm" style="margin-top: var(--space-1);">
          {{ operation.actor_name }}
        </div>
      </div>
    `,
  };
})();
