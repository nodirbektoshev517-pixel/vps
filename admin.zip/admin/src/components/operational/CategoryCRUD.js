/**
 * CategoryCRUD.js — kategoriyalar boshqaruvi.
 *
 * Bosish: kategoriyaga kirish → ProductCRUD (shu kategoriya mahsulotlari).
 * Owner/manager qo'shish/o'zgartirish/o'chirish qila oladi (permission filter).
 *
 * Universal — biznes turini bilmaydi. Adapter terms config:
 *   CategoryCRUD: { terms: { catalog: 'Mahsulotlar' } }
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils, Permissions, Actions, UI } = window.Adminbot.Core;

  window.Adminbot.Components.CategoryCRUD = {
    name: 'CategoryCRUD',
    props: { config: { type: Object, default: () => ({}) } },
    setup(props) {
      const loading = ref(true);
      const error = ref(null);
      const categories = ref([]);

      // Subview: kategoriya tanlangan bo'lsa, ProductCRUD ko'rsatamiz
      const selectedCategory = ref(null);

      // Edit modal state
      const editing = ref(null);   // null | {} (yangi) | {id, name, icon} (mavjud)

      const canManage = computed(() => Permissions.can('catalog.manage'));
      const catalogLabel = computed(() =>
        (props.config && props.config.terms && props.config.terms.catalog) || 'Katalog'
      );

      async function load() {
        loading.value = true;
        try {
          const r = await Services.catalog.listCategories();
          categories.value = (r && r.items) || [];
          error.value = null;
        } catch (e) {
          error.value = Utils.errorText(e);
        } finally { loading.value = false; }
      }

      function openCategory(cat) { selectedCategory.value = cat; }
      function backFromProducts() { selectedCategory.value = null; load(); }

      function startCreate() {
        if (!Permissions.require('catalog.manage', 'Kategoriya qo\'shish')) return;
        editing.value = { name: '', icon: '📦' };
      }
      function startEdit(cat) {
        if (!Permissions.require('catalog.manage', 'Kategoriya tahrirlash')) return;
        editing.value = { ...cat };
      }
      function cancelEdit() { editing.value = null; }

      async function saveEdit() {
        const data = editing.value;
        if (!data || !data.name || data.name.length < 2) {
          UI.toast('Kategoriya nomi juda qisqa', { type: 'warn' });
          return;
        }
        const isNew = !data.id;
        await Actions.runAction({
          permission: 'catalog.manage',
          action: () => isNew
            ? Services.catalog.createCategory({ name: data.name, icon: data.icon })
            : Services.catalog.updateCategory(data.id, { name: data.name, icon: data.icon }),
          onSuccess: async () => { editing.value = null; await load(); },
          successMessage: isNew ? 'Qo\'shildi' : 'Yangilandi',
        });
      }

      async function remove(cat) {
        await Actions.runAction({
          permission: 'catalog.manage',
          confirm: {
            title: 'O\'chirishni tasdiqlang',
            body: `"${cat.name}" o'chirilsinmi?`,
            confirmText: 'O\'chirish',
            cancelText: 'Bekor',
          },
          action: () => Services.catalog.deleteCategory(cat.id),
          onSuccess: async () => { await load(); },
          successMessage: 'O\'chirildi',
        });
      }

      onMounted(load);

      return {
        loading, error, categories, selectedCategory, editing,
        canManage, catalogLabel,
        openCategory, backFromProducts,
        startCreate, startEdit, cancelEdit, saveEdit, remove,
      };
    },
    template: `
      <!-- Subview: tanlangan kategoriya mahsulotlari -->
      <div v-if="selectedCategory">
        <ProductCRUD :category="selectedCategory" @back="backFromProducts" />
      </div>

      <!-- Asosiy: kategoriyalar ro'yxati -->
      <div v-else class="page">
        <div class="cluster cluster--between">
          <h1 class="heading">{{ catalogLabel }}</h1>
          <button
            v-if="canManage"
            type="button"
            class="btn btn--primary btn--sm"
            data-action="add-category"
            @click="startCreate"
          >+ Yangi</button>
        </div>

        <div v-if="loading && !categories.length" class="list">
          <div v-for="i in 3" :key="i" class="list__row">
            <div class="skeleton" style="width: 32px; height: 32px;"></div>
            <div class="list__main">
              <div class="skeleton" style="width: 60%; height: 14px;"></div>
            </div>
          </div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else-if="categories.length" class="list" data-component="category-list">
          <div
            v-for="cat in categories" :key="cat.id"
            class="list__row list__row--interactive"
            :data-category-id="cat.id"
            @click="openCategory(cat)"
          >
            <div class="list__icon">{{ cat.icon }}</div>
            <div class="list__main">
              <div class="list__title">{{ cat.name }}</div>
              <div class="list__subtitle">{{ cat.products_count }} ta mahsulot</div>
            </div>
            <button
              v-if="canManage"
              type="button"
              class="btn btn--ghost btn--icon btn--sm"
              :data-action="'edit-cat-' + cat.id"
              @click.stop="startEdit(cat)"
              aria-label="Tahrirlash"
            >✎</button>
            <button
              v-if="canManage"
              type="button"
              class="btn btn--ghost btn--icon btn--sm"
              :data-action="'del-cat-' + cat.id"
              @click.stop="remove(cat)"
              aria-label="O'chirish"
            >🗑</button>
            <div class="list__chevron">›</div>
          </div>
        </div>

        <div v-else class="empty">
          <div class="empty__icon">🛍️</div>
          <div class="empty__title">Kategoriya yo'q</div>
          <div class="empty__hint">Birinchi kategoriyani qo'shing.</div>
        </div>

        <!-- Edit overlay -->
        <div v-if="editing" class="overlay" @click.self="cancelEdit" data-component="category-form">
          <div class="sheet">
            <div class="sheet__handle"></div>
            <div class="sheet__header">
              <div class="sheet__title">{{ editing.id ? 'Kategoriya tahrirlash' : 'Yangi kategoriya' }}</div>
            </div>
            <div class="stack">
              <div class="field">
                <label class="field__label">Nomi</label>
                <input
                  type="text"
                  v-model="editing.name"
                  placeholder="Masalan: Ichimliklar"
                  data-field="name"
                />
              </div>
              <div class="field">
                <label class="field__label">Belgi (emoji)</label>
                <input
                  type="text"
                  v-model="editing.icon"
                  maxlength="3"
                  placeholder="📦"
                  data-field="icon"
                />
              </div>
              <div class="cluster cluster--end">
                <button class="btn btn--secondary" @click="cancelEdit">Bekor</button>
                <button class="btn btn--primary" data-action="save-category" @click="saveEdit">Saqlash</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    `,
  };
})();
