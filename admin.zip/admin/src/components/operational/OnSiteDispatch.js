/**
 * OnSiteDispatch.js — o'lcham olish yoki o'rnatish uchun ishchi yuborish.
 *
 * Custom production'da brief uchun bir-ikki marotaba on-site tashrif kerak —
 * o'lcham olish (boshlanishda), keyin o'rnatish (yakunida).
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils, Permissions, Actions, UI } = window.Adminbot.Core;

  const DISPATCH_STATUSES = {
    scheduled:   { label: 'Belgilangan', badge: 'warning' },
    in_progress: { label: 'Jarayonda',   badge: 'primary' },
    completed:   { label: 'Tugatildi',   badge: 'success' },
    cancelled:   { label: 'Bekor',       badge: 'neutral' },
  };

  window.Adminbot.Components.OnSiteDispatch = {
    name: 'OnSiteDispatch',
    setup() {
      const items = ref([]);
      const loading = ref(true);
      const error = ref(null);
      const editing = ref(null);
      const canManage = computed(() => Permissions.can('production.dispatch.manage'));

      async function load() {
        loading.value = true;
        try {
          const r = await Services.production.listDispatches();
          items.value = (r && r.items) || [];
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; }
      }

      function startCreate() {
        if (!Permissions.require('production.dispatch.manage', 'Tashrif belgilash')) return;
        editing.value = {
          brief_id: '', worker_name: '', address: '',
          scheduled_at: new Date(Date.now() + 86400000).toISOString().slice(0, 16),
          purpose: 'O\'lcham olish',
        };
      }
      function cancelEdit() { editing.value = null; }

      async function saveEdit() {
        const d = editing.value;
        if (!d || !d.brief_id) { UI.toast('Brief ID majburiy', { type: 'warn' }); return; }
        const payload = { ...d, scheduled_at: new Date(d.scheduled_at).toISOString() };
        await Actions.runAction({
          permission: 'production.dispatch.manage',
          action: () => Services.production.createDispatch(payload),
          onSuccess: async () => { editing.value = null; await load(); },
          successMessage: 'Belgilandi',
        });
      }

      async function setStatus(d, newStatus) {
        await Actions.runAction({
          permission: 'production.dispatch.manage',
          action: () => Services.production.updateDispatchStatus(d.id, newStatus),
          onSuccess: async () => { await load(); },
          successMessage: 'Yangilandi',
        });
      }

      function statusInfo(s) { return DISPATCH_STATUSES[s] || { label: s, badge: 'neutral' }; }

      onMounted(load);

      return {
        items, loading, error, editing, canManage,
        startCreate, cancelEdit, saveEdit, setStatus, statusInfo,
        formatDate: (d) => Utils.formatDate(d, { time: true }),
      };
    },
    template: `
      <div class="page" data-component="on-site-dispatch">
        <div class="cluster cluster--between">
          <h1 class="heading">Tashriflar</h1>
          <button v-if="canManage" type="button" class="btn btn--primary btn--sm"
            data-action="add-dispatch" @click="startCreate">+ Yangi</button>
        </div>

        <div v-if="loading && !items.length" class="stack">
          <div v-for="i in 2" :key="i" class="card">
            <div class="skeleton" style="width: 60%; height: 14px;"></div>
          </div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else-if="items.length" class="stack">
          <div
            v-for="d in items" :key="d.id"
            class="card"
            :data-dispatch-id="d.id"
          >
            <div class="cluster cluster--between">
              <div class="stack stack--tight">
                <div class="text-medium">{{ d.purpose }}</div>
                <div class="text-muted text-sm">{{ d.address }}</div>
              </div>
              <span class="badge" :class="'badge--' + statusInfo(d.status).badge">
                {{ statusInfo(d.status).label }}
              </span>
            </div>
            <div class="stack stack--tight" style="margin-top: var(--space-3);">
              <div class="row">
                <span style="font-size: var(--icon-md)">👷</span>
                <span class="text-sm">{{ d.worker_name }}</span>
              </div>
              <div class="row">
                <span style="font-size: var(--icon-md)">🗓️</span>
                <span class="text-sm">{{ formatDate(d.scheduled_at) }}</span>
              </div>
              <div class="row">
                <span style="font-size: var(--icon-md)">🔗</span>
                <span class="text-sm text-muted">Brief: {{ d.brief_id }}</span>
              </div>
            </div>
            <div v-if="canManage && d.status === 'scheduled'" class="cluster cluster--end" style="margin-top: var(--space-3);">
              <button class="btn btn--ghost btn--sm" :data-action="'start-' + d.id" @click="setStatus(d, 'in_progress')">Boshlash</button>
              <button class="btn btn--ghost btn--sm text-danger" :data-action="'cancel-' + d.id" @click="setStatus(d, 'cancelled')">Bekor qilish</button>
            </div>
            <div v-else-if="canManage && d.status === 'in_progress'" class="cluster cluster--end" style="margin-top: var(--space-3);">
              <button class="btn btn--primary btn--sm" :data-action="'complete-' + d.id" @click="setStatus(d, 'completed')">Tugatish</button>
            </div>
          </div>
        </div>

        <div v-else class="empty">
          <div class="empty__icon">🛠️</div>
          <div class="empty__title">Tashrif yo'q</div>
        </div>

        <div v-if="editing" class="overlay" @click.self="cancelEdit" data-component="dispatch-form">
          <div class="sheet">
            <div class="sheet__handle"></div>
            <div class="sheet__header">
              <div class="sheet__title">Yangi tashrif</div>
            </div>
            <div class="stack">
              <div class="field">
                <label class="field__label">Brief ID</label>
                <input type="text" v-model="editing.brief_id" placeholder="brf_1" data-field="disp-brief" />
              </div>
              <div class="field">
                <label class="field__label">Ishchi</label>
                <input type="text" v-model="editing.worker_name" data-field="disp-worker" />
              </div>
              <div class="field">
                <label class="field__label">Manzil</label>
                <input type="text" v-model="editing.address" data-field="disp-address" />
              </div>
              <div class="field">
                <label class="field__label">Sana va vaqt</label>
                <input type="datetime-local" v-model="editing.scheduled_at" data-field="disp-time" />
              </div>
              <div class="field">
                <label class="field__label">Maqsad</label>
                <select v-model="editing.purpose" data-field="disp-purpose">
                  <option value="O'lcham olish">O'lcham olish</option>
                  <option value="O'rnatish">O'rnatish</option>
                  <option value="Maslahat">Maslahat</option>
                  <option value="Yetkazib berish">Yetkazib berish</option>
                </select>
              </div>
              <div class="cluster cluster--end">
                <button class="btn btn--secondary" @click="cancelEdit">Bekor</button>
                <button class="btn btn--primary" data-action="save-dispatch" @click="saveEdit">Saqlash</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    `,
  };
})();
