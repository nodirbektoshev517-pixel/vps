/**
 * SessionCard.js — universal restoran sessiya kartochkasi.
 *
 * OrderCard pattern aynan takrorlanadi:
 *   - Biznes turini BILMAYDI.
 *   - Adapter `component_configs.SessionCard` orqali:
 *       - primary_actions: status → keyingi statuslar tugmasi
 *       - terms: label override (Labels.formatStatus ga uzatiladi)
 *
 * Phase 1 ko'lami:
 *   - Status badge + mijoz + stol № + mehmonlar soni
 *   - Orderlar inline summary (raqam, status, summa)
 *   - Totallar (subtotal, service_charge, tip, total)
 *   - Action tugmalari (start-closing, close) — modal yo'q
 *
 * Service: Services.restaurantSessions.updateStatus(id, 'closing'|'closed').
 * Backend transitions: bill_requested → closing → closed.
 *
 * Diqqat: InboxList barcha item'larni `:order="..."` prop nomi bilan uzatadi
 * (template'da hardcoded), shuning uchun prop nomi `order` lekin ichida
 * sessiya obyekti turadi. Buni o'zgartirmasdan moslashamiz.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { computed } = Vue;
  const { Utils, Services, Actions, Labels } = window.Adminbot.Core;

  window.Adminbot.Components.SessionCard = {
    name: 'SessionCard',
    props: {
      order:  { type: Object, required: true },  // aslida session — InboxList unifikatsiyasi
      config: { type: Object, default: () => ({}) },
    },
    emits: ['updated'],
    setup(props, { emit }) {
      const session = computed(() => props.order);
      const terms = computed(() => (props.config && props.config.terms) || {});

      const primaryActions = computed(() => {
        const map = (props.config && props.config.primary_actions) || {};
        const next = map[session.value.status] || [];
        return next.map(status => ({
          status,
          ...Labels.formatStatus(status, 'session', props.config && props.config.terms),
        }));
      });

      const customerName = computed(() => {
        const c = session.value.customer;
        if (!c) return 'Mehmon';
        return c.full_name || c.phone || 'Mehmon';
      });

      const tableLabel = computed(() => {
        const t = session.value.current_table;
        if (!t) return null;
        const cap = t.capacity ? ` (${t.capacity} o'rin)` : '';
        return `Stol №${t.number}${cap}`;
      });

      const ordersList = computed(() => {
        const list = session.value.orders || [];
        return list.map(o => ({
          id: o.id,
          number: o.number,
          status: o.status,
          statusInfo: Labels.formatStatus(o.status, 'order'),
          total: Utils.formatMoney(o.total_amount),
        }));
      });

      const totals = computed(() => {
        const sc = Number(session.value.service_charge || 0);
        const tip = Number(session.value.tip_amount || 0);
        return {
          subtotal:      Utils.formatMoney(session.value.subtotal || 0),
          serviceCharge: Utils.formatMoney(sc),
          tip:           Utils.formatMoney(tip),
          total:         Utils.formatMoney(session.value.total_amount || 0),
          hasService:    sc > 0,
          hasTip:        tip > 0,
          hasExtras:     sc > 0 || tip > 0,
        };
      });

      const timeAgo = computed(() => Utils.relativeTime(session.value.opened_at));

      async function advance(toStatus) {
        await Actions.runAction({
          permission: 'orders.update',
          actionLabel: `Sessiyani "${Labels.formatStatus(toStatus, 'session').label}" holatiga o'tkazish`,
          action: () => Services.restaurantSessions.updateStatus(session.value.id, toStatus),
          onSuccess: (updated) => {
            // Backend qaytargan ob'ektni emit qilamiz — InboxList lokal ro'yxatni yangilaydi.
            emit('updated', updated);
          },
          silent: false,
          successMessage: 'Sessiya yangilandi',
        });
      }

      return {
        session, terms, primaryActions, customerName, tableLabel,
        ordersList, totals, timeAgo, advance,
      };
    },
    template: `
      <div class="card" :data-session-id="session.id">
        <!-- Yuqori qator: mijoz/stol/mehmonlar + status -->
        <div class="cluster cluster--between">
          <div class="stack stack--tight">
            <div class="text-medium" style="font-size: var(--text-lg);">{{ customerName }}</div>
            <div v-if="tableLabel" class="text-muted text-sm">{{ tableLabel }}</div>
            <div v-if="session.guest_count" class="text-muted text-sm">{{ session.guest_count }} mehmon</div>
          </div>
          <OrderStatusBadge :status="session.status" kind="session" :terms="terms" />
        </div>

        <!-- Orderlar inline summary -->
        <div v-if="ordersList.length" class="stack stack--tight" style="margin-top: var(--space-3);">
          <div class="text-muted text-sm">Buyurtmalar ({{ ordersList.length }})</div>
          <div
            v-for="o in ordersList"
            :key="o.id"
            class="cluster cluster--between"
            style="font-size: var(--text-sm);"
          >
            <div class="cluster cluster--tight">
              <span class="text-medium">#{{ o.number }}</span>
              <span class="text-muted">{{ o.statusInfo.label }}</span>
            </div>
            <span>{{ o.total }}</span>
          </div>
        </div>
        <div v-else class="text-muted text-sm" style="margin-top: var(--space-3);">
          Hali buyurtma yo'q
        </div>

        <!-- Totallar -->
        <div class="stack stack--tight" style="margin-top: var(--space-3);">
          <div v-if="totals.hasExtras" class="cluster cluster--between text-muted text-sm">
            <span>Subtotal</span><span>{{ totals.subtotal }}</span>
          </div>
          <div v-if="totals.hasService" class="cluster cluster--between text-muted text-sm">
            <span>Xizmat haqi</span><span>{{ totals.serviceCharge }}</span>
          </div>
          <div v-if="totals.hasTip" class="cluster cluster--between text-muted text-sm">
            <span>Choychaqa</span><span>{{ totals.tip }}</span>
          </div>
          <div class="cluster cluster--between">
            <span class="text-muted text-sm">{{ timeAgo }}</span>
            <span class="text-bold" style="font-size: var(--text-lg);">{{ totals.total }}</span>
          </div>
        </div>

        <!-- Action tugmalari -->
        <div v-if="primaryActions.length" class="cluster" style="margin-top: var(--space-3);">
          <button
            v-for="act in primaryActions"
            :key="act.status"
            type="button"
            class="btn btn--primary btn--sm btn--block"
            :data-action="'advance-to-' + act.status"
            @click="advance(act.status)"
          >{{ act.label }}</button>
        </div>
      </div>
    `,
  };
})();
