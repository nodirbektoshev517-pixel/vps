/**
 * CourierList.js — kuryerlar ro'yxati.
 *
 * Filter: status (available/on_route/busy/offline).
 * Real-time: courier.status_changed event'i orqali yangilanadi.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils, Labels, Composables } = window.Adminbot.Core;

  window.Adminbot.Components.CourierList = {
    name: 'CourierList',
    setup() {
      const items = ref([]);
      const loading = ref(true);
      const error = ref(null);
      const statusFilter = ref('all');

      const statuses = computed(() => ['all', ...Labels.listStatuses('courier')]);

      async function load() {
        loading.value = true;
        try {
          const r = await Services.courier.listCouriers({ status: statusFilter.value });
          items.value = (r && r.items) || [];
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; }
      }

      function changeFilter(s) { statusFilter.value = s; load(); }
      function statusInfo(s) {
        if (s === 'all') return { label: 'Hammasi', badge: 'neutral' };
        return Labels.formatStatus(s, 'courier');
      }
      const fullName = (c) => `${c.first_name} ${c.last_name || ''}`.trim();
      const initials = Utils.initials;

      // Real-time
      const { subscribe } = Composables.useEvents();
      function onCourierUpdated(ev) {
        const p = ev && ev.payload;
        if (!p || !p.id) return;
        const idx = items.value.findIndex(c => c.id === p.id);
        if (idx >= 0) items.value[idx] = { ...items.value[idx], ...p };
      }

      onMounted(() => {
        load();
        subscribe('courier.status_changed', onCourierUpdated);
        subscribe('courier.location_updated', onCourierUpdated);
      });

      return {
        items, loading, error, statusFilter, statuses,
        changeFilter, statusInfo, fullName, initials,
        relativeTime: Utils.relativeTime,
      };
    },
    template: `
      <div class="page" data-component="courier-list">
        <h1 class="heading">Kuryerlar</h1>

        <div class="cluster" data-component="courier-filters">
          <button
            v-for="s in statuses" :key="s"
            type="button"
            class="chip"
            :class="{ 'chip--active': statusFilter === s }"
            :data-status-filter="s"
            @click="changeFilter(s)"
          >{{ statusInfo(s).label }}</button>
        </div>

        <div v-if="loading && !items.length" class="list">
          <div v-for="i in 3" :key="i" class="list__row">
            <div class="skeleton" style="width: 40px; height: 40px; border-radius: 50%;"></div>
            <div class="list__main">
              <div class="skeleton" style="width: 60%; height: 14px;"></div>
            </div>
          </div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else-if="items.length" class="list">
          <div
            v-for="c in items" :key="c.id"
            class="list__row"
            :data-courier-id="c.id"
          >
            <div class="avatar">{{ initials(c) }}</div>
            <div class="list__main">
              <div class="list__title">{{ fullName(c) }}</div>
              <div class="list__subtitle">
                {{ c.vehicle }} • Bugun: {{ c.today_deliveries }} ta •
                {{ c.last_seen_at ? relativeTime(c.last_seen_at) : 'Hech qachon' }}
              </div>
            </div>
            <span class="badge" :class="'badge--' + statusInfo(c.status).badge" :data-status="c.status">
              {{ statusInfo(c.status).label }}
            </span>
          </div>
        </div>

        <div v-else class="empty">
          <div class="empty__icon">🛵</div>
          <div class="empty__title">Kuryer yo'q</div>
        </div>
      </div>
    `,
  };
})();
