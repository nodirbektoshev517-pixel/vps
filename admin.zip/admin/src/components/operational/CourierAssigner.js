/**
 * CourierAssigner.js — yetkazib berishga kuryer tayinlash.
 *
 * pending_assignment statusidagi yetkazib berishlar uchun mavjud kuryerlarni
 * tanlash mumkin. Offline kuryerga tayinlash mumkin emas (mock 409).
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils, Permissions, Actions, Labels, UI } = window.Adminbot.Core;

  window.Adminbot.Components.CourierAssigner = {
    name: 'CourierAssigner',
    setup() {
      const pendingDeliveries = ref([]);
      const couriers = ref([]);
      const loading = ref(true);
      const error = ref(null);
      const selecting = ref(null);    // {delivery} — kuryer tanlash dialog
      const canAssign = computed(() => Permissions.can('courier.assign'));

      async function load() {
        loading.value = true;
        try {
          const [d, c] = await Promise.all([
            Services.courier.listDeliveries({ status: 'pending_assignment' }),
            Services.courier.listCouriers(),
          ]);
          pendingDeliveries.value = (d && d.items) || [];
          couriers.value = (c && c.items) || [];
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; }
      }

      function startSelect(delivery) {
        if (!Permissions.require('courier.assign', 'Kuryer tayinlash')) return;
        selecting.value = { delivery };
      }
      function cancelSelect() { selecting.value = null; }

      async function assignTo(courier) {
        if (!selecting.value) return;
        const delivery = selecting.value.delivery;
        if (courier.status === 'offline') {
          UI.toast('Oflayn kuryerga tayinlab bo\'lmaydi', { type: 'warn' });
          return;
        }
        await Actions.runAction({
          permission: 'courier.assign',
          confirm: {
            title: 'Tayinlashni tasdiqlang',
            body: `Yetkazib berish #${delivery.order_number} → ${courier.first_name} ${courier.last_name}`,
            confirmText: 'Tayinlash', cancelText: 'Bekor',
          },
          action: () => Services.courier.assignDelivery(delivery.id, courier.id),
          onSuccess: async () => { selecting.value = null; await load(); },
          successMessage: 'Tayinlandi',
        });
      }

      const availableCouriers = computed(() =>
        couriers.value.filter(c => c.status !== 'offline')
      );

      function statusInfo(s) { return Labels.formatStatus(s, 'courier'); }
      const fullName = (c) => `${c.first_name} ${c.last_name || ''}`.trim();
      const initials = Utils.initials;

      onMounted(load);

      return {
        pendingDeliveries, couriers, loading, error, selecting, canAssign,
        availableCouriers, statusInfo, fullName, initials,
        startSelect, cancelSelect, assignTo,
        formatMoney: Utils.formatMoney,
        relativeTime: Utils.relativeTime,
      };
    },
    template: `
      <div class="page" data-component="courier-assigner">
        <h1 class="heading">Tayinlanmagan yetkazishlar</h1>

        <div v-if="loading && !pendingDeliveries.length" class="stack">
          <div v-for="i in 2" :key="i" class="card">
            <div class="skeleton" style="height: 50px;"></div>
          </div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else-if="pendingDeliveries.length" class="stack">
          <div
            v-for="d in pendingDeliveries" :key="d.id"
            class="card"
            :data-delivery-id="d.id"
          >
            <div class="cluster cluster--between">
              <div class="stack stack--tight">
                <div class="text-medium" style="font-size: var(--text-lg);">#{{ d.order_number }}</div>
                <div class="text-muted text-sm">{{ d.customer_name }}</div>
              </div>
              <div class="text-bold">{{ formatMoney(d.total) }}</div>
            </div>
            <div class="row" style="margin-top: var(--space-2);">
              <span style="font-size: var(--icon-md)">📍</span>
              <span class="text-sm text-truncate">{{ d.delivery_address }}</span>
            </div>
            <div class="text-muted text-sm" style="margin-top: var(--space-1);">
              {{ relativeTime(d.created_at) }} oldin
            </div>
            <button
              v-if="canAssign"
              type="button"
              class="btn btn--primary btn--block btn--sm"
              :data-action="'assign-' + d.id"
              @click="startSelect(d)"
              style="margin-top: var(--space-3);"
            >Kuryer tayinlash</button>
          </div>
        </div>

        <div v-else class="empty">
          <div class="empty__icon">✅</div>
          <div class="empty__title">Hammasiga kuryer tayinlangan</div>
        </div>

        <!-- Kuryer tanlash -->
        <div v-if="selecting" class="overlay" @click.self="cancelSelect" data-component="courier-picker">
          <div class="sheet">
            <div class="sheet__handle"></div>
            <div class="sheet__header">
              <div class="sheet__title">Kuryer tanlang</div>
            </div>
            <div class="list">
              <div
                v-for="c in availableCouriers" :key="c.id"
                class="list__row list__row--interactive"
                :data-pick-courier="c.id"
                @click="assignTo(c)"
              >
                <div class="avatar">{{ initials(c) }}</div>
                <div class="list__main">
                  <div class="list__title">{{ fullName(c) }}</div>
                  <div class="list__subtitle">{{ c.vehicle }} • Bugun: {{ c.today_deliveries }}</div>
                </div>
                <span class="badge" :class="'badge--' + statusInfo(c.status).badge">
                  {{ statusInfo(c.status).label }}
                </span>
              </div>
            </div>
            <button class="btn btn--ghost btn--block" @click="cancelSelect" style="margin-top: var(--space-3);">Bekor</button>
          </div>
        </div>
      </div>
    `,
  };
})();
