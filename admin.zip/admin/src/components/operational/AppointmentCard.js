/**
 * AppointmentCard.js — uchrashuv kartochkasi.
 *
 * InboxList ichida ham, alohida ham ishlatilishi mumkin (OrderCard kabi).
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { computed } = Vue;
  const { Utils, Services, Actions, Labels } = window.Adminbot.Core;

  window.Adminbot.Components.AppointmentCard = {
    name: 'AppointmentCard',
    props: {
      order: { type: Object, required: true },
      config: { type: Object, default: () => ({}) },
    },
    emits: ['updated'],
    setup(props, { emit }) {
      const appointment = computed(() => props.order);

      const terms = computed(() => (props.config && props.config.terms) || {});
      const statusInfo = computed(() => Labels.formatStatus(appointment.value.status, 'appointment', terms.value));

      const primaryActions = computed(() => {
        const map = (props.config && props.config.primary_actions) || {};
        const next = map[appointment.value.status] || [];
        return next.map(s => ({
          status: s,
          ...Labels.formatStatus(s, 'appointment', terms.value),
        }));
      });

      const fmtTime = (iso) => new Date(iso).toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' });
      const fmtDate = (iso) => Utils.formatDate(iso, { time: false });

      async function advance(toStatus) {
        await Actions.runAction({
          permission: 'appointments.update',
          actionLabel: `Status "${Labels.formatStatus(toStatus, 'appointment').label}"`,
          action: () => Services.appointment.updateAppointmentStatus(appointment.value.id, toStatus),
          onSuccess: (updated) => emit('updated', updated),
          successMessage: 'Yangilandi',
        });
      }

      return { appointment, statusInfo, primaryActions, fmtTime, fmtDate, advance };
    },
    template: `
      <div class="card"
        :data-appointment-id="appointment.id"
        :data-order-id="appointment.id"
      >
        <div class="cluster cluster--between">
          <div class="stack stack--tight">
            <div class="text-medium" style="font-size: var(--text-lg);">#{{ appointment.number }}</div>
            <div class="text-muted text-sm">{{ appointment.customer_name }}</div>
          </div>
          <span class="badge" :class="'badge--' + statusInfo.badge" :data-status="appointment.status">
            {{ statusInfo.label }}
          </span>
        </div>

        <div class="stack stack--tight" style="margin-top: var(--space-3);">
          <div class="row">
            <span style="font-size: var(--icon-md)">✂️</span>
            <span class="text-sm">{{ appointment.service_name }}</span>
          </div>
          <div class="row">
            <span style="font-size: var(--icon-md)">🕐</span>
            <span class="text-sm">
              {{ fmtDate(appointment.start_time) }} {{ fmtTime(appointment.start_time) }} • {{ appointment.duration_min }} daq
            </span>
          </div>
          <div v-if="appointment.customer_phone" class="row">
            <span style="font-size: var(--icon-md)">📞</span>
            <span class="text-sm">{{ appointment.customer_phone }}</span>
          </div>
        </div>

        <div v-if="primaryActions.length" class="cluster" style="margin-top: var(--space-3);">
          <button
            v-for="act in primaryActions" :key="act.status"
            type="button"
            class="btn btn--primary btn--sm btn--block"
            :data-action="'advance-to-' + act.status"
            @click="advance(act.status)"
          >{{ act.label }}</button>
        </div>
      </div>
    `,
  };
})();
