/**
 * DeliveryStatusBoard.js — yetkazib berish dashboard'i.
 *
 * Har holat bo'yicha count: pending_assignment, assigned, on_route, delivered.
 * Tezkor xulosa, real-time delivery.assigned event'i bilan yangilanadi.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils, Composables } = window.Adminbot.Core;

  const STATUS_LABELS = {
    pending_assignment: { label: 'Tayinlanmagan', badge: 'warning', icon: '⏳' },
    assigned:           { label: 'Tayinlangan',   badge: 'info',    icon: '👤' },
    on_route:           { label: 'Yo\'lda',       badge: 'primary', icon: '🛵' },
    delivered:          { label: 'Yetkazildi',    badge: 'success', icon: '✅' },
  };

  window.Adminbot.Components.DeliveryStatusBoard = {
    name: 'DeliveryStatusBoard',
    setup() {
      const deliveries = ref([]);
      const loading = ref(true);
      const error = ref(null);

      async function load() {
        loading.value = true;
        try {
          // Hamma yetkazib berishlar
          const r = await Services.courier.listDeliveries({ page_size: 50 });
          deliveries.value = (r && r.items) || [];
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; }
      }

      const stats = computed(() => {
        const counts = {
          pending_assignment: 0,
          assigned: 0,
          on_route: 0,
          delivered: 0,
        };
        let totalRevenue = 0;
        for (const d of deliveries.value) {
          if (counts[d.status] != null) counts[d.status]++;
          if (d.status === 'delivered') totalRevenue += (d.total || 0);
        }
        return {
          counts,
          total: deliveries.value.length,
          active: counts.pending_assignment + counts.assigned + counts.on_route,
          totalRevenue,
        };
      });

      const cards = computed(() =>
        Object.entries(STATUS_LABELS).map(([key, meta]) => ({
          key,
          ...meta,
          count: stats.value.counts[key] || 0,
        }))
      );

      // Real-time — yangi tayinlash yoki status o'zgartish
      const { subscribe } = Composables.useEvents();
      onMounted(() => {
        load();
        subscribe('delivery.assigned', () => load());
      });

      return {
        stats, cards, loading, error,
        formatMoney: Utils.formatMoney,
      };
    },
    template: `
      <div class="page" data-component="delivery-status-board">
        <h1 class="heading">Yetkazib berishlar</h1>

        <div v-if="loading && !stats.total" class="grid grid--2">
          <div v-for="i in 4" :key="i" class="card">
            <div class="skeleton" style="height: 50px;"></div>
          </div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else>
          <div class="grid grid--2" data-component="status-cards">
            <div
              v-for="card in cards" :key="card.key"
              class="card"
              :data-status-card="card.key"
            >
              <div class="text-muted text-sm">{{ card.label }}</div>
              <div class="cluster cluster--between" style="margin-top: var(--space-2); align-items: baseline;">
                <div class="text-bold" style="font-size: var(--text-xxl);">{{ card.count }}</div>
                <div style="font-size: 28px;">{{ card.icon }}</div>
              </div>
            </div>
          </div>

          <div class="card" style="margin-top: var(--space-3);" data-component="summary-card">
            <div class="cluster cluster--between">
              <div>
                <div class="text-muted text-sm">Jami faol</div>
                <div class="text-bold" style="font-size: var(--text-xl);">{{ stats.active }}</div>
              </div>
              <div>
                <div class="text-muted text-sm">Yetkazilgan tushum</div>
                <div class="text-bold" style="font-size: var(--text-xl);">{{ formatMoney(stats.totalRevenue) }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `,
  };
})();
