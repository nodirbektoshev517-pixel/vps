/**
 * ImageUploader.js — xavfsiz rasm tanlash va birlamchi siqish komponenti.
 *
 * Backendga yuborish ProductCRUD ichida mahsulot ID bilan bajariladi.
 * Bu komponent 5 tagacha rasmni navbat bilan siqadi va staging holatida ushlaydi.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onBeforeUnmount } = Vue;

  const ALLOWED_MIME = ['image/jpeg', 'image/jpg', 'image/pjpeg', 'image/png', 'image/webp'];
  const MAX_INPUT_SIZE_MB = 8;
  const MAX_PIXELS = 20_000_000;
  const MAX_SIDE = 1600;
  const MAX_OUTPUT_BYTES = 1.5 * 1024 * 1024;
  const QUALITY_STEPS = [0.82, 0.74, 0.66, 0.58];

  function fileNameFor(name, mime) {
    const base = String(name || 'product').replace(/\.[^.]+$/, '');
    const ext = mime === 'image/webp' ? 'webp' : 'jpg';
    return `${base.replace(/[^a-z0-9_-]+/gi, '-').slice(0, 48) || 'product'}.${ext}`;
  }

  function imageUrl(img) {
    return img && (
      img.url || img.card_url || img.detail_url || img.thumb_url || img.image_url
    ) || null;
  }

  function hasAllowedImageType(file) {
    if (ALLOWED_MIME.includes(file.type)) return true;
    if (!file.type && /\.(jpe?g|png|webp)$/i.test(file.name || '')) return true;
    return false;
  }

  function readAsDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = e => resolve(e.target && e.target.result);
      reader.onerror = () => reject(new Error('Faylni o\'qib bo\'lmadi'));
      reader.readAsDataURL(file);
    });
  }

  function loadImageFromSrc(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error('Rasmni o\'qib bo\'lmadi'));
      img.src = src;
    });
  }

  async function loadImage(file) {
    try {
      const dataUrl = await readAsDataUrl(file);
      return { img: await loadImageFromSrc(dataUrl), revoke: null };
    } catch (firstErr) {
      const blobUrl = URL.createObjectURL(file);
      try {
        return { img: await loadImageFromSrc(blobUrl), revoke: () => URL.revokeObjectURL(blobUrl) };
      } catch (secondErr) {
        URL.revokeObjectURL(blobUrl);
        throw firstErr || secondErr;
      }
    }
  }

  function canvasToBlob(canvas, mime, quality) {
    return new Promise(resolve => canvas.toBlob(resolve, mime, quality));
  }

  async function compressedBlob(canvas) {
    let fallback = null;
    for (const quality of QUALITY_STEPS) {
      const webp = await canvasToBlob(canvas, 'image/webp', quality);
      if (webp) {
        fallback = { blob: webp, mime: 'image/webp' };
        if (webp.size <= MAX_OUTPUT_BYTES) return fallback;
      }
    }
    for (const quality of QUALITY_STEPS) {
      const jpeg = await canvasToBlob(canvas, 'image/jpeg', quality);
      if (jpeg) {
        fallback = { blob: jpeg, mime: 'image/jpeg' };
        if (jpeg.size <= MAX_OUTPUT_BYTES) return fallback;
      }
    }
    if (fallback) return fallback;
    throw new Error('Rasmni siqib bo\'lmadi');
  }

  async function compressImage(file) {
    const loaded = await loadImage(file);
    const { img, revoke } = loaded;
    try {
      if (!img.naturalWidth || !img.naturalHeight) {
        throw new Error('Rasm o\'lchami aniqlanmadi');
      }
      if (img.naturalWidth * img.naturalHeight > MAX_PIXELS) {
        throw new Error('Rasm o\'lchami juda katta');
      }

      const ratio = Math.min(1, MAX_SIDE / Math.max(img.naturalWidth, img.naturalHeight));
      const width = Math.max(1, Math.round(img.naturalWidth * ratio));
      const height = Math.max(1, Math.round(img.naturalHeight * ratio));
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d', { alpha: false });
      if (!ctx) throw new Error('Rasmni siqib bo\'lmadi');
      ctx.drawImage(img, 0, 0, width, height);

      const packed = await compressedBlob(canvas);
      const compressed = new File(
        [packed.blob],
        fileNameFor(file.name, packed.mime),
        { type: packed.mime }
      );
      return { file: compressed, width, height, size: compressed.size };
    } finally {
      if (revoke) revoke();
    }
  }

  window.Adminbot.Components.ImageUploader = {
    name: 'ImageUploader',
    props: {
      modelValue: { type: String, default: null },
      images: { type: Array, default: () => [] },
      maxImages: { type: Number, default: 5 },
    },
    emits: ['update:modelValue', 'images-ready', 'existing-image-remove'],
    setup(props, { emit }) {
      const fileInput = ref(null);
      const uploading = ref(false);
      const error = ref(null);
      const staged = ref([]);

      const existingItems = computed(() => (props.images || [])
        .map(img => ({ kind: 'existing', id: String(img.id), url: imageUrl(img) }))
        .filter(item => item.id && item.url));

      const previewItems = computed(() => existingItems.value.concat(staged.value));
      const remainingSlots = computed(() => Math.max(0, props.maxImages - previewItems.value.length));

      function emitStaged() {
        emit('images-ready', staged.value.map(item => ({
          file: item.file,
          width: item.width,
          height: item.height,
          size: item.size,
        })));
        const first = previewItems.value[0];
        emit('update:modelValue', first && first.url || null);
      }

      function pick() {
        if (remainingSlots.value <= 0 || uploading.value) return;
        if (fileInput.value) fileInput.value.click();
      }

      function revokeStaged(item) {
        if (item && item.url) URL.revokeObjectURL(item.url);
      }

      function validateFile(file) {
        if (!hasAllowedImageType(file)) {
          return 'Faqat jpeg, png, webp';
        }
        if (file.size > MAX_INPUT_SIZE_MB * 1024 * 1024) {
          return `Hajm ${MAX_INPUT_SIZE_MB} MB dan oshmasin`;
        }
        return null;
      }

      async function onChange(ev) {
        error.value = null;
        const files = Array.from(ev.target.files || []);
        if (!files.length) return;

        const slots = remainingSlots.value;
        if (slots <= 0) {
          error.value = `${props.maxImages} tagacha rasm qo'shish mumkin`;
          ev.target.value = '';
          return;
        }

        uploading.value = true;
        try {
          const selected = files.slice(0, slots);
          for (const file of selected) {
            const validationError = validateFile(file);
            if (validationError) {
              error.value = validationError;
              continue;
            }
            const result = await compressImage(file);
            staged.value.push({
              kind: 'staged',
              id: `${Date.now()}_${Math.random().toString(36).slice(2)}`,
              url: URL.createObjectURL(result.file),
              file: result.file,
              width: result.width,
              height: result.height,
              size: result.size,
            });
          }
          if (files.length > slots) {
            error.value = `${props.maxImages} tagacha rasm qo'shish mumkin`;
          }
          emitStaged();
        } catch (err) {
          error.value = err && err.message || 'Rasmni tayyorlab bo\'lmadi';
        } finally {
          uploading.value = false;
          ev.target.value = '';
        }
      }

      function remove(item) {
        if (!item) return;
        if (item.kind === 'staged') {
          const idx = staged.value.findIndex(row => row.id === item.id);
          if (idx >= 0) {
            revokeStaged(staged.value[idx]);
            staged.value.splice(idx, 1);
            emitStaged();
          }
          return;
        }
        emit('existing-image-remove', item.id);
      }

      onBeforeUnmount(() => {
        staged.value.forEach(revokeStaged);
      });

      return {
        fileInput, uploading, error, previewItems, remainingSlots,
        pick, onChange, remove,
      };
    },
    template: `
      <div class="stack stack--tight" data-component="image-uploader">
        <div
          v-if="previewItems.length"
          class="cluster"
          style="gap: var(--space-2); flex-wrap: wrap;"
        >
          <div
            v-for="item in previewItems"
            :key="item.kind + '-' + item.id"
            style="width: 78px; height: 78px; border-radius: var(--radius-md); overflow: hidden; position: relative; background: var(--color-surface-muted);"
          >
            <img :src="item.url" alt="Rasm" style="width: 100%; height: 100%; object-fit: cover; display: block;">
            <button
              type="button"
              class="btn btn--ghost btn--icon btn--sm"
              style="position: absolute; top: 3px; right: 3px; min-width: 26px; height: 26px; background: rgba(0,0,0,0.62); color: #fff;"
              data-action="remove-image"
              @click="remove(item)"
              aria-label="O'chirish"
            >x</button>
          </div>
        </div>
        <button
          type="button"
          class="btn btn--secondary btn--block"
          data-action="pick-image"
          :disabled="uploading || remainingSlots <= 0"
          @click="pick"
        >
          <span v-if="uploading">Tayyorlanmoqda...</span>
          <span v-else>Rasm qo'shish</span>
        </button>
        <input
          ref="fileInput"
          type="file"
          accept="image/jpeg,image/jpg,image/png,image/webp"
          multiple
          style="display: none;"
          @change="onChange"
        />
        <div v-if="error" class="text-danger text-sm">{{ error }}</div>
      </div>
    `,
  };
})();
