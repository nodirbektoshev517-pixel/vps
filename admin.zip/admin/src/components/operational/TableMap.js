/**
 * TableMap.js — restoran stollarining vizual xaritasi.
 *
 * Zal bo'yicha guruhlangan, har stol holati (free/reserved/occupied/cleaning)
 * rangli badge bilan ko'rsatiladi. Tap = status menyu.
 *
 * Real-time: table.status_changed event bilan avtomatik yangilanadi.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils, Labels, Composables, UI, Actions } = window.Adminbot.Core;

  const STATUSES = ['free', 'reserved', 'occupied', 'cleaning'];

  window.Adminbot.Components.TableMap = {
    name: 'TableMap',
    setup() {
      const tables = ref([]);
      const halls = ref([]);
      const loading = ref(true);
      const error = ref(null);
      const selected = ref(null);   // status menyu uchun

      async function load() {
        loading.value = true;
        try {
          const r = await Services.restaurant.listTables();
          tables.value = (r && r.items) || [];
          halls.value = (r && r.halls) || [];
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; }
      }

      function statusInfo(s) { return Labels.formatStatus(s, 'table'); }

      // Zal bo'yicha guruhlash (computed — template ichida og'ir filter YO'Q)
      const tablesByHall = computed(() => {
        const map = {};
        for (const h of halls.value) map[h.id] = [];
        for (const t of tables.value) {
          if (!map[t.hall_id]) map[t.hall_id] = [];
          map[t.hall_id].push(t);
        }
        return map;
      });

      function openMenu(t) { selected.value = t; }
      function closeMenu() { selected.value = null; }

      async function setStatus(newStatus) {
        const t = selected.value;
        if (!t) return;
        await Actions.runAction({
          permission: 'restaurant.tables.manage',
          action: () => Services.restaurant.setTableStatus(t.id, newStatus),
          onSuccess: () => {
            selected.value = null;
            // Lokal yangilash — event push ham keladi, lekin instant feedback uchun
            const idx = tables.value.findIndex(x => x.id === t.id);
            if (idx >= 0) tables.value[idx] = { ...tables.value[idx], status: newStatus };
          },
          successMessage: 'Yangilandi',
        });
      }

      // Real-time
      const { subscribe } = Composables.useEvents();
      function onTableChanged(ev) {
        const p = ev && ev.payload;
        if (!p || !p.id) return;
        const idx = tables.value.findIndex(t => t.id === p.id);
        if (idx >= 0) tables.value[idx] = { ...tables.value[idx], ...p };
      }

      onMounted(() => {
        load();
        subscribe('table.status_changed', onTableChanged);
      });

      return {
        tables, halls, tablesByHall, loading, error, selected, STATUSES,
        statusInfo, openMenu, closeMenu, setStatus,
      };
    },
    template: `
      <div class="page" data-component="table-map">
        <h1 class="heading">Stollar xaritasi</h1>

        <div v-if="loading && !tables.length" class="stack">
          <div v-for="i in 2" :key="i" class="card">
            <div class="skeleton" style="width: 30%; height: 16px;"></div>
            <div class="skeleton" style="width: 100%; height: 80px; margin-top: 12px;"></div>
          </div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else class="stack">
          <div v-for="hall in halls" :key="hall.id" class="card" :data-hall-id="hall.id">
            <div class="cluster cluster--between">
              <div class="text-medium">{{ hall.name }}</div>
              <div class="text-muted text-sm">{{ hall.capacity }} ta o'rin</div>
            </div>
            <div class="grid grid--3" style="margin-top: var(--space-3);" data-component="table-grid">
              <div
                v-for="t in tablesByHall[hall.id]" :key="t.id"
                class="card card--interactive"
                :class="'card--' + statusInfo(t.status).badge"
                :data-table-id="t.id"
                :data-table-status="t.status"
                @click="openMenu(t)"
                style="text-align: center; cursor: pointer;"
              >
                <div class="text-bold" style="font-size: var(--text-xl);">#{{ t.number }}</div>
                <div class="text-muted text-sm">{{ t.seats }} kishi</div>
                <span class="badge" :class="'badge--' + statusInfo(t.status).badge" style="margin-top: 8px;">
                  {{ statusInfo(t.status).label }}
                </span>
              </div>
            </div>
          </div>
        </div>

        <!-- Status menyu overlay -->
        <div v-if="selected" class="overlay" @click.self="closeMenu" data-component="table-status-menu">
          <div class="sheet">
            <div class="sheet__handle"></div>
            <div class="sheet__header">
              <div class="sheet__title">Stol #{{ selected.number }} holati</div>
            </div>
            <div class="stack">
              <button
                v-for="s in STATUSES" :key="s"
                type="button"
                class="btn btn--block"
                :class="selected.status === s ? 'btn--primary' : 'btn--secondary'"
                :data-set-status="s"
                @click="setStatus(s)"
              >{{ statusInfo(s).label }}</button>
              <button class="btn btn--ghost btn--block" @click="closeMenu">Bekor</button>
            </div>
          </div>
        </div>
      </div>
    `,
  };
})();
