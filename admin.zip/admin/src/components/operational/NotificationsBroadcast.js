/**
 * NotificationsBroadcast.js — mijozlarga xabar yuborish.
 *
 * Oqim: yozish → preview → confirm → send.
 * Permission: broadcast.send (Permissions.require + runAction).
 * Backend rate limit va audit log (mock'da audit log avtomatik yoziladi).
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed } = Vue;
  const { Services, Utils, Permissions, Actions, UI } = window.Adminbot.Core;

  window.Adminbot.Components.NotificationsBroadcast = {
    name: 'NotificationsBroadcast',
    setup() {
      const message = ref('');
      const audience = ref('all');     // all | active
      const sending = ref(false);

      const charCount = computed(() => message.value.length);
      const canSend = computed(() =>
        Permissions.can('broadcast.send') && message.value.length >= 5 && message.value.length <= 500
      );

      async function send() {
        if (!Permissions.require('broadcast.send', 'Xabar yuborish')) return;
        // Confirm — backend audit log ekanligi sababli foydalanuvchini tasdiqlaymiz
        const ok = await UI.confirm({
          title: 'Xabarni yuborishni tasdiqlang',
          body: `"${message.value.slice(0, 100)}${message.value.length > 100 ? '...' : ''}"\n\nQabul qiluvchilar: ${audience.value === 'all' ? 'barcha mijozlar' : 'faol mijozlar'}`,
          confirmText: 'Yuborish',
          cancelText: 'Bekor',
        });
        if (!ok) return;
        await Actions.runAction({
          permission: 'broadcast.send',
          action: () => Services.broadcast.send({ message: message.value, audience: audience.value }),
          onSuccess: (r) => {
            UI.toast(`${r.sent_to} ta mijozga yuborildi`, { type: 'success' });
            message.value = '';
          },
          loading: sending,
          silent: true,
        });
      }

      return { message, audience, sending, charCount, canSend, send };
    },
    template: `
      <div class="page" data-component="broadcast-view">
        <h1 class="heading">Xabar yuborish</h1>
        <div class="subheading">Mijozlarga Telegram orqali xabar yuboring.</div>

        <div class="card stack">
          <div class="field">
            <label class="field__label">Kim olishi kerak?</label>
            <select v-model="audience" data-field="audience">
              <option value="all">Barcha mijozlar</option>
              <option value="active">Faol mijozlar (oxirgi 30 kun)</option>
            </select>
          </div>

          <div class="field">
            <div class="cluster cluster--between">
              <label class="field__label">Xabar matni</label>
              <span class="text-muted text-sm">{{ charCount }} / 500</span>
            </div>
            <textarea
              v-model="message"
              rows="5"
              maxlength="500"
              placeholder="Salom! Bugun do'konimizda yangi mahsulotlar..."
              data-field="message"
              style="resize: vertical;"
            ></textarea>
          </div>

          <button
            type="button"
            class="btn btn--primary btn--block"
            data-action="send-broadcast"
            :disabled="!canSend || sending"
            @click="send"
          >{{ sending ? 'Yuborilmoqda...' : 'Yuborish' }}</button>
        </div>

        <div class="card text-muted text-sm">
          <strong>Eslatma.</strong> Har xabar audit log'ga yoziladi.
          Backend rate limit (kuniga 5 ta) bilan cheklaydi.
        </div>
      </div>
    `,
  };
})();
