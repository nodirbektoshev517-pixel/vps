/**
 * SpecialistCRUD.js — appointment biznes turi mutaxassislari (CRUD).
 *
 * Har mutaxassis: ism, qaysi xizmatlarni qiladi (services array), ish vaqti, active.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils, Permissions, Actions, UI } = window.Adminbot.Core;

  window.Adminbot.Components.SpecialistCRUD = {
    name: 'SpecialistCRUD',
    setup() {
      const items = ref([]);
      const allServices = ref([]);
      const loading = ref(true);
      const error = ref(null);
      const editing = ref(null);
      const canManage = computed(() => Permissions.can('appointment.specialists.manage'));

      async function loadServices() {
        try {
          const r = await Services.appointment.listServices();
          allServices.value = (r && r.items) || [];
        } catch (e) {}
      }

      async function load() {
        loading.value = true;
        try {
          const r = await Services.appointment.listSpecialists();
          items.value = (r && r.items) || [];
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; }
      }

      function startCreate() {
        if (!Permissions.require('appointment.specialists.manage', 'Mutaxassis qo\'shish')) return;
        editing.value = { first_name: '', last_name: '', services: [], working_hours: '09:00-18:00', active: true };
      }
      function startEdit(s) {
        if (!Permissions.require('appointment.specialists.manage', 'Mutaxassis tahrirlash')) return;
        editing.value = { ...s, services: [...(s.services || [])] };
      }
      function cancelEdit() { editing.value = null; }

      function toggleService(svcId) {
        if (!editing.value) return;
        const idx = editing.value.services.indexOf(svcId);
        if (idx >= 0) editing.value.services.splice(idx, 1);
        else editing.value.services.push(svcId);
      }

      async function saveEdit() {
        const d = editing.value;
        if (!d || !d.first_name) { UI.toast('Ism majburiy', { type: 'warn' }); return; }
        const isNew = !d.id;
        await Actions.runAction({
          permission: 'appointment.specialists.manage',
          action: () => isNew
            ? Services.appointment.createSpecialist(d)
            : Services.appointment.updateSpecialist(d.id, d),
          onSuccess: async () => { editing.value = null; await load(); },
          successMessage: isNew ? 'Qo\'shildi' : 'Yangilandi',
        });
      }

      async function remove(s) {
        await Actions.runAction({
          permission: 'appointment.specialists.manage',
          confirm: {
            title: 'O\'chirishni tasdiqlang',
            body: `${s.first_name} ${s.last_name} o'chirilsinmi?`,
            confirmText: 'O\'chirish', cancelText: 'Bekor',
          },
          action: () => Services.appointment.deleteSpecialist(s.id),
          onSuccess: async () => { await load(); },
          successMessage: 'O\'chirildi',
        });
      }

      function serviceName(id) {
        const s = allServices.value.find(x => x.id === id);
        return s ? s.name : id;
      }

      const fullName = (s) => `${s.first_name} ${s.last_name || ''}`.trim();
      const initials = Utils.initials;

      onMounted(async () => { await loadServices(); await load(); });

      return {
        items, allServices, loading, error, editing, canManage,
        startCreate, startEdit, cancelEdit, saveEdit, remove, toggleService,
        serviceName, fullName, initials,
      };
    },
    template: `
      <div class="page" data-component="specialist-crud">
        <div class="cluster cluster--between">
          <h1 class="heading">Mutaxassislar</h1>
          <button v-if="canManage" type="button" class="btn btn--primary btn--sm"
            data-action="add-specialist" @click="startCreate">+ Yangi</button>
        </div>

        <div v-if="loading && !items.length" class="list">
          <div v-for="i in 3" :key="i" class="list__row">
            <div class="skeleton" style="width: 40px; height: 40px; border-radius: 50%;"></div>
            <div class="list__main">
              <div class="skeleton" style="width: 60%; height: 14px;"></div>
            </div>
          </div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else-if="items.length" class="list">
          <div
            v-for="s in items" :key="s.id"
            class="list__row"
            :data-specialist-id="s.id"
          >
            <div class="avatar">{{ initials(s) }}</div>
            <div class="list__main">
              <div class="list__title">{{ fullName(s) }}</div>
              <div class="list__subtitle">
                {{ s.services.map(serviceName).join(', ') || 'Xizmat yo\\'q' }} • {{ s.working_hours }}
              </div>
            </div>
            <span v-if="!s.active" class="badge badge--neutral">Faol emas</span>
            <button v-if="canManage" type="button" class="btn btn--ghost btn--icon btn--sm"
              :data-action="'edit-spc-' + s.id" @click="startEdit(s)" aria-label="Tahrirlash">✎</button>
            <button v-if="canManage" type="button" class="btn btn--ghost btn--icon btn--sm"
              :data-action="'del-spc-' + s.id" @click="remove(s)" aria-label="O'chirish">🗑</button>
          </div>
        </div>

        <div v-else class="empty">
          <div class="empty__icon">👤</div>
          <div class="empty__title">Mutaxassis yo'q</div>
        </div>

        <div v-if="editing" class="overlay" @click.self="cancelEdit" data-component="specialist-form">
          <div class="sheet">
            <div class="sheet__handle"></div>
            <div class="sheet__header">
              <div class="sheet__title">{{ editing.id ? 'Tahrirlash' : 'Yangi mutaxassis' }}</div>
            </div>
            <div class="stack">
              <div class="field">
                <label class="field__label">Ism</label>
                <input type="text" v-model="editing.first_name" data-field="spc-first" />
              </div>
              <div class="field">
                <label class="field__label">Familiya</label>
                <input type="text" v-model="editing.last_name" data-field="spc-last" />
              </div>
              <div class="field">
                <label class="field__label">Ish vaqti</label>
                <input type="text" v-model="editing.working_hours" placeholder="09:00-18:00" data-field="spc-hours" />
              </div>
              <div class="field">
                <label class="field__label">Xizmatlar</label>
                <div class="cluster" style="flex-wrap: wrap;">
                  <button
                    v-for="svc in allServices" :key="svc.id"
                    type="button"
                    class="chip"
                    :class="{ 'chip--active': editing.services.includes(svc.id) }"
                    :data-toggle-svc="svc.id"
                    @click="toggleService(svc.id)"
                  >{{ svc.name }}</button>
                </div>
              </div>
              <div class="field">
                <label class="cluster">
                  <input type="checkbox" v-model="editing.active" data-field="spc-active" />
                  <span>Faol</span>
                </label>
              </div>
              <div class="cluster cluster--end">
                <button class="btn btn--secondary" @click="cancelEdit">Bekor</button>
                <button class="btn btn--primary" data-action="save-specialist" @click="saveEdit">Saqlash</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    `,
  };
})();
