/**
 * WalkInQueue.js — Navbatdagi tashrif buyurganlar (oldindan bron qilinmagan).
 *
 * Tezkor qo'shish, navbatdan chiqarish.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils, Permissions, Actions, UI } = window.Adminbot.Core;

  window.Adminbot.Components.WalkInQueue = {
    name: 'WalkInQueue',
    setup() {
      const items = ref([]);
      const allServices = ref([]);
      const loading = ref(true);
      const error = ref(null);
      const editing = ref(null);
      const canManage = computed(() => Permissions.can('appointment.walkin.manage'));

      async function loadServices() {
        try { const r = await Services.appointment.listServices(); allServices.value = (r && r.items) || []; }
        catch (e) {}
      }

      async function load() {
        loading.value = true;
        try {
          const r = await Services.appointment.listWalkIn();
          items.value = (r && r.items) || [];
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; }
      }

      function startCreate() {
        if (!Permissions.require('appointment.walkin.manage', 'Navbat qo\'shish')) return;
        editing.value = { customer_name: '', service_id: allServices.value[0] && allServices.value[0].id || null };
      }
      function cancelEdit() { editing.value = null; }

      async function saveEdit() {
        const d = editing.value;
        if (!d || !d.customer_name) { UI.toast('Mijoz ismi majburiy', { type: 'warn' }); return; }
        await Actions.runAction({
          permission: 'appointment.walkin.manage',
          action: () => Services.appointment.addWalkIn(d),
          onSuccess: async () => { editing.value = null; await load(); },
          successMessage: 'Navbatga qo\'shildi',
        });
      }

      async function remove(w) {
        await Actions.runAction({
          permission: 'appointment.walkin.manage',
          confirm: {
            title: 'Navbatdan chiqarish',
            body: `${w.customer_name} navbatdan chiqarilsinmi?`,
            confirmText: 'Chiqarish', cancelText: 'Bekor',
          },
          action: () => Services.appointment.removeWalkIn(w.id),
          onSuccess: async () => { await load(); },
          successMessage: 'Chiqarildi',
        });
      }

      function serviceName(id) {
        const s = allServices.value.find(x => x.id === id);
        return s ? s.name : '—';
      }

      onMounted(async () => { await loadServices(); await load(); });

      return {
        items, allServices, loading, error, editing, canManage,
        startCreate, cancelEdit, saveEdit, remove, serviceName,
        relativeTime: Utils.relativeTime,
      };
    },
    template: `
      <div class="page" data-component="walk-in-queue">
        <div class="cluster cluster--between">
          <h1 class="heading">Navbat</h1>
          <button v-if="canManage" type="button" class="btn btn--primary btn--sm"
            data-action="add-walkin" @click="startCreate">+ Mehmon</button>
        </div>

        <div v-if="loading && !items.length" class="list">
          <div v-for="i in 2" :key="i" class="list__row">
            <div class="skeleton" style="width: 60%; height: 14px;"></div>
          </div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else-if="items.length" class="list">
          <div
            v-for="(w, idx) in items" :key="w.id"
            class="list__row"
            :data-walkin-id="w.id"
          >
            <div class="list__icon">{{ idx + 1 }}</div>
            <div class="list__main">
              <div class="list__title">{{ w.customer_name }}</div>
              <div class="list__subtitle">
                {{ serviceName(w.service_id) }} • {{ relativeTime(w.queued_at) }}
              </div>
            </div>
            <div class="list__trail text-medium">{{ w.estimated_wait_min }} daq</div>
            <button v-if="canManage" type="button" class="btn btn--ghost btn--icon btn--sm"
              :data-action="'remove-walkin-' + w.id" @click="remove(w)" aria-label="Chiqarish">✕</button>
          </div>
        </div>

        <div v-else class="empty">
          <div class="empty__icon">👥</div>
          <div class="empty__title">Navbat bo'sh</div>
        </div>

        <div v-if="editing" class="overlay" @click.self="cancelEdit" data-component="walkin-form">
          <div class="sheet">
            <div class="sheet__handle"></div>
            <div class="sheet__header">
              <div class="sheet__title">Navbatga qo'shish</div>
            </div>
            <div class="stack">
              <div class="field">
                <label class="field__label">Mijoz ismi</label>
                <input type="text" v-model="editing.customer_name" data-field="walkin-name" />
              </div>
              <div class="field">
                <label class="field__label">Xizmat</label>
                <select v-model="editing.service_id" data-field="walkin-svc">
                  <option v-for="s in allServices" :key="s.id" :value="s.id">{{ s.name }}</option>
                </select>
              </div>
              <div class="cluster cluster--end">
                <button class="btn btn--secondary" @click="cancelEdit">Bekor</button>
                <button class="btn btn--primary" data-action="save-walkin" @click="saveEdit">Qo'shish</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    `,
  };
})();
