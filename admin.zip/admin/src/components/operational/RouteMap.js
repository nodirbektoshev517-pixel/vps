/**
 * RouteMap.js — kuryer marshrutining sodda ko'rinishi.
 *
 * Real xarita kutubxonasi YO'Q (yetkazib berishlar oddiy stops sequence sifatida).
 * Bir kuryerning bugungi tayinlangan/yo'lda buyurtmalari tartibida.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils, Labels } = window.Adminbot.Core;

  window.Adminbot.Components.RouteMap = {
    name: 'RouteMap',
    props: { courierId: { type: String, default: null } },
    setup(props) {
      const allDeliveries = ref([]);
      const allCouriers = ref([]);
      const loading = ref(true);
      const error = ref(null);
      const selectedCourier = ref(props.courierId);

      async function load() {
        loading.value = true;
        try {
          const [c, d] = await Promise.all([
            Services.courier.listCouriers(),
            Services.courier.listDeliveries(),    // hammasi (filter qilinmagan)
          ]);
          allCouriers.value = (c && c.items) || [];
          allDeliveries.value = (d && d.items) || [];
          if (!selectedCourier.value && allCouriers.value.length) {
            const onRoute = allCouriers.value.find(c => c.status === 'on_route') || allCouriers.value[0];
            selectedCourier.value = onRoute.id;
          }
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; }
      }

      // Bir kuryer marshruti — assigned/on_route holatida
      const routeStops = computed(() => {
        if (!selectedCourier.value) return [];
        return allDeliveries.value
          .filter(d => d.courier_id === selectedCourier.value
            && ['assigned', 'on_route'].includes(d.status))
          .sort((a, b) => new Date(a.assigned_at || 0) - new Date(b.assigned_at || 0));
      });

      const courier = computed(() => allCouriers.value.find(c => c.id === selectedCourier.value));

      function statusInfo(s) { return Labels.formatStatus(s, 'order'); }
      const fullName = (c) => c ? `${c.first_name} ${c.last_name || ''}`.trim() : '';

      function changeCourier(id) { selectedCourier.value = id; }

      onMounted(load);

      return {
        allCouriers, routeStops, courier, loading, error, selectedCourier,
        statusInfo, fullName, changeCourier,
        formatMoney: Utils.formatMoney,
      };
    },
    template: `
      <div class="page" data-component="route-map">
        <h1 class="heading">Marshrut</h1>

        <div class="field">
          <label class="field__label">Kuryer</label>
          <select v-model="selectedCourier" @change="changeCourier(selectedCourier)" data-field="route-courier">
            <option v-for="c in allCouriers" :key="c.id" :value="c.id">
              {{ fullName(c) }} ({{ c.status }})
            </option>
          </select>
        </div>

        <div v-if="loading" class="stack">
          <div class="card"><div class="skeleton" style="height: 40px;"></div></div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else-if="routeStops.length" class="stack" data-component="route-stops">
          <div class="card">
            <div class="text-medium">{{ fullName(courier) }}</div>
            <div class="text-muted text-sm">{{ routeStops.length }} ta to'xtash</div>
          </div>
          <div
            v-for="(stop, idx) in routeStops" :key="stop.id"
            class="card"
            :data-stop-id="stop.id"
            :data-stop-order="idx + 1"
          >
            <div class="cluster cluster--between">
              <div class="row">
                <div class="avatar avatar--sm">{{ idx + 1 }}</div>
                <div class="stack stack--tight">
                  <div class="text-medium">#{{ stop.order_number }}</div>
                  <div class="text-muted text-sm">{{ stop.customer_name }}</div>
                </div>
              </div>
              <span class="badge" :class="'badge--' + statusInfo(stop.status).badge">
                {{ statusInfo(stop.status).label }}
              </span>
            </div>
            <div class="stack stack--tight" style="margin-top: var(--space-3);">
              <div class="row">
                <span style="font-size: var(--icon-md)">📍</span>
                <span class="text-sm">{{ stop.delivery_address }}</span>
              </div>
              <div class="row">
                <span style="font-size: var(--icon-md)">💰</span>
                <span class="text-sm">{{ formatMoney(stop.total) }}</span>
              </div>
            </div>
          </div>
        </div>

        <div v-else class="empty">
          <div class="empty__icon">🗺️</div>
          <div class="empty__title">Marshrut yo'q</div>
        </div>
      </div>
    `,
  };
})();
