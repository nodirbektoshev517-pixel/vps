/**
 * CustomerProfile.js — bitta mijoz profili va orders_history extension.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils, Labels } = window.Adminbot.Core;

  const EXTENSION_MAP = {
    orders_history: 'OrdersHistoryBlock',
  };

  window.Adminbot.Components.CustomerProfile = {
    name: 'CustomerProfile',
    props: {
      customer: { type: Object, default: null },
    },
    emits: ['back'],
    setup(props, { emit }) {
      const loading = ref(true);
      const error = ref(null);
      const data = ref(null);

      const childConfig = computed(() => {
        const adapter = window.Adminbot.Runtime.adapter;
        if (!adapter) return {};
        return (adapter.component_configs && adapter.component_configs.CustomerProfile) || {};
      });

      const extensions = computed(() => {
        const list = (childConfig.value && childConfig.value.extensions) || ['orders_history'];
        return list.map(name => ({ name, component: EXTENSION_MAP[name] })).filter(e => !!e.component);
      });

      async function load() {
        loading.value = true;
        try {
          const r = await Services.customers.get(props.customer.id);
          data.value = r;
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; }
      }

      onMounted(load);

      return {
        loading, error, data, extensions,
        back: () => emit('back'),
        fullName: (c) => [c.first_name, c.last_name].filter(Boolean).join(' '),
        initials: Utils.initials,
        formatMoney: Utils.formatMoney,
        formatPhone: Utils.formatPhone,
        formatDate: Utils.formatDate,
      };
    },
    template: `
      <div class="page">
        <div class="row">
          <button
            type="button"
            class="btn btn--ghost btn--icon btn--sm"
            data-action="back"
            @click="back"
            aria-label="Orqaga"
          >←</button>
          <h1 class="heading">Mijoz profili</h1>
        </div>

        <div v-if="loading && !data" class="card">
          <div class="skeleton" style="width: 60%; height: 18px;"></div>
          <div class="skeleton" style="width: 40%; height: 12px; margin-top: 8px;"></div>
        </div>
        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>
        <div v-else-if="data" data-component="customer-profile">
          <div class="card">
            <div class="row">
              <div class="avatar avatar--lg">{{ initials(data) }}</div>
              <div class="stack stack--tight">
                <div class="text-medium" style="font-size: var(--text-lg);">{{ fullName(data) }}</div>
                <div class="text-muted text-sm">{{ formatPhone(data.phone) }}</div>
              </div>
            </div>
          </div>

          <div class="grid">
            <div class="card">
              <div class="stat__label">Buyurtmalar</div>
              <div class="stat__value">{{ data.orders_count }}</div>
            </div>
            <div class="card">
              <div class="stat__label">Umumiy sarflagan</div>
              <div class="stat__value">{{ formatMoney(data.total_spent) }}</div>
            </div>
          </div>

          <component
            v-for="ext in extensions"
            :key="ext.name"
            :is="ext.component"
            :customer="data"
          />
        </div>
      </div>
    `,
  };
})();
