/**
 * ShopApprover.js — taklif kodi bilan ro'yxatdan o'tgan
 * do'konlarni tasdiqlash/rad etish.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils, Permissions, Actions } = window.Adminbot.Core;

  window.Adminbot.Components.ShopApprover = {
    name: 'ShopApprover',
    setup() {
      const items = ref([]);
      const loading = ref(true);
      const error = ref(null);
      const canManage = computed(() => Permissions.can('supplier.shop.approve'));

      async function load() {
        loading.value = true;
        try {
          const r = await Services.supplier.listPendingShops();
          items.value = (r && r.items) || [];
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; }
      }

      async function approve(p) {
        await Actions.runAction({
          permission: 'supplier.shop.approve',
          confirm: {
            title: 'Tasdiqlash',
            body: `${p.name} do'koni tasdiqlansinmi?`,
            confirmText: 'Tasdiqlash', cancelText: 'Bekor',
          },
          action: () => Services.supplier.approveShop(p.id),
          onSuccess: async () => { await load(); },
          successMessage: 'Tasdiqlandi',
        });
      }

      async function reject(p) {
        await Actions.runAction({
          permission: 'supplier.shop.approve',
          confirm: {
            title: 'Rad etish',
            body: `${p.name} do'koni rad etilsinmi?`,
            confirmText: 'Rad etish', cancelText: 'Bekor',
          },
          action: () => Services.supplier.rejectShop(p.id),
          onSuccess: async () => { await load(); },
          successMessage: 'Rad etildi',
        });
      }

      onMounted(load);
      return {
        items, loading, error, canManage, approve, reject,
        formatPhone: Utils.formatPhone,
        relativeTime: Utils.relativeTime,
      };
    },
    template: `
      <div class="page" data-component="shop-approver">
        <h1 class="heading">Tasdiq kutmoqda</h1>

        <div v-if="loading" class="list">
          <div v-for="i in 2" :key="i" class="card">
            <div class="skeleton" style="width: 50%; height: 14px;"></div>
          </div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else-if="items.length" class="stack">
          <div
            v-for="p in items" :key="p.id"
            class="card"
            :data-pending-id="p.id"
          >
            <div class="cluster cluster--between">
              <div class="stack stack--tight">
                <div class="text-medium" style="font-size: var(--text-lg);">{{ p.name }}</div>
                <div class="text-muted text-sm">{{ formatPhone(p.owner_phone) }}</div>
                <div class="text-muted text-sm">Kod: {{ p.invite_code }} • {{ relativeTime(p.created_at) }}</div>
              </div>
            </div>
            <div v-if="canManage" class="cluster cluster--end" style="margin-top: var(--space-3);">
              <button
                type="button"
                class="btn btn--ghost btn--sm text-danger"
                :data-action="'reject-' + p.id"
                @click="reject(p)"
              >Rad etish</button>
              <button
                type="button"
                class="btn btn--success btn--sm"
                :data-action="'approve-' + p.id"
                @click="approve(p)"
              >Tasdiqlash</button>
            </div>
          </div>
        </div>

        <div v-else class="empty">
          <div class="empty__icon">✅</div>
          <div class="empty__title">Tasdiq kutayotgan yo'q</div>
        </div>
      </div>
    `,
  };
})();
