/**
 * ProductCRUD.js — mahsulotlar boshqaruvi.
 *
 * Kategoriya prop bilan ochiladi (CategoryCRUD'dan).
 * Pagination, filter, CRUD via sheet form, ImageUploader, variants/addons extensions.
 *
 * Adapter `ProductCRUD.extensions: ['variants', 'addons']` orqali qaysi
 * qo'shimcha bloklarni ko'rsatish. Variant 2 — har biri kichik komponent.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted, watch } = Vue;
  const { Services, Utils, Permissions, Actions, Labels, Composables, UI } = window.Adminbot.Core;

  const EXTENSION_MAP = {
    variants: 'VariantsBlock',
    addons:   'AddonsBlock',
  };

  window.Adminbot.Components.ProductCRUD = {
    name: 'ProductCRUD',
    props: {
      category: { type: Object, default: null },
      config:   { type: Object, default: () => ({}) },
    },
    emits: ['back'],
    setup(props, { emit }) {
      const loading = ref(true);
      const error = ref(null);
      const products = ref([]);
      const cursor = ref(null);
      const hasMore = ref(false);
      const loadingMore = ref(false);
      const seenIds = new Set();

      const editing = ref(null);   // null | {} | mavjud mahsulot
      const saving = ref(false);

      const canManage = computed(() => Permissions.can('catalog.manage'));

      const childConfig = computed(() => {
        const adapter = window.Adminbot.Runtime.adapter;
        if (!adapter) return {};
        return (adapter.component_configs && adapter.component_configs.ProductCRUD) || {};
      });

      const extensions = computed(() => {
        const list = (childConfig.value && childConfig.value.extensions) || [];
        return list
          .map(name => ({ name, component: EXTENSION_MAP[name] }))
          .filter(e => !!e.component);
      });

      async function load(append = false) {
        if (append) loadingMore.value = true;
        else loading.value = true;
        try {
          const r = await Services.catalog.listProducts({
            category_id: props.category ? props.category.id : null,
            cursor: append ? cursor.value : null,
            page_size: 20,
          });
          const newItems = (r && r.items) || [];
          if (append) {
            const toAdd = newItems.filter(it => !seenIds.has(it.id));
            toAdd.forEach(it => seenIds.add(it.id));
            products.value = products.value.concat(toAdd);
          } else {
            seenIds.clear();
            newItems.forEach(it => seenIds.add(it.id));
            products.value = newItems;
          }
          cursor.value = r && r.next_cursor;
          hasMore.value = !!(r && r.has_more);
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; loadingMore.value = false; }
      }

      function startCreate() {
        if (!Permissions.require('catalog.manage', 'Mahsulot qo\'shish')) return;
        editing.value = {
          category_id: props.category && props.category.id,
          name: '',
          price: 0,
          status: 'active',
          image_url: null,
          images: [],
          _imageUploads: [],
          _imageDeleteIds: [],
          variants: [],
          addons: [],
        };
      }
      function startEdit(p) {
        if (!Permissions.require('catalog.manage', 'Mahsulot tahrirlash')) return;
        editing.value = {
          ...p,
          images: [...(p.images || [])],
          _imageUploads: [],
          _imageDeleteIds: [],
          variants: [...(p.variants || [])],
          addons: [...(p.addons || [])],
        };
      }
      function cancelEdit() { editing.value = null; }

      function setImageUploads(payload) {
        if (!editing.value) return;
        editing.value._imageUploads = payload || [];
      }
      function removeExistingImage(imageId) {
        if (!editing.value) return;
        editing.value._imageDeleteIds = editing.value._imageDeleteIds || [];
        if (!editing.value._imageDeleteIds.includes(imageId)) {
          editing.value._imageDeleteIds.push(imageId);
        }
        editing.value.images = (editing.value.images || []).filter(img => String(img.id) !== String(imageId));
        const primary = editing.value.images[0] || null;
        editing.value.image_url = primary && (
          primary.url || primary.card_url || primary.detail_url || primary.thumb_url
        ) || null;
      }

      async function saveProductWithImage(d, isNew) {
        const savedResp = isNew
          ? await Services.catalog.createProduct(d)
          : await Services.catalog.updateProduct(d.id, d);
        let product = savedResp && (savedResp.product || savedResp);
        if (!product || !product.id) return product;

        for (const imageId of (d._imageDeleteIds || [])) {
          const deleteResp = await Services.catalog.deleteProductImage(product.id, imageId);
          product = deleteResp && (deleteResp.product || deleteResp) || product;
        }

        const newImageIds = [];
        for (const upload of (d._imageUploads || [])) {
          if (!upload || !upload.file) continue;
          const beforeIds = new Set(((product.images || []).map(img => String(img.id))));
          const imageResp = await Services.catalog.uploadProductImage(product.id, upload.file);
          product = imageResp && (imageResp.product || imageResp) || product;
          const images = product && product.images || [];
          const newImage = images.find(img => !beforeIds.has(String(img.id))) || images[images.length - 1];
          if (newImage && newImage.id) newImageIds.push(String(newImage.id));
        }

        if (newImageIds.length) {
          const images = product && product.images || [];
          const orderedIds = [
            ...newImageIds,
            ...images
              .map(img => String(img.id))
              .filter(id => id && !newImageIds.includes(id)),
          ];
          const primaryResp = await Services.catalog.setPrimaryProductImage(product.id, orderedIds, newImageIds[0]);
          product = primaryResp && (primaryResp.product || primaryResp) || product;
        }
        return product;
      }

      async function saveEdit() {
        const d = editing.value;
        if (!d || !d.name || d.name.length < 2) {
          UI.toast('Mahsulot nomi juda qisqa', { type: 'warn' }); return;
        }
        if (!d.price || d.price <= 0) {
          UI.toast('Narx 0 dan katta bo\'lishi kerak', { type: 'warn' }); return;
        }
        const isNew = !d.id;
        await Actions.runAction({
          permission: 'catalog.manage',
          loading: saving,
          action: () => saveProductWithImage(d, isNew),
          onSuccess: async () => { editing.value = null; await load(); },
          successMessage: isNew ? 'Qo\'shildi' : 'Yangilandi',
        });
      }

      async function remove(p) {
        await Actions.runAction({
          permission: 'catalog.manage',
          confirm: {
            title: 'O\'chirishni tasdiqlang',
            body: `"${p.name}" o'chirilsinmi?`,
            confirmText: 'O\'chirish', cancelText: 'Bekor',
          },
          action: () => Services.catalog.deleteProduct(p.id),
          onSuccess: async () => { await load(); },
          successMessage: 'O\'chirildi',
        });
      }

      function statusInfo(s) { return Labels.formatStatus(s, 'product'); }
      function fmtPrice(n) { return Utils.formatMoney(n); }

      // Variants/addons — oddiy ro'yxat tahrirlovchi
      function addVariant() {
        if (!editing.value) return;
        editing.value.variants.push({ name: '', price_delta: 0 });
      }
      function removeVariant(i) {
        if (!editing.value) return;
        editing.value.variants.splice(i, 1);
      }
      function addAddon() {
        if (!editing.value) return;
        editing.value.addons.push({ name: '', price: 0 });
      }
      function removeAddon(i) {
        if (!editing.value) return;
        editing.value.addons.splice(i, 1);
      }

      onMounted(load);
      watch(() => props.category && props.category.id, () => load());

      return {
        loading, error, products, hasMore, loadingMore, editing, saving,
        canManage, extensions, childConfig,
        startCreate, startEdit, cancelEdit, saveEdit, remove,
        setImageUploads, removeExistingImage,
        statusInfo, fmtPrice,
        loadMore: () => load(true),
        back: () => emit('back'),
        addVariant, removeVariant, addAddon, removeAddon,
      };
    },
    template: `
      <div class="page">
        <div class="cluster cluster--between">
          <div class="row">
            <button
              v-if="category"
              type="button"
              class="btn btn--ghost btn--icon btn--sm"
              data-action="back"
              @click="back"
              aria-label="Orqaga"
            >←</button>
            <h1 class="heading">{{ category ? category.name : 'Mahsulotlar' }}</h1>
          </div>
          <button
            v-if="canManage"
            type="button"
            class="btn btn--primary btn--sm"
            data-action="add-product"
            @click="startCreate"
          >+ Yangi</button>
        </div>

        <div v-if="loading && !products.length" class="stack">
          <div v-for="i in 3" :key="i" class="card">
            <div class="skeleton" style="height: 14px; width: 50%;"></div>
            <div class="skeleton" style="height: 12px; width: 30%; margin-top: 8px;"></div>
          </div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else-if="products.length" class="stack" data-component="product-list">
          <div
            v-for="p in products" :key="p.id"
            class="card"
            :data-product-id="p.id"
          >
            <div class="cluster cluster--between">
              <div class="row" style="gap: var(--space-3); min-width: 0;">
                <img
                  v-if="p.image_url"
                  :src="p.image_url"
                  alt=""
                  style="width: 64px; height: 64px; border-radius: var(--radius-md); object-fit: cover; flex: 0 0 auto; background: var(--color-surface-muted);"
                >
                <div
                  v-else
                  class="list__icon"
                  style="width: 64px; height: 64px; flex: 0 0 auto;"
                >📦</div>
                <div class="stack stack--tight" style="min-width: 0;">
                  <div class="text-medium" style="font-size: var(--text-lg);">{{ p.name }}</div>
                  <div class="text-muted text-sm">{{ fmtPrice(p.price) }}</div>
                </div>
              </div>
              <span class="badge" :class="'badge--' + statusInfo(p.status).badge">{{ statusInfo(p.status).label }}</span>
            </div>
            <div v-if="canManage" class="cluster cluster--end" style="margin-top: var(--space-3);">
              <button
                class="btn btn--ghost btn--sm"
                :data-action="'edit-product-' + p.id"
                @click="startEdit(p)"
              >Tahrirlash</button>
              <button
                class="btn btn--ghost btn--sm text-danger"
                :data-action="'del-product-' + p.id"
                @click="remove(p)"
              >O'chirish</button>
            </div>
          </div>
          <button
            v-if="hasMore"
            class="btn btn--secondary btn--block"
            data-action="load-more-products"
            :disabled="loadingMore"
            @click="loadMore"
          >{{ loadingMore ? 'Yuklanmoqda...' : 'Yana yuklash' }}</button>
        </div>

        <div v-else class="empty">
          <div class="empty__icon">📦</div>
          <div class="empty__title">Mahsulot yo'q</div>
        </div>

        <!-- Edit overlay -->
        <div v-if="editing" class="overlay" @click.self="cancelEdit" data-component="product-form">
          <div class="sheet">
            <div class="sheet__handle"></div>
            <div class="sheet__header">
              <div class="sheet__title">{{ editing.id ? 'Mahsulot tahrirlash' : 'Yangi mahsulot' }}</div>
            </div>
            <div class="stack">
              <!-- Rasm -->
              <ImageUploader
                v-model="editing.image_url"
                :images="editing.images || []"
                :max-images="5"
                @images-ready="setImageUploads"
                @existing-image-remove="removeExistingImage"
              />

              <div class="field">
                <label class="field__label">Nomi</label>
                <input type="text" v-model="editing.name" placeholder="Cappuccino" data-field="name" />
              </div>

              <div class="field">
                <label class="field__label">Narx (so'm)</label>
                <input type="number" v-model.number="editing.price" placeholder="25000" data-field="price" />
              </div>

              <div class="field">
                <label class="field__label">Holat</label>
                <select v-model="editing.status" data-field="status">
                  <option value="active">Faol</option>
                  <option value="out_of_stock">Yo'q</option>
                  <option value="draft">Qoralama</option>
                </select>
              </div>

              <!-- Extension'lar (Variant 2 — kichik komponentlar) -->
              <component
                v-for="ext in extensions"
                :key="ext.name"
                :is="ext.component"
                v-model="editing[ext.name]"
              />

              <div class="cluster cluster--end">
                <button class="btn btn--secondary" :disabled="saving" @click="cancelEdit">Bekor</button>
                <button
                  class="btn btn--primary"
                  data-action="save-product"
                  :disabled="saving"
                  @click="saveEdit"
                >{{ saving ? 'Saqlanmoqda...' : 'Saqlash' }}</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    `,
  };
})();
