/**
 * CalendarView.js — Kun bo'yicha uchrashuvlar jadvali.
 *
 * Sodda kun ko'rinishi: 9:00-19:00 oralig'i, har bir uchrashuv vaqt bilan.
 * Specialist filter — kim ishlamoqda.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils, Labels, Composables } = window.Adminbot.Core;

  window.Adminbot.Components.CalendarView = {
    name: 'CalendarView',
    setup() {
      const appointments = ref([]);
      const specialists = ref([]);
      const date = ref(new Date().toISOString().slice(0, 10));
      const specialistFilter = ref('all');
      const loading = ref(true);
      const error = ref(null);

      async function loadSpecialists() {
        try {
          const r = await Services.appointment.listSpecialists();
          specialists.value = (r && r.items) || [];
        } catch (e) {}
      }

      async function load() {
        loading.value = true;
        try {
          const r = await Services.appointment.listAppointments({
            date: date.value,
            specialist_id: specialistFilter.value === 'all' ? null : specialistFilter.value,
          });
          appointments.value = (r && r.items) || [];
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; }
      }

      function changeDate(delta) {
        const d = new Date(date.value);
        d.setDate(d.getDate() + delta);
        date.value = d.toISOString().slice(0, 10);
        load();
      }

      function changeSpecialist() { load(); }

      // Vaqt slot'lariga guruhlash (template'da og'ir filter YO'Q)
      const grouped = computed(() => {
        const slots = {};
        for (const a of appointments.value) {
          const t = new Date(a.start_time);
          const hour = t.getHours();
          const key = `${hour.toString().padStart(2, '0')}:00`;
          if (!slots[key]) slots[key] = [];
          slots[key].push(a);
        }
        return Object.entries(slots)
          .sort((a, b) => a[0].localeCompare(b[0]))
          .map(([time, items]) => ({ time, items }));
      });

      function statusInfo(s) { return Labels.formatStatus(s, 'appointment'); }
      function specialistName(id) {
        const s = specialists.value.find(x => x.id === id);
        return s ? `${s.first_name} ${s.last_name}` : '—';
      }
      function fmtTime(iso) {
        return new Date(iso).toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' });
      }

      // Real-time
      const { subscribe } = Composables.useEvents();
      onMounted(async () => {
        await loadSpecialists();
        await load();
        subscribe('appointment.created', () => load());
        subscribe('appointment.status_changed', () => load());
      });

      return {
        appointments, specialists, date, specialistFilter, loading, error,
        grouped, statusInfo, specialistName, fmtTime,
        changeDate, changeSpecialist,
      };
    },
    template: `
      <div class="page" data-component="calendar-view">
        <h1 class="heading">Kun jadvali</h1>

        <div class="cluster cluster--between" style="margin-bottom: var(--space-3);">
          <button class="btn btn--ghost btn--icon" data-action="prev-day" @click="changeDate(-1)">←</button>
          <div class="text-bold">{{ date }}</div>
          <button class="btn btn--ghost btn--icon" data-action="next-day" @click="changeDate(1)">→</button>
        </div>

        <div class="field">
          <label class="field__label">Mutaxassis</label>
          <select v-model="specialistFilter" @change="changeSpecialist" data-field="specialist-filter">
            <option value="all">Hammasi</option>
            <option v-for="s in specialists" :key="s.id" :value="s.id">
              {{ s.first_name }} {{ s.last_name }}
            </option>
          </select>
        </div>

        <div v-if="loading && !appointments.length" class="stack">
          <div v-for="i in 3" :key="i" class="card">
            <div class="skeleton" style="height: 50px;"></div>
          </div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else-if="grouped.length" class="stack" data-component="calendar-slots">
          <div v-for="slot in grouped" :key="slot.time" class="card" :data-slot-time="slot.time">
            <div class="text-bold" style="font-size: var(--text-lg);">{{ slot.time }}</div>
            <div class="stack stack--tight" style="margin-top: var(--space-2);">
              <div
                v-for="a in slot.items" :key="a.id"
                class="list__row"
                :data-appointment-id="a.id"
              >
                <div class="list__main">
                  <div class="list__title">{{ a.customer_name }}</div>
                  <div class="list__subtitle">
                    {{ fmtTime(a.start_time) }} • {{ a.service_name }} • {{ a.duration_min }} daq
                  </div>
                  <div class="text-muted text-sm">{{ specialistName(a.specialist_id) }}</div>
                </div>
                <span class="badge" :class="'badge--' + statusInfo(a.status).badge">
                  {{ statusInfo(a.status).label }}
                </span>
              </div>
            </div>
          </div>
        </div>

        <div v-else class="empty">
          <div class="empty__icon">📅</div>
          <div class="empty__title">Uchrashuv yo'q</div>
        </div>
      </div>
    `,
  };
})();
