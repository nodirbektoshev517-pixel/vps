/**
 * OrdersHistoryBlock.js — mijozning oxirgi buyurtmalari (extension).
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { computed } = Vue;
  const { Utils, Labels } = window.Adminbot.Core;

  window.Adminbot.Components.OrdersHistoryBlock = {
    name: 'OrdersHistoryBlock',
    props: { customer: { type: Object, required: true } },
    setup(props) {
      const orders = computed(() => (props.customer && props.customer.orders_history) || []);
      function statusInfo(s) { return Labels.formatStatus(s, 'order'); }
      return { orders, statusInfo,
        formatMoney: Utils.formatMoney,
        formatDate: (d) => Utils.formatDate(d, { time: false }),
      };
    },
    template: `
      <div class="stack stack--snug" data-ext="orders_history">
        <div class="heading heading--sm">Buyurtmalar tarixi</div>
        <div v-if="orders.length" class="list">
          <div
            v-for="o in orders" :key="o.id"
            class="list__row"
            :data-order-id="o.id"
          >
            <div class="list__main">
              <div class="list__title">#{{ o.number }}</div>
              <div class="list__subtitle">{{ formatDate(o.created_at) }}</div>
            </div>
            <span class="badge" :class="'badge--' + statusInfo(o.status).badge">{{ statusInfo(o.status).label }}</span>
            <div class="list__trail">{{ formatMoney(o.total) }}</div>
          </div>
        </div>
        <div v-else class="text-muted text-sm">Tarix yo'q.</div>
      </div>
    `,
  };
})();
