/**
 * AddonsBlock.js — qo'shimchalar (syrup, qaymoq, h.k.).
 */
(function () {
  'use strict';
  const Vue = window.Vue;

  window.Adminbot.Components.AddonsBlock = {
    name: 'AddonsBlock',
    props: { modelValue: { type: Array, default: () => [] } },
    emits: ['update:modelValue'],
    setup(props, { emit }) {
      function add() {
        emit('update:modelValue', [...(props.modelValue || []), { name: '', price: 0 }]);
      }
      function update(i, field, value) {
        const list = [...(props.modelValue || [])];
        list[i] = { ...list[i], [field]: value };
        emit('update:modelValue', list);
      }
      function remove(i) {
        const list = [...(props.modelValue || [])];
        list.splice(i, 1);
        emit('update:modelValue', list);
      }
      return { add, update, remove };
    },
    template: `
      <div class="stack stack--tight" data-ext="addons">
        <div class="cluster cluster--between">
          <div class="heading heading--sm">Qo'shimchalar</div>
          <button class="btn btn--ghost btn--sm" type="button" @click="add">+ Qo'shish</button>
        </div>
        <div v-for="(a, i) in modelValue" :key="i" class="row" :data-addon-index="i">
          <input
            type="text"
            :value="a.name"
            @input="update(i, 'name', $event.target.value)"
            placeholder="Syrup"
            style="flex: 2;"
          />
          <input
            type="number"
            :value="a.price"
            @input="update(i, 'price', parseInt($event.target.value, 10) || 0)"
            placeholder="3000"
            style="flex: 1;"
          />
          <button class="btn btn--ghost btn--icon btn--sm" type="button" @click="remove(i)" aria-label="O'chirish">✕</button>
        </div>
        <div v-if="!modelValue.length" class="text-muted text-sm">Qo'shimchalar yo'q.</div>
      </div>
    `,
  };
})();
