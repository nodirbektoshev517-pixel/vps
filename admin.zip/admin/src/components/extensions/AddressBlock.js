/**
 * AddressBlock.js — OrderCard'da yetkazib berish manzili.
 *
 * Adapter OrderCard.extensions: ['delivery_address', ...] orqali yoqiladi.
 * Order obyektida `delivery_address` field bo'lsa ko'rsatadi.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { computed } = Vue;

  window.Adminbot.Components.AddressBlock = {
    name: 'AddressBlock',
    props: {
      order: { type: Object, required: true },
    },
    setup(props) {
      const address = computed(() => props.order && props.order.delivery_address);
      return { address };
    },
    template: `
      <div v-if="address" class="row" data-ext="delivery_address">
        <span style="font-size: var(--icon-md)">📍</span>
        <span class="text-sm text-truncate">{{ address }}</span>
      </div>
    `,
  };
})();
