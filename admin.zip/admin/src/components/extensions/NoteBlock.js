/**
 * NoteBlock.js — mijoz izohi (agar bo'lsa).
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { computed } = Vue;

  window.Adminbot.Components.NoteBlock = {
    name: 'NoteBlock',
    props: {
      order: { type: Object, required: true },
    },
    setup(props) {
      const note = computed(() => props.order && props.order.note);
      return { note };
    },
    template: `
      <div v-if="note" class="row" data-ext="note">
        <span style="font-size: var(--icon-md)">💬</span>
        <span class="text-sm" style="font-style: italic;">{{ note }}</span>
      </div>
    `,
  };
})();
