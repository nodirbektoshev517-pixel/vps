/**
 * VariantsBlock.js — mahsulot variantlari (kichik/o'rta/katta, 200ml/400ml, h.k.).
 * v-model orqali ProductCRUD bilan ikki tomonlama bog'lanadi.
 */
(function () {
  'use strict';
  const Vue = window.Vue;

  window.Adminbot.Components.VariantsBlock = {
    name: 'VariantsBlock',
    props: { modelValue: { type: Array, default: () => [] } },
    emits: ['update:modelValue'],
    setup(props, { emit }) {
      function add() {
        emit('update:modelValue', [...(props.modelValue || []), { name: '', price_delta: 0 }]);
      }
      function update(i, field, value) {
        const list = [...(props.modelValue || [])];
        list[i] = { ...list[i], [field]: value };
        emit('update:modelValue', list);
      }
      function remove(i) {
        const list = [...(props.modelValue || [])];
        list.splice(i, 1);
        emit('update:modelValue', list);
      }
      return { add, update, remove };
    },
    template: `
      <div class="stack stack--tight" data-ext="variants">
        <div class="cluster cluster--between">
          <div class="heading heading--sm">Variantlar</div>
          <button class="btn btn--ghost btn--sm" type="button" @click="add">+ Qo'shish</button>
        </div>
        <div v-for="(v, i) in modelValue" :key="i" class="row" :data-variant-index="i">
          <input
            type="text"
            :value="v.name"
            @input="update(i, 'name', $event.target.value)"
            placeholder="Masalan: Katta"
            style="flex: 2;"
          />
          <input
            type="number"
            :value="v.price_delta"
            @input="update(i, 'price_delta', parseInt($event.target.value, 10) || 0)"
            placeholder="+5000"
            style="flex: 1;"
          />
          <button class="btn btn--ghost btn--icon btn--sm" type="button" @click="remove(i)" aria-label="O'chirish">✕</button>
        </div>
        <div v-if="!modelValue.length" class="text-muted text-sm">Variantlar yo'q.</div>
      </div>
    `,
  };
})();
