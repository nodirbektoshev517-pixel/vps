/**
 * PaymentBlock.js — OrderCard'da to'lov usuli.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { computed } = Vue;
  const { Labels } = window.Adminbot.Core;

  // To'lov turi → label + icon
  const PAYMENT_INFO = {
    cash:  { label: 'Naqd',  icon: '💵' },
    card:  { label: 'Karta', icon: '💳' },
    click: { label: 'Click', icon: '📱' },
    payme: { label: 'Payme', icon: '📱' },
    transfer: { label: 'O\'tkazma', icon: '🏦' },
  };

  window.Adminbot.Components.PaymentBlock = {
    name: 'PaymentBlock',
    props: {
      order: { type: Object, required: true },
    },
    setup(props) {
      const info = computed(() => {
        const k = props.order && props.order.payment_method;
        return PAYMENT_INFO[k] || { label: k || '—', icon: '💰' };
      });
      return { info };
    },
    template: `
      <div v-if="info" class="row" data-ext="payment_method">
        <span style="font-size: var(--icon-md)">{{ info.icon }}</span>
        <span class="text-sm text-muted">{{ info.label }}</span>
      </div>
    `,
  };
})();
