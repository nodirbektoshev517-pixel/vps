/**
 * Dashboard.js — bosh sahifa — stat kartochkalar.
 *
 * Biznes turini BILMAYDI. Adapter component_configs.Dashboard.stat_cards
 * orqali qaysi statistikalarni ko'rsatishini deklare qiladi.
 *
 * Yangi design tizimi:
 *   .page → .cluster--between → .heading + .btn .btn--ghost .btn--icon
 *   .grid .grid--auto → .card-larda .stat__label / .stat__value / .stat__delta
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils, Cache, Events } = window.Adminbot.Core;

  window.Adminbot.Components.Dashboard = {
    name: 'Dashboard',
    props: {
      config: { type: Object, default: () => ({}) },
    },
    setup(props) {
      const loading = ref(true);
      const error = ref(null);
      const stats = ref({});
      const lastUpdated = ref(null);

      const cards = computed(() => {
        const want = (props.config && props.config.stat_cards) || ['todays_orders', 'revenue'];
        return want
          .map(key => ({ key, ...(stats.value[key] || {}) }))
          .filter(s => s.value != null || s.label);
      });

      function formatValue(card) {
        if (card.value == null) return '—';
        if (card.format === 'money') return Utils.formatMoney(card.value);
        return new Intl.NumberFormat('uz-UZ').format(card.value);
      }

      function formatDelta(card) {
        if (card.delta == null) return null;
        const sign = card.delta > 0 ? '+' : '';
        return `${sign}${card.delta}%`;
      }

      async function load(force = false) {
        loading.value = true;
        error.value = null;
        try {
          const resp = await Cache.fetch(
            'dashboard:stats',
            () => Services.dashboard.fetch(),
            { ttl: 60_000, cooldownMs: 5_000, force },
          );
          stats.value = (resp && resp.stats) || {};
          lastUpdated.value = resp && resp.last_updated_at;
        } catch (e) {
          error.value = Utils.errorText(e);
        } finally {
          loading.value = false;
        }
      }

      function refresh() {
        Cache.invalidate('dashboard:');
        load(true);
      }

      onMounted(() => {
        load();
        // Server event triggered (POLLING EMAS)
        Events.on('order.created', () => refresh());
        Events.on('order.status_changed', () => refresh());
      });

      return { loading, error, cards, lastUpdated, formatValue, formatDelta, refresh };
    },
    template: `
      <div class="page">
        <div class="cluster cluster--between">
          <h1 class="heading">Bosh sahifa</h1>
          <button
            type="button"
            class="btn btn--ghost btn--icon btn--sm"
            aria-label="Yangilash"
            @click="refresh"
          >↻</button>
        </div>

        <div v-if="loading && !cards.length" class="grid grid--auto">
          <div v-for="i in 4" :key="i" class="card">
            <div class="skeleton" style="height: 12px; width: 60%;"></div>
            <div class="skeleton" style="height: 30px; width: 40%; margin-top: 8px;"></div>
          </div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else-if="cards.length" class="grid grid--auto" data-component="dashboard-stats">
          <div v-for="c in cards" :key="c.key" class="card" :data-stat="c.key">
            <div class="stat__label">{{ c.label || c.key }}</div>
            <div class="stat__value">{{ formatValue(c) }}</div>
            <div
              v-if="formatDelta(c)"
              class="stat__delta"
              :class="{ 'stat__delta--down': c.delta < 0 }"
            >{{ formatDelta(c) }} (1 hafta)</div>
          </div>
        </div>

        <div v-else class="empty">
          <div class="empty__icon">📊</div>
          <div class="empty__title">Statistika sozlanmagan</div>
          <div class="empty__hint">Adapter component_configs.Dashboard.stat_cards bo'sh.</div>
        </div>
      </div>
    `,
  };
})();
