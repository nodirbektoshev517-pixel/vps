/**
 * AuthGate.js — autentifikatsiya darvozasi.
 *
 * Boot vaqtida ko'rsatiladi: Telegram initData → JWT → bootstrap.
 * Tugagandan keyin PinGate yoki to'g'ridan-to'g'ri ilova ko'rsatiladi.
 *
 * Bu komponent o'z-o'zicha render qilmaydi — boot xato bo'lsa xato ekran,
 * tugayotgan bo'lsa spinner ko'rsatadi.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, onMounted } = Vue;
  const { Auth, Pin, Events, Services, Utils, Theme } = window.Adminbot.Core;

  window.Adminbot.Components.AuthGate = {
    name: 'AuthGate',
    emits: ['ready'],
    setup(_props, { emit }) {
      const status = ref('booting');   // booting | error | done
      const message = ref('Yuklanmoqda...');
      const error = ref(null);

      async function boot() {
        try {
          // 1. Tema
          message.value = 'Tema sozlanmoqda...';
          Theme.init();

          // 2. Auth (Telegram initData → JWT yoki mock)
          message.value = 'Telegram orqali kirilmoqda...';
          await Auth.login();

          // 3. Bootstrap — backend AUTHORITATIVE javob
          message.value = 'Ma\'lumotlar olinmoqda...';
          const bs = await Services.bootstrap.fetch();
          Auth.applyBootstrap(bs);
          Pin.applyBootstrap(bs);

          // 3.5 Sessiya yaroqligini tekshirish — jim "menyu bo'sh" muammosini
          // boot xatoga aylantirish (sabab darhol ko'rinadi)
          const check = Auth.validateSession();
          if (!check.ok) {
            throw new Error('Sessiya to\'liq emas: ' + check.errors.join('; '));
          }

          // 4. Adapter tanlash
          const session = Auth.getSession();
          const adapter = window.Adminbot.Core.BusinessRegistry.get(session.business_type);
          if (!adapter) {
            throw new Error(`Adapter topilmadi: ${session.business_type}`);
          }
          window.Adminbot.Runtime.adapter = adapter;
          window.Adminbot.Runtime.tenant = bs.tenant;

          // MUHIM: Events.connect() bu yerda CHAQIRILMAYDI.
          // PIN qulflanganida event stream ochiq bo'lmasligi uchun
          // ulanish RootShell tomonidan boshqariladi (PIN unlock'dan keyin).

          window.Adminbot.Runtime.ready = true;
          status.value = 'done';
          emit('ready', { bootstrap: bs, adapter });
        } catch (e) {
          console.error('[AuthGate] boot xato:', e);
          status.value = 'error';
          error.value = Utils.errorText(e);
        }
      }

      function retry() {
        status.value = 'booting';
        error.value = null;
        boot();
      }

      onMounted(() => { boot(); });

      return { status, message, error, retry };
    },
    template: `
      <div class="auth-screen" v-if="status !== 'done'">
        <div class="auth-screen__logo">SaaSBot</div>
        <template v-if="status === 'booting'">
          <div class="spinner" aria-label="Yuklanmoqda"></div>
          <div class="auth-screen__hint">{{ message }}</div>
        </template>
        <template v-else-if="status === 'error'">
          <div class="auth-screen__error">{{ error }}</div>
          <button class="btn btn--primary" @click="retry">Qayta urinish</button>
        </template>
      </div>
    `,
  };
})();
