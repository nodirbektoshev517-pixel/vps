/**
 * BottomNav.js — pastki navigatsiya.
 *
 * Adapter routes ro'yxatini Runtime.adapter.routes dan oladi.
 * Permission yo'q route'lar yashiriladi (UX filter — backend baribir tekshiradi).
 *
 * Tartib:
 *   - Primary route'lar (secondary != true) BottomNav'da ko'rinadi
 *   - Secondary route'lar "Boshqa" tugmasi orqali yuqoriga ochiladigan sheet'da
 *   - Agar Primary 5 yoki kamroq + Secondary yo'q: faqat Primary'lar
 *   - Agar Primary 5+ yoki Secondary bor: birinchi 4 ta + 5-chi "Boshqa"
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { computed, ref } = Vue;
  const { Router, Permissions } = window.Adminbot.Core;

  const MAX_PRIMARY_SLOTS = 5;

  window.Adminbot.Components.BottomNav = {
    name: 'BottomNav',
    setup() {
      const sheetOpen = ref(false);

      const allowedRoutes = computed(() =>
        Router.routes.value.filter(r => Permissions.canRoute(r))
      );

      const primaryRoutes = computed(() =>
        allowedRoutes.value.filter(r => !r.secondary)
      );

      const secondaryRoutes = computed(() =>
        allowedRoutes.value.filter(r => !!r.secondary)
      );

      const needsMoreButton = computed(() =>
        primaryRoutes.value.length > MAX_PRIMARY_SLOTS ||
        secondaryRoutes.value.length > 0
      );

      const visibleRoutes = computed(() => {
        if (!needsMoreButton.value) {
          return primaryRoutes.value;
        }
        return primaryRoutes.value.slice(0, MAX_PRIMARY_SLOTS - 1);
      });

      const sheetRoutes = computed(() => {
        if (!needsMoreButton.value) return [];
        const overflowPrimary = primaryRoutes.value.slice(MAX_PRIMARY_SLOTS - 1);
        return [...overflowPrimary, ...secondaryRoutes.value];
      });

      const currentKey = Router.currentKey;

      const moreActive = computed(() => {
        if (!sheetRoutes.value.length) return false;
        return sheetRoutes.value.some(r => r.key === currentKey.value);
      });

      function onTap(key) {
        sheetOpen.value = false;
        Router.go(key);
      }

      function toggleSheet() {
        sheetOpen.value = !sheetOpen.value;
      }

      function closeSheet() {
        sheetOpen.value = false;
      }

      return {
        visibleRoutes, sheetRoutes, currentKey,
        needsMoreButton, sheetOpen, moreActive,
        onTap, toggleSheet, closeSheet,
      };
    },
    template: `
      <div
        v-if="sheetOpen"
        class="bottom-sheet-backdrop"
        @click="closeSheet"
        role="presentation"
      ></div>

      <div
        v-if="sheetOpen && sheetRoutes.length"
        class="bottom-sheet"
        role="menu"
      >
        <button
          v-for="r in sheetRoutes"
          :key="r.key"
          type="button"
          class="bottom-sheet__item"
          :class="{ 'is-active': currentKey === r.key }"
          :data-route="r.key"
          @click="onTap(r.key)"
          role="menuitem"
        >
          <span class="bottom-sheet__icon">{{ r.icon }}</span>
          <span class="bottom-sheet__label">{{ r.label }}</span>
        </button>
      </div>

      <nav class="bottom-nav" v-if="visibleRoutes.length || needsMoreButton">
        <button
          v-for="r in visibleRoutes"
          :key="r.key"
          type="button"
          class="bottom-nav__item"
          :class="{ 'is-active': currentKey === r.key }"
          :data-route="r.key"
          @click="onTap(r.key)"
        >
          <span class="bottom-nav__icon">{{ r.icon }}</span>
          <span>{{ r.label }}</span>
        </button>

        <button
          v-if="needsMoreButton"
          type="button"
          class="bottom-nav__item"
          :class="{ 'is-active': moreActive || sheetOpen }"
          data-route="__more__"
          @click="toggleSheet"
        >
          <span class="bottom-nav__icon">⋯</span>
          <span>Boshqa</span>
        </button>
      </nav>
    `,
  };
})();