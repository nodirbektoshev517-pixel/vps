/**
 * LockScreen.js — qulflangan holat ekrani.
 *
 * Bu komponent quyidagi holatlarda ko'rsatiladi:
 *   - timeout: foydalanuvchi jim turdi, ilova qulflandi
 *   - manual: foydalanuvchi qo'lda lock bosdi
 *   - session_expired: backend 401 qaytardi
 *   - security_hold: backend 423 qaytardi (tenant suspended yoki PIN bloklandi)
 *
 * Holat bo'yicha turli xabar va harakat:
 *   - timeout/manual → "PINni kiriting" tugmasi → PinGate ochiladi
 *   - session_expired → "Qayta kirish" → app reload (yangi auth)
 *   - security_hold → "Yordamga murojaat qiling" — qulfdan chiqib bo'lmaydi
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { computed } = Vue;
  const { Pin, Auth } = window.Adminbot.Core;

  window.Adminbot.Components.LockScreen = {
    name: 'LockScreen',
    emits: ['enter-pin', 'reauth'],
    setup(_props, { emit }) {
      const state = computed(() => Pin.getState());

      const messageFor = computed(() => {
        switch (state.value.lockReason) {
          case 'security_hold':
            return {
              icon: '🛑',
              title: 'Xavfsizlik holati',
              hint: 'Akkauntingiz vaqtinchalik bloklangan. Yordamga murojaat qiling.',
              action: null,
            };
          case 'session_expired':
            return {
              icon: '⏰',
              title: 'Sessiya tugadi',
              hint: 'Qayta kirish kerak.',
              action: { label: 'Qayta kirish', handler: 'reauth' },
            };
          case 'manual':
            return {
              icon: '🔒',
              title: 'Ilova qulflangan',
              hint: 'Davom etish uchun PIN kiriting.',
              action: { label: 'PIN kiritish', handler: 'enter-pin' },
            };
          case 'timeout':
          default:
            return {
              icon: '🔒',
              title: 'Faollik bo\'lmaganligi sababli qulflandi',
              hint: 'Davom etish uchun PIN kiriting.',
              action: { label: 'PIN kiritish', handler: 'enter-pin' },
            };
        }
      });

      function onAction() {
        const a = messageFor.value.action;
        if (!a) return;
        if (a.handler === 'enter-pin') emit('enter-pin');
        if (a.handler === 'reauth') emit('reauth');
      }

      return { state, messageFor, onAction };
    },
    template: `
      <div class="pin-screen">
        <div class="pin-screen__icon">{{ messageFor.icon }}</div>
        <div class="pin-screen__title">{{ messageFor.title }}</div>
        <div class="pin-screen__hint">{{ messageFor.hint }}</div>
        <button
          v-if="messageFor.action"
          class="btn btn--primary"
          @click="onAction"
        >{{ messageFor.action.label }}</button>
      </div>
    `,
  };
})();
