/**
 * StaffManager.js — Xodimlar boshqaruvi (to'liq CRUD).
 *
 * Yangi: qo'shish/tahrirlash modal forma orqali.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted } = Vue;
  const { Services, Utils, Permissions, I18n, Labels, Actions, Composables, UI } = window.Adminbot.Core;

  const ROLE_OPTIONS = [
    { value: 'manager', label: 'Menejer' },
    { value: 'staff',   label: 'Xodim' },
    { value: 'courier', label: 'Kuryer' },
  ];

  window.Adminbot.Components.StaffManager = {
    name: 'StaffManager',
    props: { config: { type: Object, default: () => ({}) } },
    setup(props) {
      const loading = ref(true);
      const error = ref(null);
      const staff = ref([]);
      const editing = ref(null);

      const terms = computed(() => (props.config && props.config.terms) || {});
      const titleText = computed(() => I18n.plural(terms.value, 'staff', 'Xodimlar'));
      const canManage = computed(() => Permissions.can('staff.manage'));

      async function load() {
        loading.value = true;
        try {
          const r = await Services.staff.list();
          staff.value = (r && r.items) || [];
          error.value = null;
        } catch (e) { error.value = Utils.errorText(e); }
        finally { loading.value = false; }
      }

      const getInitials = Utils.initials;
      const getRoleInfo = (role) => Labels.formatStatus(role, 'role');
      const fullName = (s) => [s.first_name, s.last_name].filter(Boolean).join(' ');

      function startCreate() {
        if (!Permissions.require('staff.manage', 'Xodim qo\'shish')) return;
        editing.value = {
          first_name: '', last_name: '', role: 'staff',
          telegram_username: '', phone: '',
        };
      }
      function startEdit(s) {
        if (!Permissions.require('staff.manage', 'Xodim tahrirlash')) return;
        editing.value = { ...s };
      }
      function cancelEdit() { editing.value = null; }

      async function saveEdit() {
        const d = editing.value;
        if (!d || !d.first_name || d.first_name.length < 2) {
          UI.toast('Ism juda qisqa', { type: 'warn' }); return;
        }
        const isNew = !d.id;
        await Actions.runAction({
          permission: 'staff.manage',
          action: () => isNew
            ? Services.staff.create(d)
            : Services.staff.update(d.id, d),
          onSuccess: async () => { editing.value = null; await load(); },
          successMessage: isNew ? 'Qo\'shildi' : 'Yangilandi',
        });
      }

      async function onRemove(s) {
        if (s.is_self) {
          UI.toast('O\'zingizni o\'chira olmaysiz', { type: 'warn' });
          return;
        }
        await Actions.runAction({
          permission: 'staff.manage',
          confirm: {
            title: 'O\'chirishni tasdiqlang',
            body: `${fullName(s)} ro'yxatdan o'chirilsinmi?`,
            confirmText: 'O\'chirish', cancelText: 'Bekor',
          },
          action: () => Services.staff.remove(s.id),
          onSuccess: async () => { await load(); },
          successMessage: 'O\'chirildi',
        });
      }

      // Yangi event listener — boshqa session xodim qo'shsa, list yangilanadi
      const { subscribe } = Composables.useEvents();
      onMounted(() => {
        load();
        subscribe('staff.changed', () => load());
      });

      return {
        loading, error, staff, editing, ROLE_OPTIONS,
        terms, titleText, canManage,
        fullName, getInitials, getRoleInfo,
        startCreate, startEdit, cancelEdit, saveEdit, onRemove,
      };
    },
    template: `
      <div class="page">
        <div class="cluster cluster--between">
          <h1 class="heading">{{ titleText }}</h1>
          <button
            v-if="canManage"
            type="button"
            class="btn btn--primary btn--sm"
            data-action="add-staff"
            @click="startCreate"
          >+ Qo'shish</button>
        </div>

        <div v-if="loading && !staff.length" class="list">
          <div v-for="i in 3" :key="i" class="list__row">
            <div class="skeleton" style="width: 40px; height: 40px; border-radius: 50%;"></div>
            <div class="list__main">
              <div class="skeleton" style="width: 60%; height: 12px;"></div>
            </div>
          </div>
        </div>

        <div v-else-if="error" class="auth-screen__error">{{ error }}</div>

        <div v-else-if="staff.length" class="list" data-component="staff-list">
          <div
            v-for="s in staff" :key="s.id"
            class="list__row"
            :data-staff-id="s.id"
          >
            <div class="avatar">{{ getInitials(s) }}</div>
            <div class="list__main">
              <div class="list__title">
                {{ fullName(s) }}
                <span v-if="s.is_self" class="text-muted text-sm" style="margin-left: 6px;">(siz)</span>
              </div>
              <div class="list__subtitle">@{{ s.telegram_username || '—' }}</div>
            </div>
            <span class="badge" :class="'badge--' + getRoleInfo(s.role).badge">
              {{ getRoleInfo(s.role).label }}
            </span>
            <button
              v-if="canManage && !s.is_self"
              type="button"
              class="btn btn--ghost btn--icon btn--sm"
              :data-action="'edit-staff-' + s.id"
              @click="startEdit(s)"
              aria-label="Tahrirlash"
            >✎</button>
            <button
              v-if="canManage && !s.is_self"
              type="button"
              class="btn btn--ghost btn--icon btn--sm"
              :data-action="'remove-staff-' + s.id"
              @click="onRemove(s)"
              aria-label="O'chirish"
            >✕</button>
          </div>
        </div>

        <div v-else class="empty">
          <div class="empty__icon">👥</div>
          <div class="empty__title">Xodimlar yo'q</div>
        </div>

        <!-- Edit overlay -->
        <div v-if="editing" class="overlay" @click.self="cancelEdit" data-component="staff-form">
          <div class="sheet">
            <div class="sheet__handle"></div>
            <div class="sheet__header">
              <div class="sheet__title">{{ editing.id ? 'Xodim tahrirlash' : 'Yangi xodim' }}</div>
            </div>
            <div class="stack">
              <div class="field">
                <label class="field__label">Ism</label>
                <input type="text" v-model="editing.first_name" data-field="first_name" />
              </div>
              <div class="field">
                <label class="field__label">Familiya</label>
                <input type="text" v-model="editing.last_name" data-field="last_name" />
              </div>
              <div class="field">
                <label class="field__label">Telegram username</label>
                <input type="text" v-model="editing.telegram_username" placeholder="ali_owner" data-field="username" />
              </div>
              <div class="field">
                <label class="field__label">Telefon</label>
                <input type="tel" v-model="editing.phone" placeholder="+998901234567" data-field="phone" />
              </div>
              <div class="field">
                <label class="field__label">Rol</label>
                <select v-model="editing.role" data-field="role">
                  <option v-for="r in ROLE_OPTIONS" :key="r.value" :value="r.value">{{ r.label }}</option>
                </select>
              </div>
              <div class="cluster cluster--end">
                <button class="btn btn--secondary" @click="cancelEdit">Bekor</button>
                <button class="btn btn--primary" data-action="save-staff" @click="saveEdit">Saqlash</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    `,
  };
})();
