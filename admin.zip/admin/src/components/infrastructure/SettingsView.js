/**
 * SettingsView.js — OPERATIV sozlamalar.
 *
 * Chegara: biznesning ASOSIY sozlamalari uchun emas (vitrina,
 * to'lov, business_type) — ular SaaSBot SPA'da qoladi.
 *
 * Yangi design:
 *   .stack (vertical gap)
 *   .heading--sm (kichik sarlavhalar)
 *   .row (horizontal align-center)
 *   .list__row--interactive (bosish mumkin)
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { computed } = Vue;
  const { Auth, Pin, UI, Events, Utils, Labels, Actions } = window.Adminbot.Core;

  window.Adminbot.Components.SettingsView = {
    name: 'SettingsView',
    props: {
      config: { type: Object, default: () => ({}) },
    },
    setup(_props) {
      const session = computed(() => Auth.getSession());
      const pinState = computed(() => Pin.getState());

      const userName = computed(() => {
        const u = session.value.user;
        if (!u) return '—';
        return [u.first_name, u.last_name].filter(Boolean).join(' ') || u.username || 'Foydalanuvchi';
      });

      const userInitials = computed(() => Utils.initials(session.value.user));

      const roleInfo = computed(() => {
        const role = session.value.user && session.value.user.role;
        return Labels.formatStatus(role, 'role');
      });

      async function lockNow() {
        await Actions.runAction({
          actionLabel: 'Ilovani qulflash',
          confirm: {
            title: 'Ilovani qulflash?',
            body: 'Davom etish uchun PIN kerak bo\'ladi.',
            confirmText: 'Qulflash',
            cancelText: 'Bekor',
          },
          action: async () => { Pin.lock('manual'); },
          silent: true,
        });
      }

      async function logout() {
        await Actions.runAction({
          actionLabel: 'Chiqish',
          confirm: {
            title: 'Chiqishni tasdiqlang',
            body: 'Sessiyangiz yopiladi.',
            confirmText: 'Chiqish',
            cancelText: 'Bekor',
          },
          action: async () => {
            const { Services } = window.Adminbot.Core;
            try { await Services.auth.logout(); } catch (e) {}
            Auth.clearSession();
            Events.disconnect('logout');
          },
          onSuccess: () => {
            UI.toast('Sessiya yopildi', { type: 'success' });
            setTimeout(() => { window.location.reload(); }, 600);
          },
          silent: true,  // success toast'ni biz qo'lda chiqaramiz (reload bilan)
        });
      }

      const sections = computed(() => (
        (_props.config && _props.config.sections) ||
        ['profile', 'pin', 'theme', 'about']
      ));

      function showSection(s) {
        return sections.value.includes(s);
      }

      // Secondary route'lar — adapter'dan permission filter bilan
      const { Router, Permissions } = window.Adminbot.Core;
      const secondaryRoutes = computed(() => {
        return Router.routes.value.filter(r => r.secondary && Permissions.canRoute(r));
      });
      function navigateTo(key) {
        Router.go(key);
      }

      return {
        session, pinState, userName, userInitials, roleInfo,
        lockNow, logout, showSection,
        secondaryRoutes, navigateTo,
      };
    },
    template: `
      <div class="page">
        <div>
          <h1 class="heading">Sozlamalar</h1>
          <div class="subheading">
            Faqat operativ sozlamalar. Biznes konfiguratsiyasi web-kabinetda.
          </div>
        </div>

        <!-- Profile -->
        <section v-if="showSection('profile')" data-section="profile">
          <div class="card">
            <div class="row">
              <div class="avatar avatar--lg">{{ userInitials }}</div>
              <div class="stack stack--tight">
                <div class="text-medium" style="font-size: 17px;">{{ userName }}</div>
                <div class="text-muted text-sm">@{{ session.user && session.user.username || '—' }}</div>
                <span class="badge" :class="'badge--' + roleInfo.badge">{{ roleInfo.label }}</span>
              </div>
            </div>
          </div>
        </section>

        <!-- PIN -->
        <section v-if="showSection('pin')" class="stack stack--snug" data-section="pin">
          <div class="heading heading--sm">Xavfsizlik</div>
          <div class="list">
            <div class="list__row">
              <div class="list__icon">🔒</div>
              <div class="list__main">
                <div class="list__title">PIN-kod</div>
                <div class="list__subtitle">
                  {{ pinState.pinRequired ? 'O\\'rnatilgan' : 'O\\'rnatilmagan' }}
                </div>
              </div>
              <div class="list__trail">{{ pinState.timeoutMin }} daq</div>
            </div>
            <div
              class="list__row list__row--interactive"
              data-action="lock-now"
              @click="lockNow"
            >
              <div class="list__icon">🔐</div>
              <div class="list__main">
                <div class="list__title">Hozir qulflash</div>
                <div class="list__subtitle">Sessiyani darhol yopish</div>
              </div>
              <div class="list__chevron">›</div>
            </div>
          </div>
        </section>

        <!-- Theme -->
        <section v-if="showSection('theme')" class="stack stack--snug" data-section="theme">
          <div class="heading heading--sm">Ko'rinish</div>
          <div class="list">
            <div class="list__row">
              <div class="list__icon">🎨</div>
              <div class="list__main">
                <div class="list__title">Tema</div>
                <div class="list__subtitle">Telegram sozlamasidan avtomatik</div>
              </div>
              <div class="list__trail">Auto</div>
            </div>
          </div>
        </section>

        <!-- Notifications -->
        <section v-if="showSection('notifications')" class="stack stack--snug" data-section="notifications">
          <div class="heading heading--sm">Bildirishnomalar</div>
          <div class="list">
            <div class="list__row">
              <div class="list__icon">🔔</div>
              <div class="list__main">
                <div class="list__title">Telegram xabarlari</div>
                <div class="list__subtitle">Yangi buyurtmalar haqida</div>
              </div>
              <div class="list__trail">Yoq</div>
            </div>
          </div>
        </section>

        <!-- Boshqa bo'limlar — secondary route'lar (broadcast, reports, audit, staff) -->
        <section v-if="secondaryRoutes.length" class="stack stack--snug" data-section="more">
          <div class="heading heading--sm">Boshqa bo'limlar</div>
          <div class="list">
            <div
              v-for="r in secondaryRoutes" :key="r.key"
              class="list__row list__row--interactive"
              :data-action="'nav-' + r.key"
              @click="navigateTo(r.key)"
            >
              <div class="list__icon">{{ r.icon || '📂' }}</div>
              <div class="list__main">
                <div class="list__title">{{ r.label || r.key }}</div>
              </div>
              <div class="list__chevron">›</div>
            </div>
          </div>
        </section>

        <!-- About -->
        <section v-if="showSection('about')" class="stack stack--snug" data-section="about">
          <div class="heading heading--sm">Ilova haqida</div>
          <div class="list">
            <div class="list__row">
              <div class="list__icon">📦</div>
              <div class="list__main">
                <div class="list__title">Versiya</div>
                <div class="list__subtitle">Adminbot 0.1.0 (Bosqich 1.5)</div>
              </div>
            </div>
          </div>
        </section>

        <button
          class="btn btn--danger btn--block"
          data-action="logout"
          @click="logout"
        >Chiqish</button>
      </div>
    `,
  };
})();
