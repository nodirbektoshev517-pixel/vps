/**
 * PinGate.js — PIN-kod kirish ekrani.
 *
 * MUHIM:
 *   - PIN to'g'riligi localStorage'da emas. Backend (yoki mock) tekshiradi.
 *   - core/pin.js verifyPin(pin) → Services.auth.verifyPin(pin)
 *   - Backend 423 qaytarsa, LockScreen security_hold rejimida ochiladi
 *   - Failed attempts faqat UI uchun (backend o'z hisobini yuritadi)
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed } = Vue;
  const { Pin, UI } = window.Adminbot.Core;

  window.Adminbot.Components.PinGate = {
    name: 'PinGate',
    emits: ['unlocked'],
    setup(_props, { emit }) {
      const buffer = ref('');
      const isError = ref(false);
      const isVerifying = ref(false);
      const attemptsLeft = ref(null);
      const errorMsg = ref('');

      const filled = computed(() => buffer.value.length);
      const canSubmit = computed(() => buffer.value.length >= 4 && buffer.value.length <= 8 && !isVerifying.value);

      function press(digit) {
        if (isVerifying.value) return;
        if (buffer.value.length >= 8) return;
        isError.value = false;
        errorMsg.value = '';
        buffer.value += digit;
      }

      function backspace() {
        if (isVerifying.value) return;
        buffer.value = buffer.value.slice(0, -1);
        isError.value = false;
        errorMsg.value = '';
      }

      function clearAll() {
        if (isVerifying.value) return;
        buffer.value = '';
        isError.value = false;
        errorMsg.value = '';
      }

      async function tryVerify() {
        if (!canSubmit.value) return;
        isVerifying.value = true;
        try {
          const result = await Pin.verifyPin(buffer.value);
          if (result.ok) {
            buffer.value = '';
            attemptsLeft.value = null;
            emit('unlocked');
            return;
          }
          isError.value = true;
          buffer.value = '';
          if (result.attempts_left != null) {
            attemptsLeft.value = result.attempts_left;
            errorMsg.value = `PIN noto\'g\'ri. Qolgan urinishlar: ${result.attempts_left}`;
          } else {
            errorMsg.value = result.error || 'PIN noto\'g\'ri';
          }
        } catch (e) {
          isError.value = true;
          buffer.value = '';
          errorMsg.value = 'Xato: qayta urining';
        } finally {
          isVerifying.value = false;
        }
      }

      const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9'];

      return {
        buffer, filled, canSubmit, isError, isVerifying, errorMsg, attemptsLeft,
        press, backspace, clearAll, keys,
      };
    },
    template: `
      <div class="pin-screen">
        <div class="pin-screen__icon">🔒</div>
        <div class="pin-screen__title">PIN kodni kiriting</div>
        <div class="pin-screen__hint" v-if="!errorMsg">Adminbot'ga kirish uchun</div>
        <div class="auth-screen__error" v-if="errorMsg" style="margin: 0;">{{ errorMsg }}</div>
        <div class="pin-dots">
          <div
            v-for="i in 8" :key="i"
            class="pin-dot"
            :class="{ 'is-filled': i <= filled, 'is-error': isError }"
          ></div>
        </div>
        <div class="pin-keypad">
          <button
            v-for="k in keys" :key="k"
            class="pin-key"
            type="button"
            :data-key="k"
            :disabled="isVerifying"
            @click="press(k)"
          >{{ k }}</button>
          <button class="pin-key pin-key--clear" type="button" :disabled="isVerifying" @click="clearAll">Tozalash</button>
          <button class="pin-key" type="button" :data-key="'0'" :disabled="isVerifying" @click="press('0')">0</button>
          <button class="pin-key pin-key--del" type="button" :disabled="isVerifying" @click="backspace">⌫</button>
        </div>
        <button
          class="btn btn--primary"
          type="button"
          :disabled="!canSubmit"
          @click="tryVerify"
        >Kirish</button>
        <div v-if="isVerifying" class="hint">Tekshirilmoqda...</div>
      </div>
    `,
  };
})();
