/**
 * RootShell.js — eng yuqori darajadagi konteyner va xavfsizlik koordinatori.
 *
 * Holat mashinasi:
 *   - 'booting'  → AuthGate (auth + bootstrap)
 *   - 'locked'   → LockScreen (timeout, security_hold, session_expired, manual)
 *   - 'pin'      → PinGate (PIN kerak, hozir kiritamiz)
 *   - 'app'      → BottomNav + asosiy route komponenti
 *
 * EVENT ULANISH ORDER (kritik):
 *   - Events.connect()  → faqat 'app' holatiga o'tganda
 *   - Events.disconnect() → 'locked' yoki 'booting' ga qaytganda
 *
 * Bu PIN qulflanganida event stream ochiq qolib qolmasligini ta'minlaydi.
 */
(function () {
  'use strict';
  const Vue = window.Vue;
  const { ref, computed, onMounted, watch } = Vue;
  const { Router, Pin, Events, UI, Auth } = window.Adminbot.Core;

  window.Adminbot.Components.RootShell = {
    name: 'RootShell',
    setup() {
      const phase = ref('booting'); // booting | locked | pin | app

      function onAuthReady(_payload) {
        const adapter = window.Adminbot.Runtime.adapter;
        if (adapter && adapter.routes) {
          Router.setRoutes(adapter.routes);
        }
        const pinSt = Pin.getState();
        if (pinSt.pinRequired && pinSt.isLocked) {
          phase.value = 'pin';
        } else {
          phase.value = 'app';
        }
      }

      function onPinUnlocked() {
        phase.value = 'app';
      }

      function onPinLocked(_payload) {
        phase.value = 'locked';
      }

      function onEnterPin() {
        phase.value = 'pin';
      }

      function onReauth() {
        // Eski sessiyani tozalab, app'ni qayta yuklash
        try { Auth.clearSession(); } catch (e) {}
        window.location.reload();
      }

      onMounted(() => {
        Events.on('pin.locked', onPinLocked);
        Events.on('pin.unlocked', onPinUnlocked);

        // Telegram start_param — Startup module tomonidan parse qilingan
        const { Startup } = window.Adminbot.Core;
        const hint = Startup && Startup.startHint;
        if (hint && hint.type === 'route') {
          window.Adminbot.Runtime.routeHint = hint.value;
        } else if (hint && hint.type === 'event') {
          window.Adminbot.Runtime.eventIdHint = hint.value;
        }
      });

      // EVENT ULANISH ORDER:
      //   'app' ga o'tilganda → Events.connect() + syncSince
      //   'locked' ga o'tilganda → Events.disconnect()
      //   'pin' ga o'tilganda → Events.disconnect() (PIN ochilmaguncha stream yo'q)
      watch(phase, (now, prev) => {
        if (now === 'app' && prev !== 'app') {
          // App'ga kirildi — eventlarni ulanamiz
          Events.connect();
          // Missed events sync (bir martalik)
          Events.syncSince(Events.getLastEventId()).catch(() => {});

          // Route hint qo'llash
          const routeHint = window.Adminbot.Runtime.routeHint;
          if (routeHint && Router.routes.value.find(r => r.key === routeHint)) {
            Router.go(routeHint);
            window.Adminbot.Runtime.routeHint = null;
          }
        }
        if ((now === 'locked' || now === 'pin' || now === 'booting') && prev === 'app') {
          // App'dan chiqildi — eventlarni uzamiz
          Events.disconnect(now);
        }
      });

      // Asosiy route komponenti
      const currentRoute = Router.current;
      const currentComponent = computed(() => {
        if (!currentRoute.value) return null;
        const name = currentRoute.value.component;
        const comp = window.Adminbot.Components[name];
        if (!comp) {
          console.warn(`[RootShell] Komponent topilmadi: ${name}`);
          return null;
        }
        return comp;
      });

      const currentConfig = computed(() => {
        if (!currentRoute.value) return {};
        // Route-level config ustun bo'ladi (bitta komponentni turli route'larda
        // turli config bilan ishlatish uchun, masalan InboxList — reservations va orders)
        if (currentRoute.value.config) return currentRoute.value.config;
        const adapter = window.Adminbot.Runtime.adapter;
        if (!adapter) return {};
        const name = currentRoute.value.component;
        return (adapter.component_configs && adapter.component_configs[name]) || {};
      });

      return {
        phase, onAuthReady, onPinUnlocked, onEnterPin, onReauth,
        currentRoute, currentComponent, currentConfig,
        toasts: UI.toasts, modal: UI.modal,
        dismissToast: UI.dismissToast,
      };
    },
    template: `
      <div class="app-shell">
        <!-- Boot -->
        <component
          v-if="phase === 'booting'"
          :is="$options.AuthGate"
          @ready="onAuthReady"
        />

        <!-- Lock -->
        <component
          v-else-if="phase === 'locked'"
          :is="$options.LockScreen"
          @enter-pin="onEnterPin"
          @reauth="onReauth"
        />

        <!-- PIN -->
        <component
          v-else-if="phase === 'pin'"
          :is="$options.PinGate"
          @unlocked="onPinUnlocked"
        />

        <!-- Asosiy ilova -->
        <template v-else>
          <main class="app-shell__main">
            <component
              v-if="currentComponent"
              :is="currentComponent"
              :config="currentConfig"
              :key="currentRoute && currentRoute.key"
            />
            <div v-else class="empty">
              <div class="empty__icon">🤷</div>
              <div class="empty__title">Sahifa topilmadi</div>
            </div>
          </main>
          <component :is="$options.BottomNav" />
        </template>

        <!-- Toast stack -->
        <div class="toast-stack" v-if="toasts.length">
          <div
            v-for="t in toasts" :key="t.id"
            class="toast"
            :class="'toast--' + t.type"
            @click="dismissToast(t.id)"
            role="status"
          >{{ t.message }}</div>
        </div>

        <!-- Modal -->
        <div class="overlay" v-if="modal.open" @click.self="modal.onCancel && modal.onCancel()">
          <div class="dialog" role="dialog">
            <div class="dialog__title">{{ modal.title }}</div>
            <div class="dialog__body">{{ modal.body }}</div>
            <div class="dialog__actions">
              <button
                v-if="modal.cancelText"
                class="btn btn--secondary"
                type="button"
                @click="modal.onCancel && modal.onCancel()"
              >{{ modal.cancelText }}</button>
              <button
                class="btn btn--primary"
                type="button"
                @click="modal.onConfirm && modal.onConfirm()"
              >{{ modal.confirmText }}</button>
            </div>
          </div>
        </div>
      </div>
    `,
  };
})();
