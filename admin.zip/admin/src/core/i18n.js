/**
 * i18n.js — terminologiya almashtirish yordamchisi.
 *
 * Adminbot 1 ta tilda (Uzbek) ishlaydi. Lekin har biznes turi
 * o'z so'zlarini ishlatadi: "Mijoz" vs "Mehmon" vs "Bemor" vs "Do'kon".
 *
 * Bu modul terms obyektidan kelgan kalit asosida matn qaytaradi.
 * Adapter komponentga `terms: { customer: 'Mehmon' }` uzatadi,
 * komponent esa `t(props.terms, 'customer', 'Mijoz')` chaqirib oladi.
 */
(function () {
  'use strict';

  /**
   * Term swap.
   * @param {object} terms - adapter bergan terms obyekti
   * @param {string} key - kalit (masalan 'customer')
   * @param {string} fallback - agar adapter bermagan bo'lsa
   */
  function t(terms, key, fallback) {
    if (terms && terms[key]) return terms[key];
    return fallback;
  }

  /**
   * Plural — terms ichida key+'s' ko'p shakli bo'lishi mumkin.
   * Bizda Uzbek "lar" qo'shimchasi shart emas, lekin
   * "Mijozlar" / "Mehmonlar" alohida kalit sifatida turishi mumkin.
   */
  function plural(terms, key, fallback) {
    const pluralKey = key + 's';
    if (terms && terms[pluralKey]) return terms[pluralKey];
    return fallback;
  }

  window.Adminbot.Core.I18n = { t, plural };
})();
