/**
 * pin.js — AdminPinRuntime: PIN-kod boshqaruvi.
 *
 * MUHIM XAVFSIZLIK QOIDALARI:
 *   1. PIN frontend localStorage'da SAQLANMAYDI (na plaintext, na hash).
 *   2. PIN backend (yoki mock) tomonidan tasdiqlanadi: Services.auth.verifyPin(pin)
 *   3. setInterval ISHLATILMAYDI — polling taqiqlangan.
 *      Lock taymeri setTimeout (bir martalik) bilan rejalashtiriladi,
 *      foydalanuvchi faolligi bo'lganda qayta jadval qilinadi.
 *   4. Backend 401/423 qaytarsa — bu yerda lock holatiga o'tamiz.
 *
 * Frontend faqat UI tomonini boshqaradi:
 *   - PIN o'rnatilganmi (bootstrap'dan keladi)
 *   - Hozir qulflanganmi (timeout yoki manual)
 *   - Failed attempts (faqat UI uchun — backend o'z hisobini yuritadi)
 */
(function () {
  'use strict';

  const { Constants, Utils, Events, Services } = window.Adminbot.Core;

  const state = {
    // Backend bootstrap'dan keladi (PIN o'rnatilganmi)
    pinRequired: false,
    // Hozirgi adminbot session qulflanganmi
    isLocked: false,
    // Qulflash sababi: 'timeout' | 'manual' | 'security_hold' | 'session_expired'
    lockReason: null,
    // Backend bergan PIN session token (PIN ochilganidan keyin)
    // Bu localStorage'ga saqlanmaydi — faqat xotirada turadi.
    pinSession: null,
    // Foydalanuvchi UI uchun urinishlar soni (backend o'z hisobini yuritadi)
    failedAttempts: 0,
    // Timeout (daqiqa) — bootstrap'dan yoki sukut
    timeoutMin: Constants.PIN_TIMEOUT_DEFAULT_MIN,
    // Oxirgi faollik vaqti
    lastActiveAt: Date.now(),
  };

  // Bir martalik scheduled lock taymeri (setInterval EMAS — bu polling emas)
  let scheduledLockHandle = null;

  function setPinRequired(required) {
    state.pinRequired = !!required;
    if (!required) {
      state.isLocked = false;
      state.pinSession = null;
    }
  }

  function setTimeoutMin(min) {
    state.timeoutMin = Math.max(1, parseInt(min, 10) || Constants.PIN_TIMEOUT_DEFAULT_MIN);
    rescheduleLock();
    Events.emit('pin.timeout_changed', { min: state.timeoutMin });
  }

  /**
   * PIN'ni backend orqali tasdiqlash.
   * Mock mode'da mock handler shu kontraktni amalga oshiradi.
   *
   * @returns {Promise<{ ok: boolean, attempts_left?: number }>}
   */
  async function verifyPin(pin) {
    if (!pin || pin.length < 4) {
      return { ok: false, error: 'PIN kamida 4 raqamdan iborat bo\'lishi kerak' };
    }
    try {
      const resp = await Services.auth.verifyPin(pin);
      if (resp && (resp.ok || resp.success)) {
        if (resp.token) Utils.setToken(resp.token);
        state.isLocked = false;
        state.lockReason = null;
        state.failedAttempts = 0;
        state.pinSession = resp.session || {
          token: resp.pin_activity_token || 'pin-verified',
          expires_at: resp.pin_activity_expires_at || null,
        };
        touch();
        Events.emit('pin.unlocked');
        return { ok: true };
      }
      state.failedAttempts++;
      Events.emit('pin.failed', {
        attempts: state.failedAttempts,
        attempts_left: resp && resp.attempts_left,
      });
      return {
        ok: false,
        attempts_left: resp && resp.attempts_left,
        error: 'PIN noto\'g\'ri',
      };
    } catch (e) {
      // Backend xato javobi: 423 — security_hold, 429 — rate limit, ...
      if (e.status === 423) {
        lock('security_hold');
        return { ok: false, error: 'Xavfsizlik holati: kirish bloklangan' };
      }
      if (e.status === 429) {
        return { ok: false, error: 'Juda ko\'p urinish — biroz kuting' };
      }
      return { ok: false, error: Utils.errorText(e) };
    }
  }

  /**
   * Yangi PIN o'rnatish (backend orqali).
   */
  async function setPin(pin) {
    if (!pin || pin.length < 4) {
      throw new Error('PIN kamida 4 raqamdan iborat bo\'lishi kerak');
    }
    const resp = await Services.auth.setPin(pin);
    state.pinRequired = true;
    state.isLocked = false;
    state.pinSession = resp && resp.session ? resp.session : { token: 'pin-set' };
    Events.emit('pin.set');
    return resp;
  }

  /**
   * PIN o'chirish — joriy PIN bilan tasdiqlanadi.
   */
  async function removePin(currentPin) {
    await Services.auth.removePin(currentPin);
    state.pinRequired = false;
    state.isLocked = false;
    state.pinSession = null;
    Events.emit('pin.removed');
  }

  function lock(reason = 'manual') {
    if (!state.pinRequired && reason !== 'session_expired' && reason !== 'security_hold') {
      // PIN o'rnatilmagan bo'lsa, timeout lock ishlamaydi
      return;
    }
    state.isLocked = true;
    state.lockReason = reason;
    state.pinSession = null;
    cancelScheduledLock();
    Events.emit('pin.locked', { reason });
  }

  function touch() {
    state.lastActiveAt = Date.now();
    rescheduleLock();
  }

  function rescheduleLock() {
    cancelScheduledLock();
    if (!state.pinRequired || state.isLocked) return;
    // BIR MARTALIK setTimeout (polling emas — kelajakda bir nuqtaga yo'naltirilgan)
    const ms = state.timeoutMin * 60 * 1000;
    scheduledLockHandle = setTimeout(() => {
      scheduledLockHandle = null;
      lock('timeout');
    }, ms);
  }

  function cancelScheduledLock() {
    if (scheduledLockHandle) {
      clearTimeout(scheduledLockHandle);
      scheduledLockHandle = null;
    }
  }

  function getState() {
    return {
      pinRequired: state.pinRequired,
      isLocked: state.isLocked,
      lockReason: state.lockReason,
      failedAttempts: state.failedAttempts,
      timeoutMin: state.timeoutMin,
    };
  }

  /**
   * Boot vaqtida chaqiriladi. Foydalanuvchi faolligini tinglaydi
   * (tap/scroll/keydown), bu hodisalarda lock taymerini qayta jadval qiladi.
   *
   * Visibility API ham ishlatiladi: tab background'ga ketganda lock taymerini
   * pauza qilmaymiz — aksincha real vaqt ishlatamiz (timeoutMin daqiqa orqali).
   */
  function init() {
    const onActivity = Utils.throttle(touch, 3000);
    window.addEventListener('click', onActivity, { passive: true });
    window.addEventListener('touchstart', onActivity, { passive: true });
    window.addEventListener('keydown', onActivity, { passive: true });

    // Page visibility: foydalanuvchi qaytib kelganda lock holatini tekshirish
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        const elapsedMin = (Date.now() - state.lastActiveAt) / 60000;
        if (state.pinRequired && elapsedMin >= state.timeoutMin && !state.isLocked) {
          lock('timeout');
        } else {
          rescheduleLock();
        }
      }
    });

    // Backend session_expired yoki security_hold hodisalari — services tomonidan
    // emit qilinadi. Bizning ish: lock holatiga o'tish.
    Events.on('api.session_expired', () => lock('session_expired'));
    Events.on('api.security_hold', () => lock('security_hold'));
  }

  /**
   * Bootstrap javobidan PIN holatini qabul qilish.
   */
  function applyBootstrap(bootstrapResp) {
    if (!bootstrapResp || !bootstrapResp.pin) return;
    state.pinRequired = !!bootstrapResp.pin.required;
    state.isLocked = !!bootstrapResp.pin.locked;
    if (bootstrapResp.pin.timeout_min) {
      state.timeoutMin = parseInt(bootstrapResp.pin.timeout_min, 10) || state.timeoutMin;
    }
    if (state.pinRequired && !state.isLocked) {
      rescheduleLock();
    }
  }

  window.Adminbot.Core.Pin = {
    init,
    applyBootstrap,
    setPinRequired,
    setTimeoutMin,
    verifyPin,
    setPin,
    removePin,
    lock,
    touch,
    getState,
  };
})();
