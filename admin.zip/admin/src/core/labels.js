/**
 * labels.js — barcha status, role va boshqa label mapping'lar.
 *
 * YAGONA MANBA. Bu mapping universal — biznes turidan qat'iy nazar
 * "yangi" status hamma joyda bir xil rangda va bir xil so'z bilan ko'rinadi.
 *
 * Adapter faqat QAYSI kalitlar yoqilganini deklare qiladi:
 *   shop:        ['new', 'accepted', 'preparing', 'delivered', 'cancelled']
 *   restaurant:  ['new', 'accepted', 'preparing', 'served',   'cancelled']
 *   supplier:    ['new', 'accepted', 'shipped',   'completed', 'cancelled']
 *
 * Komponent shu kalitlarni shu jadvalda qidiradi va labelni/badge'ni oladi.
 * Agar adapter `terms` config bilan label'ni qayta nomlasa (Bosqich 2'da),
 * `formatStatus(key, terms)` shu override'ni qo'llaydi.
 *
 * Badge variant'lari (`03_primitives.css` dan):
 *   primary | success | warning | danger | info | neutral (default)
 */
(function () {
  'use strict';

  // === Order/Item status — barcha biznes turlari uchun universal ===
  const ORDER_STATUS = {
    new:           { label: 'Yangi',          badge: 'warning' },
    pending:       { label: 'Kutilmoqda',     badge: 'warning' },
    accepted:      { label: 'Qabul qilindi',  badge: 'info'    },
    preparing:     { label: 'Tayyorlanmoqda', badge: 'primary' },
    ready:         { label: 'Tayyor',         badge: 'info'    },
    on_delivery:   { label: 'Yo\'lda',         badge: 'primary' },
    delivered:     { label: 'Yetkazildi',     badge: 'success' },
    served:        { label: 'Berildi',        badge: 'success' },    // restaurant
    shipped:       { label: 'Jo\'natildi',     badge: 'success' },    // supplier
    completed:     { label: 'Tugatildi',      badge: 'success' },
    cancelled:     { label: 'Bekor qilindi',  badge: 'danger'  },
    refunded:      { label: 'Qaytarildi',     badge: 'neutral' },
    failed:        { label: 'Xato',           badge: 'danger'  },
  };

  // === Reservation status — restaurant/appointment uchun ===
  const RESERVATION_STATUS = {
    requested:     { label: 'So\'rov',         badge: 'warning' },
    confirmed:     { label: 'Tasdiqlandi',    badge: 'info'    },
    seated:        { label: 'O\'tirgan',       badge: 'primary' },
    no_show:       { label: 'Kelmagan',       badge: 'danger'  },
    completed:     { label: 'Tugatildi',      badge: 'success' },
    cancelled:     { label: 'Bekor',          badge: 'neutral' },
  };

  // === Foydalanuvchi role'lari ===
  const ROLE = {
    owner:    { label: 'Egasi',     badge: 'primary' },
    manager:  { label: 'Menejer',   badge: 'info'    },
    staff:    { label: 'Xodim',     badge: 'neutral' },
    courier:  { label: 'Kuryer',    badge: 'warning' },
  };

  // === Tenant status (suspended, security_hold, h.k.) ===
  const TENANT_STATUS = {
    active:         { label: 'Faol',           badge: 'success' },
    trial:          { label: 'Sinov',          badge: 'info'    },
    suspended:      { label: 'To\'xtatilgan',   badge: 'warning' },
    security_hold:  { label: 'Bloklangan',     badge: 'danger'  },
  };

  // === Mahsulot status ===
  const PRODUCT_STATUS = {
    active:    { label: 'Faol',         badge: 'success' },
    draft:     { label: 'Qoralama',     badge: 'neutral' },
    out_of_stock: { label: 'Yo\'q',      badge: 'warning' },
    archived:  { label: 'Arxivda',      badge: 'neutral' },
  };

  // === Restaurant stol holati (3.A) ===
  const TABLE_STATUS = {
    free:      { label: 'Bo\'sh',         badge: 'success' },
    reserved:  { label: 'Bron qilingan', badge: 'warning' },
    occupied:  { label: 'Band',           badge: 'danger'  },
    cleaning:  { label: 'Tozalanmoqda',  badge: 'info'    },
  };

  // === Restaurant sessiya holati (3.E) — DB enum: open/bill_requested/closing/closed/abandoned ===
  const SESSION_STATUS = {
    open:           { label: 'Ochiq',             badge: 'info'    },
    bill_requested: { label: 'Hisob so\'ralgan',  badge: 'warning' },
    closing:        { label: 'Yopilmoqda',        badge: 'primary' },
    closed:         { label: 'Yopilgan',          badge: 'success' },
    abandoned:      { label: 'Bekor qilingan',    badge: 'neutral' },
  };

  // === Appointment status (3.B) ===
  const APPOINTMENT_STATUS = {
    scheduled:    { label: 'Belgilangan',  badge: 'warning' },
    in_progress:  { label: 'Jarayonda',    badge: 'primary' },
    completed:    { label: 'Tugatildi',    badge: 'success' },
    cancelled:    { label: 'Bekor',        badge: 'neutral' },
    no_show:      { label: 'Kelmagan',     badge: 'danger'  },
  };

  // === Production stage (3.C) ===
  const PRODUCTION_STAGE = {
    brief_review:  { label: 'Topshiriq',     badge: 'warning' },
    proposal_sent: { label: 'Taklif yuborildi', badge: 'info' },
    approved:      { label: 'Tasdiqlandi',   badge: 'info'    },
    design:        { label: 'Dizayn',        badge: 'primary' },
    production:    { label: 'Ishlab chiqarish', badge: 'primary' },
    finishing:     { label: 'Yakuni',        badge: 'primary' },
    delivery:      { label: 'Yetkazib berish', badge: 'info'  },
    completed:     { label: 'Tugatildi',     badge: 'success' },
    cancelled:     { label: 'Bekor',         badge: 'neutral' },
  };

  // === Courier status (3.D) ===
  const COURIER_STATUS = {
    available:  { label: 'Bo\'sh',     badge: 'success' },
    on_route:   { label: 'Yo\'lda',    badge: 'primary' },
    busy:       { label: 'Band',       badge: 'warning' },
    offline:    { label: 'Oflayn',     badge: 'neutral' },
  };

  // === Lookup funksiyalari ===
  // Agar kalit jadvalda yo'q bo'lsa, neutral badge bilan kalitning o'zi qaytariladi.
  const FALLBACK = { label: '?', badge: 'neutral' };

  function lookup(table, key) {
    if (!key) return { ...FALLBACK };
    const entry = table[key];
    if (!entry) return { label: key, badge: 'neutral' };
    return { ...entry };
  }

  /**
   * Status'ni label + badge'ga aylantirish.
   *   formatStatus('new', 'order')                 → { label: 'Yangi', badge: 'warning' }
   *   formatStatus('confirmed', 'reservation')     → { label: 'Tasdiqlandi', badge: 'info' }
   *   formatStatus('owner', 'role')                → { label: 'Egasi', badge: 'primary' }
   *
   * Adapter terms override:
   *   formatStatus('delivered', 'order', { delivered: 'Yetib bordi' })
   *     → { label: 'Yetib bordi', badge: 'success' }
   */
  function formatStatus(key, kind = 'order', terms = null) {
    const tables = {
      order:        ORDER_STATUS,
      reservation:  RESERVATION_STATUS,
      role:         ROLE,
      tenant:       TENANT_STATUS,
      product:      PRODUCT_STATUS,
      table:        TABLE_STATUS,
      session:      SESSION_STATUS,
      appointment:  APPOINTMENT_STATUS,
      production:   PRODUCTION_STAGE,
      courier:      COURIER_STATUS,
    };
    const table = tables[kind] || tables.order;
    const result = lookup(table, key);
    if (terms && terms[key]) {
      result.label = terms[key];
    }
    return result;
  }

  // Ro'yxat qaytarish — barcha kalitlar (masalan filter chip'lar uchun)
  function listStatuses(kind = 'order') {
    const tables = {
      order:        ORDER_STATUS,
      reservation:  RESERVATION_STATUS,
      role:         ROLE,
      tenant:       TENANT_STATUS,
      product:      PRODUCT_STATUS,
      table:        TABLE_STATUS,
      session:      SESSION_STATUS,
      appointment:  APPOINTMENT_STATUS,
      production:   PRODUCTION_STAGE,
      courier:      COURIER_STATUS,
    };
    return Object.keys(tables[kind] || tables.order);
  }

  window.Adminbot.Core.Labels = {
    ORDER_STATUS,
    RESERVATION_STATUS,
    ROLE,
    TENANT_STATUS,
    PRODUCT_STATUS,
    TABLE_STATUS,
    SESSION_STATUS,
    APPOINTMENT_STATUS,
    PRODUCTION_STAGE,
    COURIER_STATUS,
    formatStatus,
    listStatuses,
  };
})();
