/**
 * ui.js — UI yordamchilari: toast, modal, sheet.
 *
 * Komponentlar UI.toast('Saqlandi') yoki UI.confirm('O\'chirilsinmi?') chaqirishi mumkin.
 * Bu yordamchilar Vue reaktiv state'ga yozadi va RootShell bu state'ni
 * o'qib mos UI'ni ko'rsatadi.
 */
(function () {
  'use strict';

  const Vue = window.Vue;
  const { ref, reactive } = Vue;
  const { Utils } = window.Adminbot.Core;

  // Toast queue (eng yangisi pastda, eski avtomatik o'chadi)
  const toasts = ref([]);

  function toast(message, opts = {}) {
    const t = {
      id: Utils.uuid(),
      message: String(message || ''),
      type: opts.type || 'info',     // info | success | error | warn
      duration: opts.duration || 3000,
    };
    toasts.value = [...toasts.value, t];
    if (t.duration > 0) {
      setTimeout(() => {
        toasts.value = toasts.value.filter(x => x.id !== t.id);
      }, t.duration);
    }
    return t.id;
  }

  function dismissToast(id) {
    toasts.value = toasts.value.filter(x => x.id !== id);
  }

  // Modal — bitta vaqtda bittasi
  const modal = reactive({
    open: false,
    title: '',
    body: '',
    confirmText: 'OK',
    cancelText: 'Bekor',
    onConfirm: null,
    onCancel: null,
    type: 'dialog', // dialog | sheet
  });

  function confirm(opts) {
    return new Promise((resolve) => {
      modal.title = opts.title || '';
      modal.body = opts.body || '';
      modal.confirmText = opts.confirmText || 'Ha';
      modal.cancelText = opts.cancelText || 'Yo\'q';
      modal.type = 'dialog';
      modal.onConfirm = () => {
        modal.open = false;
        resolve(true);
      };
      modal.onCancel = () => {
        modal.open = false;
        resolve(false);
      };
      modal.open = true;
    });
  }

  function alert(message, title = 'Diqqat') {
    return new Promise((resolve) => {
      modal.title = title;
      modal.body = message;
      modal.confirmText = 'OK';
      modal.cancelText = '';
      modal.type = 'dialog';
      modal.onConfirm = () => {
        modal.open = false;
        resolve(true);
      };
      modal.onCancel = null;
      modal.open = true;
    });
  }

  // Bottom-sheet — komponent ichidagi murakkab forma uchun
  // (Bosqich 1'da minimal — sodda dialog)
  const sheet = reactive({
    open: false,
    title: '',
    component: null,    // Vue komponent obyekti
    props: {},
    onClose: null,
  });

  function openSheet(opts) {
    sheet.title = opts.title || '';
    sheet.component = opts.component || null;
    sheet.props = opts.props || {};
    sheet.onClose = opts.onClose || null;
    sheet.open = true;
  }

  function closeSheet() {
    sheet.open = false;
    if (sheet.onClose) try { sheet.onClose(); } catch (e) {}
  }

  window.Adminbot.Core.UI = {
    toast, dismissToast, toasts,
    confirm, alert, modal,
    openSheet, closeSheet, sheet,
  };
})();
