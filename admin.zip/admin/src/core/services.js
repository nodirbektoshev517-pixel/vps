/**
 * services.js — Service layer.
 *
 * Komponentlar endpoint URL'larini bilmaydi. Buning o'rniga ular
 * shu service'lar orqali ishlaydi. Mock yoki real — bir xil interfeys.
 *
 * Maqsadi:
 *   1. Mavjud /platform/admin/* va target /platform/adminbot/* endpointlar
 *      orasidagi farqni izolyatsiya qilish.
 *   2. Mock mode va real mode bir xil chaqirilishi.
 *   3. Backend xato kodlarini (401/403/423/...) bitta joyda ishlash.
 *
 * Hozirgi adapter strategiyasi:
 *   - Mock mode'da hamma narsa mock handler'lar orqali ketadi.
 *   - Real mode'da target /platform/adminbot/{tenant}/* path'lariga so'rov ketadi.
 *   - Agar real backendda hali shu yangi path'lar bo'lmasa, service layer
 *     "compatibility" rejimda /platform/admin/* ga fallback qilishi mumkin
 *     (Bosqich 2/3 da kengaytiriladi).
 */
(function () {
  'use strict';

  const { Api, Utils, Events } = window.Adminbot.Core;

  function tenantPath(suffix) {
    const t = Utils.getTenantId() || 'unknown';
    return `/adminbot/${encodeURIComponent(t)}${suffix}`;
  }

  function tenantAdminPath(suffix) {
    const t = Utils.getTenantId() || 'unknown';
    return `/tenants/${encodeURIComponent(t)}${suffix}`;
  }

  function normalizeCategory(cat) {
    return {
      ...cat,
      icon: cat && (cat.icon || cat.emoji) || '📦',
      emoji: cat && (cat.emoji || cat.icon) || '📦',
      products_count: cat && cat.products_count || 0,
      order: cat && (cat.order != null ? cat.order : cat.sort_order || 0),
      active: !cat || cat.active !== false,
    };
  }

  function categoryPayload(data) {
    return {
      name: data && data.name || '',
      emoji: data && (data.emoji || data.icon) || '📦',
      parent_id: data && data.parent_id || null,
      fields: data && data.fields || [],
      order: data && (data.order != null ? data.order : data.sort_order || 0),
      active: !data || data.active !== false,
    };
  }

  function normalizeProduct(product) {
    const primary = product && product.primary_image || null;
    return {
      ...product,
      status: product && product.is_active === false ? 'draft' : 'active',
      image_url: product && product.image_url || primary && (
        primary.url || primary.card_url || primary.detail_url || primary.thumb_url
      ) || null,
      variants: product && product.variants || [],
    };
  }

  function productPayload(data) {
    return {
      category_id: data && data.category_id || null,
      name: data && data.name || '',
      description: data && data.description || '',
      price: data && data.price || 0,
      old_price: data && data.old_price || null,
      sku: data && data.sku || '',
      stock: data && data.stock != null ? data.stock : null,
      sort_order: data && data.sort_order || 0,
      is_active: !data || data.status !== 'draft',
      is_addon_candidate: !!(data && data.is_addon_candidate),
      properties: data && data.properties || {},
      option_groups: data && data.option_groups || [],
      addons: data && data.addons || [],
    };
  }

  function normalizeStaff(staff) {
    const full = String(staff && staff.full_name || '').trim();
    const parts = full.split(/\s+/).filter(Boolean);
    return {
      ...staff,
      first_name: staff && staff.first_name || parts[0] || full,
      last_name: staff && staff.last_name || parts.slice(1).join(' '),
      telegram_username: staff && (staff.telegram_username || staff.username) || '',
      role: staff && (staff.role || staff.role_key) || 'staff',
    };
  }

  function staffPayload(data) {
    const fullName = String(
      data && data.full_name
        || [data && data.first_name, data && data.last_name].filter(Boolean).join(' ')
        || ''
    ).trim();
    return {
      full_name: fullName,
      phone: data && data.phone || null,
      username: data && (data.username || data.telegram_username) || null,
      telegram_id: data && data.telegram_id || null,
      role_id: data && data.role_id || null,
      is_active: !data || data.is_active !== false,
      language: data && data.language || 'uz',
    };
  }

  function normalizeTable(table) {
    return {
      ...table,
      seats: table && (table.seats || table.capacity) || 4,
    };
  }

  function tablePayload(table, status) {
    return {
      branch_id: table && table.branch_id || null,
      hall_id: table && table.hall_id || null,
      number: table && table.number || '',
      capacity: table && (table.capacity || table.seats) || 4,
      status: status || table && table.status || 'free',
      sort_order: table && table.sort_order || 0,
      shape: table && table.shape || 'round',
      x: table && table.x != null ? table.x : null,
      y: table && table.y != null ? table.y : null,
      note: table && table.note || '',
      is_active: !table || table.is_active !== false,
    };
  }

  function normalizeBanquet(banquet) {
    return {
      ...banquet,
      name: banquet && (banquet.name || banquet.customer_name) || '',
      date: banquet && (banquet.date || banquet.starts_at) || null,
      contact_phone: banquet && (banquet.contact_phone || banquet.customer_phone) || '',
      menu_summary: banquet && (banquet.menu_summary || banquet.note) || '',
    };
  }

  function banquetPayload(data) {
    return {
      branch_id: data && data.branch_id || null,
      hall_id: data && data.hall_id || null,
      table_ids: data && data.table_ids || [],
      responsible_staff_id: data && data.responsible_staff_id || null,
      customer_name: data && (data.customer_name || data.name) || '',
      customer_phone: data && (data.customer_phone || data.contact_phone) || null,
      guest_count: data && data.guest_count || 1,
      starts_at: data && (data.starts_at || data.date) || new Date().toISOString(),
      duration_min: data && data.duration_min || 180,
      status: data && data.status || 'draft',
      note: data && (data.note || data.menu_summary) || null,
      deposit_amount: data && data.deposit_amount || null,
    };
  }

  /**
   * Backend xato kodlari uchun markaziy ishlovchi.
   * Xato turi bo'yicha global hodisa yuboradi — AuthGate, LockScreen,
   * UI toaster bu hodisalarni tinglaydi.
   *
   * 401 → session_expired (qayta auth/PIN kerak)
   * 403 → permission_denied (toast)
   * 423 → security_hold (LockScreen, sessiyani tozalash)
   * 409 → conflict (toast — "ma'lumot eskirdi, yangilang")
   * 422 → validation_error (caller javobini olib formaga ko'rsatadi)
   *  5xx → server_error (toast)
   */
  function handleApiError(err) {
    if (!err || !err.status) {
      // Tarmoq xatosi yoki noma'lum
      Events.emit('api.network_error', { error: err });
      return err;
    }
    const status = err.status;
    if (status === 401) {
      Events.emit('api.session_expired', { error: err });
    } else if (status === 403) {
      Events.emit('api.permission_denied', { error: err });
    } else if (status === 423) {
      Events.emit('api.security_hold', { error: err });
    } else if (status === 409) {
      Events.emit('api.conflict', { error: err });
    } else if (status === 422) {
      Events.emit('api.validation_error', { error: err });
    } else if (status >= 500) {
      Events.emit('api.server_error', { error: err });
    }
    return err;
  }

  async function call(method, path, body, opts = {}) {
    try {
      return await Api.request(method, path, body, opts);
    } catch (e) {
      handleApiError(e);
      throw e;
    }
  }

  // === Service'lar ===

  const auth = {
    /**
     * Telegram initData → JWT. Real backend endpoint:
     *   POST /platform/admin/auth/telegram
     * Mock mode'da to'g'ridan-to'g'ri auth.js loginMock chaqiradi (services'siz).
     */
    async telegramLogin(initData) {
      return call('POST', '/admin/auth/telegram', {
        tenant_id: Utils.getTenantId(),
        init_data: initData,
      });
    },
    /**
     * PIN tekshiruvi. Frontend localStorage'da hash saqlamaydi.
     * Backend (yoki mock) tasdiqlaydi.
     *   POST /platform/auth/staff/pin/verify
     * Javob: { ok: true, session: {...}, expires_at: '...' } yoki { ok: false, attempts_left: 2 }
     */
    async verifyPin(pin) {
      return call('POST', '/auth/staff/pin/verify', { pin });
    },
    /**
     * Yangi PIN belgilash. Bu backend tomonidan tasdiqlanadi va
     * server-side hash saqlanadi. Frontend faqat plaintext yuboradi
     * (HTTPS ostida) va keyin uni unutadi.
     *   POST /platform/auth/staff/pin/setup
     */
    async setPin(pin) {
      return call('POST', '/auth/staff/pin/setup', { pin });
    },
    /**
     * PIN o'chirish — mavjud PIN bilan tasdiqlanadi.
     */
    async removePin(currentPin) {
      return call('POST', '/adminbot/auth/pin/remove', { pin: currentPin });
    },
    /**
     * Sessionni manual lock qilish (foydalanuvchi yopilmoqchi).
     *   POST /platform/adminbot/auth/lock
     */
    async lock() {
      return call('POST', '/adminbot/auth/lock', {});
    },
    /**
     * Logout — token bekor qilish.
     */
    async logout() {
      try { return await call('POST', '/adminbot/auth/logout', {}); }
      catch (e) { return null; }
    },
  };

  const bootstrap = {
    /**
     * Adminbot ochilganda barcha boshlang'ich ma'lumotni bitta so'rovda olish:
     *   GET /platform/admin/bootstrap
     * Javob: {
     *   tenant: { id, name, business_type, status, ... },
     *   user: { id, role, permissions, ... },
     *   pin: { required: true|false, locked: true|false },
     *   notifications: { unread_count, last_event_id },
     *   feature_flags: {...},
     * }
     *
     * URL'dagi tenant_id faqat hint — backend session bo'yicha aniqlaydi.
     */
    async fetch() {
      return call('GET', '/admin/bootstrap');
    },
  };

  const dashboard = {
    /**
     * Dashboard statistikalari (cached, biznes-turi-mustaqil shakl):
     *   GET /platform/adminbot/{tenant_id}/dashboard
     * Adapter `component_configs.Dashboard.stat_cards` orqali qaysi
     * stat'lar ko'rsatilishini deklare qiladi.
     */
    async fetch() {
      const statsResp = await call('GET', '/admin/orders/stats');
      let layoutResp = null;
      try {
        layoutResp = await call('GET', tenantAdminPath('/restaurant-layout'));
      } catch (e) {}
      const tables = layoutResp && layoutResp.tables || [];
      const occupied = tables.filter(t => t.status === 'occupied').length;
      const todayOrders = statsResp && (statsResp.today_orders || statsResp.delivered_today || 0);
      const revenue = statsResp && (statsResp.today_revenue || statsResp.collected_today || 0);
      return {
        stats: {
          todays_orders: { label: 'Bugungi buyurtmalar', value: todayOrders },
          todays_reservations: { label: 'Bugungi bronlar', value: todayOrders },
          new_orders: { label: 'Yangi', value: statsResp && statsResp.new_orders || 0 },
          revenue: { label: 'Tushum', value: revenue, format: 'money' },
          occupied_tables: { label: 'Band stollar', value: occupied },
          avg_party_size: { label: "O'rtacha mehmon", value: 0 },
        },
        last_updated_at: new Date().toISOString(),
      };
    },
  };

  const staff = {
    async list() {
      const resp = await call('GET', tenantAdminPath('/staff'));
      return { items: ((resp && resp.staff) || []).map(normalizeStaff) };
    },
    async create(data) {
      return call('POST', tenantAdminPath('/staff'), staffPayload(data));
    },
    async update(id, data) {
      return call('PATCH', tenantAdminPath(`/staff/${encodeURIComponent(id)}`), staffPayload(data));
    },
    async remove(id) {
      return call('DELETE', tenantAdminPath(`/staff/${encodeURIComponent(id)}`));
    },
  };

  const inbox = {
    /**
     * Buyurtmalar ro'yxati. Pagination — cursor-based.
     * @param {object} filter
     *   status?:    string | 'all'        — status bo'yicha filter (sukut: hamma)
     *   cursor?:    string                — oxirgi olingan item ID dan keyin
     *   page_size?: number (default 20, max 50)
     */
    async list(filter = {}) {
      const q = new URLSearchParams();
      if (filter.status && filter.status !== 'all') q.set('status', filter.status);
      if (filter.cursor) q.set('cursor', filter.cursor);
      q.set('page_size', String(filter.page_size || 20));
      if (filter.status && filter.status !== 'all') q.set('status', filter.status);
      const qs = q.toString();
      const resp = await call('GET', `/admin/orders${qs ? `?${qs}` : ''}`);
      return {
        items: resp && resp.orders || [],
        total: resp && resp.total || 0,
        next_cursor: null,
        has_more: false,
      };
    },
    /**
     * Status o'zgartirish. Backend transition qoidalarini tekshiradi (409 mumkin).
     */
    async updateStatus(itemId, newStatus) {
      return call('PATCH', `/admin/orders/${encodeURIComponent(itemId)}/status`, {
        status: newStatus,
      });
    },
  };

  const events = {
    /**
     * Missed events — frontend reconnect/resume qilganda chaqiradi.
     *   GET /platform/adminbot/{tenant_id}/events?since={cursor}
     * Bu DOIMIY POLLING UCHUN ISHLATILMAYDI.
     */
    async syncSince(cursor) {
      const q = cursor ? `?after=${encodeURIComponent(cursor)}` : '';
      return call('GET', `/admin/events${q}`);
    },
    /**
     * Eventni ack qilish (qabul qildim).
     *   POST /platform/adminbot/{tenant_id}/events/{event_id}/ack
     */
    async ack(eventId) {
      return { success: true, event_id: eventId };
    },
  };

  // === Catalog (Bosqich 2.2) ===
  const catalog = {
    async listCategories() {
      const resp = await call('GET', tenantAdminPath('/categories'));
      return { items: ((resp && resp.categories) || []).map(normalizeCategory) };
    },
    async createCategory(data) {
      return call('POST', tenantAdminPath('/categories'), categoryPayload(data));
    },
    async updateCategory(id, data) {
      return call('PATCH', tenantAdminPath(`/categories/${encodeURIComponent(id)}`), categoryPayload(data));
    },
    async deleteCategory(id) {
      return call('DELETE', tenantAdminPath(`/categories/${encodeURIComponent(id)}`));
    },
    async listProducts(filter = {}) {
      const resp = await call('GET', tenantAdminPath('/products'));
      let items = ((resp && resp.products) || []).map(normalizeProduct);
      if (filter.category_id) {
        items = items.filter(p => p.category_id === filter.category_id);
      }
      return { items, next_cursor: null, has_more: false };
    },
    async createProduct(data) {
      return call('POST', tenantAdminPath('/products'), productPayload(data));
    },
    async updateProduct(id, data) {
      return call('PATCH', tenantAdminPath(`/products/${encodeURIComponent(id)}`), productPayload(data));
    },
    async deleteProduct(id) {
      return call('DELETE', tenantAdminPath(`/products/${encodeURIComponent(id)}`));
    },
    async deleteProductImage(productId, imageId) {
      return call(
        'DELETE',
        tenantAdminPath(`/products/${encodeURIComponent(productId)}/images/${encodeURIComponent(imageId)}`)
      );
    },
    async uploadProductImage(productId, file) {
      const form = new FormData();
      form.append('image', file, file && file.name || 'product.webp');
      return call(
        'POST',
        tenantAdminPath(`/products/${encodeURIComponent(productId)}/images`),
        form,
        { timeoutMs: 45000 }
      );
    },
    async setPrimaryProductImage(productId, imageIds, primaryImageId) {
      return call('PATCH', tenantAdminPath(`/products/${encodeURIComponent(productId)}/images/order`), {
        image_ids: imageIds || [],
        primary_image_id: primaryImageId || null,
      });
    },
  };

  // === Customers (Bosqich 2.3) ===
  const customers = {
    async list(filter = {}) {
      const q = new URLSearchParams();
      if (filter.q) q.set('q', filter.q);
      if (filter.cursor) q.set('cursor', filter.cursor);
      q.set('page_size', String(filter.page_size || 20));
      return call('GET', tenantPath(`/customers?${q}`));
    },
    async get(id) {
      return call('GET', tenantPath(`/customers/${encodeURIComponent(id)}`));
    },
  };

  // === Reports (Bosqich 2.3) ===
  const reports = {
    async fetch(key) {
      return call('GET', tenantPath(`/reports/${encodeURIComponent(key)}`));
    },
  };

  // === Broadcast + Audit (Bosqich 2.4) ===
  const broadcast = {
    async send(data) {
      return call('POST', tenantPath('/broadcast'), data);
    },
  };

  const audit = {
    async list(filter = {}) {
      const q = new URLSearchParams();
      if (filter.type) q.set('type', filter.type);
      if (filter.cursor) q.set('cursor', filter.cursor);
      q.set('page_size', String(filter.page_size || 20));
      return call('GET', tenantPath(`/audit?${q}`));
    },
  };

  // === Supplier (Bosqich 2.5) ===
  const supplier = {
    async listShops() {
      return call('GET', tenantPath('/supplier/shops'));
    },
    async setTier(shopId, tier) {
      return call('PATCH', tenantPath(`/supplier/shops/${encodeURIComponent(shopId)}/tier`), { tier });
    },
    async setCreditLimit(shopId, limit) {
      return call('PATCH', tenantPath(`/supplier/shops/${encodeURIComponent(shopId)}/credit-limit`), { credit_limit: limit });
    },
    async listBalance(filter = {}) {
      const q = new URLSearchParams();
      if (filter.shop_id) q.set('shop_id', filter.shop_id);
      if (filter.cursor) q.set('cursor', filter.cursor);
      q.set('page_size', String(filter.page_size || 20));
      return call('GET', tenantPath(`/supplier/balance?${q}`));
    },
    async addBalanceOperation(data) {
      return call('POST', tenantPath('/supplier/balance/operation'), data);
    },
    async listInvites() {
      return call('GET', tenantPath('/supplier/invites'));
    },
    async createInvite(data) {
      return call('POST', tenantPath('/supplier/invites'), data);
    },
    async deleteInvite(id) {
      return call('DELETE', tenantPath(`/supplier/invites/${encodeURIComponent(id)}`));
    },
    async listPendingShops() {
      return call('GET', tenantPath('/supplier/pending-shops'));
    },
    async approveShop(id) {
      return call('POST', tenantPath(`/supplier/pending-shops/${encodeURIComponent(id)}/approve`), {});
    },
    async rejectShop(id) {
      return call('POST', tenantPath(`/supplier/pending-shops/${encodeURIComponent(id)}/reject`), {});
    },
  };

  // === Restaurant (Bosqich 3.A) ===
  const restaurant = {
    async listTables() {
      const resp = await call('GET', tenantAdminPath('/restaurant-layout'));
      return {
        items: ((resp && resp.tables) || []).map(normalizeTable),
        halls: resp && resp.halls || [],
        branches: resp && resp.branches || [],
      };
    },
    async setTableStatus(id, status) {
      const layout = await call('GET', tenantAdminPath('/restaurant-layout'));
      const table = ((layout && layout.tables) || []).find(t => t.id === id);
      if (!table) throw new Error('Stol topilmadi');
      return call('PATCH', tenantAdminPath(`/restaurant-layout/tables/${encodeURIComponent(id)}`), tablePayload(table, status));
    },
    async listReservations(filter = {}) {
      return { items: [], next_cursor: null, has_more: false };
    },
    async updateReservationStatus(id, status) {
      return call('PATCH', tenantPath(`/restaurant/reservations/${encodeURIComponent(id)}/status`), { status });
    },
    async listBanquets() {
      const resp = await call('GET', tenantAdminPath('/restaurant-layout/banquets'));
      return { items: ((resp && resp.banquets) || []).map(normalizeBanquet) };
    },
    async createBanquet(data) {
      return call('POST', tenantAdminPath('/restaurant-layout/banquets'), banquetPayload(data));
    },
    async updateBanquet(id, data) {
      return call('PATCH', tenantAdminPath(`/restaurant-layout/banquets/${encodeURIComponent(id)}`), banquetPayload(data));
    },
    async deleteBanquet(id) {
      return call('DELETE', tenantAdminPath(`/restaurant-layout/banquets/${encodeURIComponent(id)}`));
    },
  };

  // === Appointment service (Bosqich 3.B) ===
  const appointment = {
    async listServices() {
      return call('GET', tenantPath('/appointment/services'));
    },
    async createService(data) {
      return call('POST', tenantPath('/appointment/services'), data);
    },
    async updateService(id, data) {
      return call('PATCH', tenantPath(`/appointment/services/${encodeURIComponent(id)}`), data);
    },
    async deleteService(id) {
      return call('DELETE', tenantPath(`/appointment/services/${encodeURIComponent(id)}`));
    },
    async listSpecialists() {
      return call('GET', tenantPath('/appointment/specialists'));
    },
    async createSpecialist(data) {
      return call('POST', tenantPath('/appointment/specialists'), data);
    },
    async updateSpecialist(id, data) {
      return call('PATCH', tenantPath(`/appointment/specialists/${encodeURIComponent(id)}`), data);
    },
    async deleteSpecialist(id) {
      return call('DELETE', tenantPath(`/appointment/specialists/${encodeURIComponent(id)}`));
    },
    async listAppointments(filter = {}) {
      const q = new URLSearchParams();
      if (filter.status && filter.status !== 'all') q.set('status', filter.status);
      if (filter.date) q.set('date', filter.date);
      if (filter.specialist_id) q.set('specialist_id', filter.specialist_id);
      return call('GET', tenantPath(`/appointment/appointments?${q}`));
    },
    async updateAppointmentStatus(id, status) {
      return call('PATCH', tenantPath(`/appointment/appointments/${encodeURIComponent(id)}/status`), { status });
    },
    async listWalkIn() {
      return call('GET', tenantPath('/appointment/walk-in'));
    },
    async addWalkIn(data) {
      return call('POST', tenantPath('/appointment/walk-in'), data);
    },
    async removeWalkIn(id) {
      return call('DELETE', tenantPath(`/appointment/walk-in/${encodeURIComponent(id)}`));
    },
  };

  // === Custom production (Bosqich 3.C) ===
  const production = {
    async listBriefs(filter = {}) {
      const q = new URLSearchParams();
      if (filter.stage && filter.stage !== 'all') q.set('stage', filter.stage);
      if (filter.cursor) q.set('cursor', filter.cursor);
      q.set('page_size', String(filter.page_size || 20));
      return call('GET', tenantPath(`/production/briefs?${q}`));
    },
    async getBrief(id) {
      return call('GET', tenantPath(`/production/briefs/${encodeURIComponent(id)}`));
    },
    async advanceStage(id, stage) {
      return call('PATCH', tenantPath(`/production/briefs/${encodeURIComponent(id)}/stage`), { stage });
    },
    async sendProposal(id, price) {
      return call('POST', tenantPath(`/production/briefs/${encodeURIComponent(id)}/proposal`), { price });
    },
    async listDispatches() {
      return call('GET', tenantPath('/production/dispatches'));
    },
    async createDispatch(data) {
      return call('POST', tenantPath('/production/dispatches'), data);
    },
    async updateDispatchStatus(id, status) {
      return call('PATCH', tenantPath(`/production/dispatches/${encodeURIComponent(id)}/status`), { status });
    },
  };

  // ==========================================================================
  // RESTAURANT SESSIONS — restoran sessiyalari (Phase 1)
  // ==========================================================================
  // InboxList list interface'iga moslashtirilgan ({ items, total, next_cursor, has_more }).
  // updateStatus(id, toStatus) wrapper:
  //   - toStatus === 'closing' → POST /admin/sessions/{id}/start-closing
  //   - toStatus === 'closed'  → POST /admin/sessions/{id}/close (default body)
  // Backend transition'lari: bill_requested → closing → closed.
  const restaurantSessions = {
    async list(filter = {}) {
      const params = new URLSearchParams();
      if (filter.status && filter.status !== 'all') {
        params.set('status', filter.status);
      }
      const qs = params.toString();
      const resp = await call('GET', `/admin/sessions${qs ? `?${qs}` : ''}`);
      const sessions = (resp && resp.sessions) || [];
      return {
        items: sessions,
        total: (resp && resp.total) || sessions.length,
        next_cursor: null,
        has_more: false,
      };
    },

    async get(sessionId) {
      const resp = await call('GET', `/admin/sessions/${encodeURIComponent(sessionId)}`);
      return (resp && resp.session) || null;
    },

    async startClosing(sessionId) {
      const resp = await call(
        'POST',
        `/admin/sessions/${encodeURIComponent(sessionId)}/start-closing`,
      );
      return (resp && resp.session) || null;
    },

    async close(sessionId, body = {}) {
      const payload = {
        payment_method: body.payment_method || 'cash',
        paid_amount: body.paid_amount ?? null,
        tip_amount: body.tip_amount ?? null,
        note: body.note ?? null,
      };
      const resp = await call(
        'POST',
        `/admin/sessions/${encodeURIComponent(sessionId)}/close`,
        payload,
      );
      return (resp && resp.session) || null;
    },

    // OrderCard pattern bilan moslik uchun (Services.X.updateStatus(id, toStatus)).
    // SessionCard ichidan `Services.restaurantSessions.updateStatus(id, 'closing'|'closed')` chaqiriladi.
    async updateStatus(sessionId, toStatus) {
      if (toStatus === 'closing') {
        return await restaurantSessions.startClosing(sessionId);
      }
      if (toStatus === 'closed') {
        return await restaurantSessions.close(sessionId);
      }
      throw new Error(`restaurantSessions.updateStatus: noma'lum transition: ${toStatus}`);
    },
  };

  // === Courier (Bosqich 3.D) ===
  const courier = {
    async listCouriers(filter = {}) {
      const q = new URLSearchParams();
      if (filter.status && filter.status !== 'all') q.set('status', filter.status);
      return call('GET', tenantPath(`/courier/couriers?${q}`));
    },
    async setCourierStatus(id, status) {
      return call('PATCH', tenantPath(`/courier/couriers/${encodeURIComponent(id)}/status`), { status });
    },
    async listDeliveries(filter = {}) {
      const q = new URLSearchParams();
      if (filter.status && filter.status !== 'all') q.set('status', filter.status);
      if (filter.cursor) q.set('cursor', filter.cursor);
      q.set('page_size', String(filter.page_size || 20));
      return call('GET', tenantPath(`/courier/deliveries?${q}`));
    },
    async assignDelivery(id, courierId) {
      return call('POST', tenantPath(`/courier/deliveries/${encodeURIComponent(id)}/assign`), { courier_id: courierId });
    },
  };

  window.Adminbot.Core.Services = {
    auth,
    bootstrap,
    dashboard,
    staff,
    inbox,
    events,
    catalog,
    customers,
    reports,
    broadcast,
    audit,
    supplier,
    restaurant,    // Bosqich 3.A
    restaurantSessions,
    appointment,   // Bosqich 3.B
    production,    // Bosqich 3.C
    courier,       // Bosqich 3.D
    handleApiError,
  };
})();
