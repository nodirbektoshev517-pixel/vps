/**
 * constants.js — sozlamalar va kalitlar.
 *
 * Bu yerda biznes-mustaqil konstantalar:
 *   - API endpoint
 *   - localStorage kalitlari
 *   - sukut bo'yicha sozlamalar
 */
(function () {
  'use strict';

  const C = {
    // Backend bazasi. Mock mode ishlatilganda bu ahamiyatsiz.
    API_BASE: 'https://api.classmonitor.uz/platform',

    // localStorage kalitlari
    TOKEN_KEY: 'adminbot.token',
    TENANT_KEY: 'adminbot.tenant',
    PIN_KEY: 'adminbot.pin_hash',
    PIN_TIMEOUT_KEY: 'adminbot.pin_timeout_min',
    THEME_KEY: 'adminbot.theme',
    LAST_ACTIVE_KEY: 'adminbot.last_active',

    // Sukut bo'yicha — PIN qulflashgacha vaqt (daqiqa)
    PIN_TIMEOUT_DEFAULT_MIN: 5,

    // Cache TTL (ms)
    CACHE_DEFAULT_TTL_MS: 60 * 1000,

    // Events polling oraliq (ms)
    EVENTS_POLL_INTERVAL_MS: 15 * 1000,

    // API timeout (ms)
    API_TIMEOUT_MS: 15 * 1000,

    // Mock rejim faolligi — URL'da ?mock=true bo'lsa
    // (api.js bu bayroqdan foydalanadi)
    MOCK_PARAM: 'mock',

    // Tenant aniqlash uchun URL parametr
    TENANT_PARAM: 'tenant_id',
  };

  window.Adminbot.Core.Constants = C;
})();
