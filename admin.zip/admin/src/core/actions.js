/**
 * actions.js — write-action wrapper.
 *
 * Buyurtma statusini o'zgartirish, xodim o'chirish, mahsulot yangilash —
 * bularning hammasi bir xil shablon bilan ishlaydi:
 *   1. permission tekshir
 *   2. (ixtiyoriy) confirm dialog
 *   3. loading state on
 *   4. service layer chaqir
 *   5. xato bo'lsa toast + onError
 *   6. muvaffaqiyat bo'lsa success toast + onSuccess
 *   7. loading state off
 *
 * Bu wrapper komponentlardagi try/catch/UI.toast takrorini kamaytiradi.
 *
 * Misol (Bosqich 2'da):
 *   runAction({
 *     permission: 'orders.update',
 *     actionLabel: 'Buyurtma statusini o\'zgartirish',
 *     action: () => Services.inbox.updateStatus(order.id, 'accepted'),
 *     onSuccess: (result) => { order.status = result.status; },
 *     successMessage: 'Status yangilandi',
 *   });
 *
 * @param {object} opts
 *   permission?:    string — Permissions.require chaqiriladi
 *   actionLabel?:   string — permission xato xabarida ishlatiladi
 *   confirm?:       { title, body, confirmText, cancelText } | null
 *   action:         async () => result — service layer chaqirig'i
 *   onSuccess?:     async (result) => void
 *   onError?:       async (err) => void
 *   successMessage?: string — true bo'lsa toast (success)
 *   errorMessage?:  string — Utils.errorText(err) o'rniga ishlatiladi
 *   loading?:       Vue ref<boolean> — action davomida true qilinadi
 *   silent?:        boolean — toast'lar bekor qilinadi (default false)
 *
 * @returns {Promise<{ ok: boolean, reason?: string, result?: any, error?: any }>}
 */
(function () {
  'use strict';

  async function runAction(opts) {
    const {
      permission,
      actionLabel,
      confirm,
      action,
      onSuccess,
      onError,
      successMessage,
      errorMessage,
      loading,
      silent = false,
    } = opts || {};

    const { Permissions, UI, Utils } = window.Adminbot.Core;

    // 1. Permission check (UX filter — backend baribir tekshiradi)
    if (permission) {
      if (!Permissions.can(permission)) {
        if (!silent) {
          UI.toast(`Ruxsat yo'q: ${actionLabel || permission}`, { type: 'warn' });
        }
        return { ok: false, reason: 'permission' };
      }
    }

    // 2. Confirm dialog
    if (confirm) {
      const ok = await UI.confirm(confirm);
      if (!ok) return { ok: false, reason: 'cancelled' };
    }

    if (typeof action !== 'function') {
      console.error('[runAction] action funktsiya bo\'lishi shart');
      return { ok: false, reason: 'invalid' };
    }

    // 3. Loading state
    if (loading && 'value' in loading) loading.value = true;

    // 4. Action execute
    try {
      const result = await action();
      // 6. Success
      if (successMessage && !silent) {
        UI.toast(successMessage, { type: 'success' });
      }
      if (onSuccess) {
        try { await onSuccess(result); } catch (e) {
          console.error('[runAction] onSuccess xatosi:', e);
        }
      }
      return { ok: true, result };
    } catch (e) {
      // 5. Error
      // Backend 401/403/423 — services.js allaqachon api.* event'larini chiqargan.
      // Bu yerda biz faqat UI ko'rsatamiz.
      const msg = errorMessage || Utils.errorText(e);
      if (!silent) {
        // 401/403/423 holatlarida toast minimal — chunki LockScreen yoki
        // permission_denied subscribe handler o'zi UI'ni boshqaradi
        const status = e && e.status;
        const isHandledByGlobal = (status === 401 || status === 423);
        if (!isHandledByGlobal) {
          UI.toast(msg, { type: 'error' });
        }
      }
      if (onError) {
        try { await onError(e); } catch (innerE) {
          console.error('[runAction] onError xatosi:', innerE);
        }
      }
      return { ok: false, reason: 'error', error: e };
    } finally {
      // 7. Loading off
      if (loading && 'value' in loading) loading.value = false;
    }
  }

  window.Adminbot.Core.Actions = { runAction };
})();
