/**
 * composables.js — Vue composable'lar.
 *
 * useEvents() — komponent unmount bo'lganda barcha event listener'larni
 *               avtomatik o'chiradi. Bu memory leak'ni oldini oladi.
 *
 * Talab: bu modul Vue yuklangandan keyin yuklanishi shart.
 */
(function () {
  'use strict';

  const Vue = window.Vue;
  if (!Vue) {
    console.warn('[composables] Vue yuklanmagan');
    return;
  }
  const { onScopeDispose } = Vue;
  const { Events } = window.Adminbot.Core;

  /**
   * useEvents() — komponentda event subscribe qilishning xavfsiz yo'li.
   *
   * Misol:
   *   const { subscribe } = useEvents();
   *   subscribe('order.created', (e) => addOrder(e.payload));
   *   subscribe('order.status_changed', (e) => updateOrder(e));
   *   // unmount avtomatik tozalanadi
   */
  function useEvents() {
    const offs = [];

    function subscribe(type, handler) {
      const off = Events.subscribe(type, handler);
      offs.push(off);
      return off;
    }

    // Vue 3'da onScopeDispose komponent unmount yoki setup scope'i yopilganda
    // chaqiriladi. Hatto effectScope ichida ishlatilganda ham xavfsiz.
    onScopeDispose(() => {
      for (const off of offs) {
        try { off(); } catch (e) {}
      }
      offs.length = 0;
    });

    return { subscribe };
  }

  window.Adminbot.Core.Composables = { useEvents };
})();
