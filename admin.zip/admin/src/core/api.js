/**
 * api.js — REST API wrapper.
 *
 * - Mock rejim: utils.isMockMode() === true bo'lsa, mocks ro'yxatidan javob
 * - Real rejim: window.Adminbot.Core.Constants.API_BASE ga so'rov
 *
 * Mock'lar window.Adminbot.Mocks ostida turadi (mocks/ papkasi).
 * Har mock fayl o'zini register qiladi:
 *   window.Adminbot.Mocks.register('GET', '/staff', () => [...])
 */
(function () {
  'use strict';

  const { Constants, Utils } = window.Adminbot.Core;

  if (!window.Adminbot.Mocks) {
    window.Adminbot.Mocks = {
      _handlers: new Map(),
      register(method, path, handler) {
        this._handlers.set(`${method.toUpperCase()} ${path}`, handler);
      },
      find(method, path) {
        // Aniq mos
        const exact = this._handlers.get(`${method.toUpperCase()} ${path}`);
        if (exact) return exact;
        // Pattern mos (/staff/:id)
        for (const [key, h] of this._handlers.entries()) {
          const [m, pattern] = key.split(' ');
          if (m !== method.toUpperCase()) continue;
          const regex = new RegExp('^' + pattern.replace(/:[^/]+/g, '([^/]+)') + '$');
          const match = path.match(regex);
          if (match) return (body, opts) => h(body, opts, match.slice(1));
        }
        return null;
      },
    };
  }

  async function request(method, path, body, opts = {}) {
    const isMock = Utils.isMockMode() && !opts.forceReal;
    method = method.toUpperCase();

    if (isMock) {
      // Query string'ni ajratamiz — mock pattern faqat path bilan moslashtiriladi,
      // lekin handler full URL'ni opts.url orqali oladi (filter param'lar uchun)
      const qIdx = path.indexOf('?');
      const pathOnly = qIdx >= 0 ? path.slice(0, qIdx) : path;
      const handler = window.Adminbot.Mocks.find(method, pathOnly);
      if (!handler) {
        throw new Error(`Mock topilmadi: ${method} ${pathOnly}`);
      }
      // Sun'iy kechikish — UX'ni real ishlatish kabi his qilish uchun
      await new Promise(r => setTimeout(r, opts.mockDelay != null ? opts.mockDelay : 80));
      try {
        // opts.url - full path with query (handler buni parse qila oladi)
        const result = await handler(body, { ...opts, url: path });
        return result;
      } catch (e) {
        throw e;
      }
    }

    // Real fetch
    const url = (opts.base || Constants.API_BASE) + path;
    const isFormData = typeof FormData !== 'undefined' && body instanceof FormData;
    const headers = { ...(opts.headers || {}) };
    if (!isFormData) headers['Content-Type'] = 'application/json';
    const token = Utils.getToken();
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const tenant = Utils.getTenantId();
    if (tenant) headers['X-Tenant-Id'] = tenant;

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), opts.timeoutMs || Constants.API_TIMEOUT_MS);

    let resp;
    try {
      resp = await fetch(url, {
        method,
        headers,
        body: body != null ? (isFormData ? body : JSON.stringify(body)) : undefined,
        signal: controller.signal,
      });
    } catch (e) {
      clearTimeout(timer);
      throw new Error('Tarmoq xatosi: ' + Utils.errorText(e));
    }
    clearTimeout(timer);

    if (!resp.ok) {
      let errBody = null;
      try { errBody = await resp.json(); } catch (e) {}
      const msg = errBody ? Utils.errorText(errBody) : `HTTP ${resp.status}`;
      const err = new Error(msg);
      err.status = resp.status;
      err.body = errBody;
      throw err;
    }

    if (resp.status === 204) return null;
    return resp.json();
  }

  const Api = {
    get: (path, opts) => request('GET', path, null, opts),
    post: (path, body, opts) => request('POST', path, body, opts),
    put: (path, body, opts) => request('PUT', path, body, opts),
    patch: (path, body, opts) => request('PATCH', path, body, opts),
    delete: (path, opts) => request('DELETE', path, null, opts),
    request,
  };

  window.Adminbot.Core.Api = Api;
})();
