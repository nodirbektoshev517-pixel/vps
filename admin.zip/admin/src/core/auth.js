/**
 * auth.js — Telegram initData → JWT autentifikatsiya oqimi.
 *
 * Real oqim:
 *   1. window.Telegram.WebApp.initData o'qiladi (Telegram tomonidan signed)
 *   2. Services.auth.telegramLogin(initData) → backend tekshiradi → JWT
 *   3. Bootstrap chaqiriladi (services.bootstrap.fetch) — backend tenant'ni
 *      AUTHORITATIVE belgilaydi (URL'dagi tenant_id faqat hint).
 *   4. business_type bootstrap javobidan olinadi → adapter tanlanadi
 *
 * Mock oqim (test/dev): Telegram mavjud emas yoki ?mock=true bo'lsa,
 *   to'g'ridan-to'g'ri mock session yaratiladi va bootstrap mock'i chaqiriladi.
 *
 * MUHIM:
 *   - URL'dagi tenant_id faqat boshlang'ich taklif.
 *   - Real mode'da backend qaysi tenantga ruxsat bersa, o'sha ishlatiladi.
 *   - User URL'da boshqa tenant yozsa, backend 403 qaytaradi.
 */
(function () {
  'use strict';

  const { Constants, Utils } = window.Adminbot.Core;

  const session = {
    token: null,
    user: null,
    tenant_id: null,
    business_type: null,
    permissions: [],
    expires_at: null,
  };

  function getSession() {
    return { ...session };
  }

  function isAuthenticated() {
    return !!session.token;
  }

  function clearSession() {
    session.token = null;
    session.user = null;
    session.tenant_id = null;
    session.business_type = null;
    session.permissions = [];
    session.expires_at = null;
    Utils.setToken(null);
  }

  async function login() {
    const isMock = Utils.isMockMode();
    if (isMock) return loginMock();

    const tg = window.Telegram && window.Telegram.WebApp;
    if (!tg || !tg.initData) {
      throw new Error('Telegram initData mavjud emas — Telegram\'da oching');
    }

    const { Services } = window.Adminbot.Core;
    try {
      const resp = await Services.auth.telegramLogin(tg.initData);
      applySessionResponse(resp);
      return getSession();
    } catch (e) {
      throw new Error('Autentifikatsiya: ' + Utils.errorText(e));
    }
  }

  async function loginMock() {
    const { Startup } = window.Adminbot.Core;

    // URL'dagi tenant_id faqat hint (Startup allowlist'dan o'tgan)
    const tenantHint = Utils.getTenantId() || 'demo_tenant';
    Utils.setTenantId(tenantHint);

    const fakeToken = 'mock_' + Math.random().toString(36).slice(2);
    Utils.setToken(fakeToken);

    // URL parametrlar bilan rolni/biznesni almashtirsa bo'ladi (faqat dev)
    const role = (Startup && Startup.get('role')) || 'owner';
    const businessType = (Startup && Startup.get('biz')) || 'shop';

    applySessionResponse({
      token: fakeToken,
      user: {
        id: 'usr_demo',
        telegram_id: 123456789,
        first_name: 'Demo',
        last_name: 'Admin',
        username: 'demo_admin',
        role: role,
        avatar_url: null,
      },
      tenant_id: tenantHint,
      business_type: businessType,
      permissions: role === 'owner' ? ['*'] : ['orders.view', 'orders.update'],
      expires_at: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
    });
    return getSession();
  }

  function applySessionResponse(resp) {
    if (!resp || !resp.token) {
      throw new Error('Auth javobida token yo\'q');
    }
    session.token = resp.token;
    session.user = resp.user || null;
    session.tenant_id = resp.tenant_id || null;
    session.business_type = resp.business_type || null;
    session.permissions = resp.permissions || [];
    session.expires_at = resp.expires_at || null;
    Utils.setToken(resp.token);
    if (resp.tenant_id) Utils.setTenantId(resp.tenant_id);
  }

  /**
   * Bootstrap javobi backend'dan keladi va session ma'lumotini overwrite qiladi.
   * Bu — backend AUTHORITATIVE bo'lgan joy. URL'dagi tenant_id faqat hint edi.
   */
  function applyBootstrap(bootstrapResp) {
    if (!bootstrapResp) return;
    if (bootstrapResp.tenant && bootstrapResp.tenant.id) {
      session.tenant_id = bootstrapResp.tenant.id;
      Utils.setTenantId(bootstrapResp.tenant.id);
    }
    if (bootstrapResp.tenant && bootstrapResp.tenant.business_type) {
      session.business_type = bootstrapResp.tenant.business_type;
    }
    // Backend /admin/bootstrap "me" maydonida qaytaradi (admin_panel.py).
    // Mock'lar esa "user" maydonida qaytaradi (eski kontrakt).
    // Ikkalasiga ham mos kelishi uchun ikkala kalitni qabul qilamiz.
    const meOrUser = bootstrapResp.me || bootstrapResp.user;
    if (meOrUser) {
      session.user = meOrUser;
      if (meOrUser.permissions) {
        session.permissions = meOrUser.permissions;
      }
    }
  }

  function logout() {
    clearSession();
  }

  /**
   * Session boot uchun yaroqlimi?
   * Backend kontrakti: bootstrap'dan keyin TENANT_ID, BUSINESS_TYPE va
   * PERMISSIONS to'liq bo'lishi kerak. Aks holda BottomNav bo'sh ko'rinadi
   * va sabab tushunarsiz bo'ladi — bu yerda aniq xato qaytaramiz.
   */
  function validateSession() {
    const errors = [];
    if (!session.token) errors.push('token yo\'q');
    if (!session.tenant_id) errors.push('tenant_id yo\'q (bootstrap.tenant.id)');
    if (!session.business_type) errors.push('business_type yo\'q (bootstrap.tenant.business_type)');
    if (!Array.isArray(session.permissions) || session.permissions.length === 0) {
      errors.push('permissions bo\'sh (bootstrap.me.permissions tekshiring — backend "user" emas "me" qaytaradi)');
    }
    return { ok: errors.length === 0, errors };
  }

  window.Adminbot.Core.Auth = {
    login, logout, getSession, isAuthenticated, clearSession,
    applyBootstrap, applySessionResponse, validateSession,
  };
})();
