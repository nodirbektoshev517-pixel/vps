/**
 * router.js — oddiy hash-asoslangan router.
 *
 * Adapter routes ro'yxati beradi:
 *   [{ key: 'dashboard', component: 'Dashboard', label: 'Bosh', icon: '🏠' }, ...]
 *
 * Router bittasini "active" deb belgilaydi va Vue reactivity orqali
 * App shell ko'rsatadi. Bottom nav tap'ga reaktsiya qiladi.
 *
 * URL: #/dashboard, #/staff, h.k.
 */
(function () {
  'use strict';

  const { Events } = window.Adminbot.Core;
  const Vue = window.Vue;
  if (!Vue) {
    console.error('Vue mavjud emas, router init qila olmaymiz');
    return;
  }

  const { ref, computed } = Vue;

  const currentKey = ref(null);
  const routes = ref([]);

  function parseHash() {
    const h = window.location.hash || '';
    const m = h.match(/^#\/([^/?]+)/);
    return m ? m[1] : null;
  }

  function setRoutes(list) {
    routes.value = list || [];
    // Agar joriy key ro'yxatda yo'q bo'lsa — birinchi RUXSAT BERILGAN'ni tanlaymiz
    const valid = currentKey.value && routes.value.find(r => r.key === currentKey.value);
    if (!valid) {
      const Permissions = window.Adminbot.Core && window.Adminbot.Core.Permissions;
      const canRoute = (r) =>
        !Permissions || typeof Permissions.canRoute !== 'function'
          ? true
          : Permissions.canRoute(r);

      const fromHash = parseHash();
      const fromHashRoute = fromHash && routes.value.find(r => r.key === fromHash);
      if (fromHashRoute && canRoute(fromHashRoute)) {
        currentKey.value = fromHash;
      } else if (routes.value.length) {
        // Permission yo'q route'larni o'tkazib yuboramiz —
        // aks holda Dashboard mount bo'lib backend 403 javob beradi
        const first = routes.value.find(canRoute) || routes.value[0];
        currentKey.value = first.key;
        replaceHash(currentKey.value);
      }
    }
  }

  function go(key) {
    if (!routes.value.find(r => r.key === key)) return;
    currentKey.value = key;
    pushHash(key);
    Events.emit('route.changed', { key });
  }

  function pushHash(key) {
    const target = `#/${key}`;
    if (window.location.hash !== target) {
      window.history.pushState(null, '', target);
    }
  }

  function replaceHash(key) {
    const target = `#/${key}`;
    if (window.location.hash !== target) {
      window.history.replaceState(null, '', target);
    }
  }

  function onHashChange() {
    const k = parseHash();
    if (k && routes.value.find(r => r.key === k) && k !== currentKey.value) {
      currentKey.value = k;
      Events.emit('route.changed', { key: k });
    }
  }

  function init() {
    window.addEventListener('hashchange', onHashChange);
    window.addEventListener('popstate', onHashChange);
  }

  const current = computed(() => {
    if (!currentKey.value) return null;
    return routes.value.find(r => r.key === currentKey.value) || null;
  });

  window.Adminbot.Core.Router = {
    init, setRoutes, go,
    currentKey, current, routes,
  };
})();
