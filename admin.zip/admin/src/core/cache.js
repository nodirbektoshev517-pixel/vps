/**
 * cache.js — AdminCache: TTL bilan kalit-qiymat cache.
 *
 * Klient-tomon cache. localStorage va xotirada (memory) ishlaydi.
 * Cooldown: bir xil kalitga juda tez-tez fetch yuborilmasligi uchun.
 *
 * Ishlatish:
 *   const data = await Cache.fetch('orders:list', async () => api.get('/orders'), { ttl: 30000 });
 */
(function () {
  'use strict';

  const { Constants } = window.Adminbot.Core;
  const MEM = new Map();          // kalit → { value, expiresAt }
  const COOLDOWN = new Map();     // kalit → lastFetchAt
  const INFLIGHT = new Map();     // kalit → Promise (deduplikatsiya)

  function now() {
    return Date.now();
  }

  function get(key) {
    const entry = MEM.get(key);
    if (!entry) return null;
    if (entry.expiresAt && entry.expiresAt < now()) {
      MEM.delete(key);
      return null;
    }
    return entry.value;
  }

  function set(key, value, ttlMs = Constants.CACHE_DEFAULT_TTL_MS) {
    MEM.set(key, {
      value,
      expiresAt: ttlMs > 0 ? now() + ttlMs : 0,
    });
  }

  function invalidate(prefix) {
    if (!prefix) {
      MEM.clear();
      COOLDOWN.clear();
      return;
    }
    for (const k of Array.from(MEM.keys())) {
      if (k.startsWith(prefix)) MEM.delete(k);
    }
    for (const k of Array.from(COOLDOWN.keys())) {
      if (k.startsWith(prefix)) COOLDOWN.delete(k);
    }
  }

  /**
   * Cache'dan o'qish, agar bo'lmasa fetcher chaqirish.
   * - cooldownMs: oxirgi fetch'dan keyin shu vaqt o'tmaguncha
   *   yangi fetch yuborilmaydi (eski qiymat qaytadi).
   * - deduplikatsiya: bir xil kalitga parallel fetch — bitta promise.
   */
  async function fetchOrLoad(key, fetcher, opts = {}) {
    const ttl = opts.ttl != null ? opts.ttl : Constants.CACHE_DEFAULT_TTL_MS;
    const cooldownMs = opts.cooldownMs || 0;

    // 1. Memory cache'da bormi va eskirmagan?
    const cached = get(key);
    if (cached !== null && !opts.force) return cached;

    // 2. Cooldown ichidamizmi?
    const lastFetch = COOLDOWN.get(key) || 0;
    if (cooldownMs && (now() - lastFetch) < cooldownMs && cached !== null) {
      return cached;
    }

    // 3. Bir xil kalitga inflight bormi?
    if (INFLIGHT.has(key)) {
      return INFLIGHT.get(key);
    }

    // 4. Yangi fetch
    const p = (async () => {
      try {
        const value = await fetcher();
        set(key, value, ttl);
        COOLDOWN.set(key, now());
        return value;
      } finally {
        INFLIGHT.delete(key);
      }
    })();
    INFLIGHT.set(key, p);
    return p;
  }

  function stats() {
    return {
      entries: MEM.size,
      keys: Array.from(MEM.keys()),
      inflight: Array.from(INFLIGHT.keys()),
    };
  }

  window.Adminbot.Core.Cache = {
    get,
    set,
    invalidate,
    fetch: fetchOrLoad,
    stats,
  };
})();
