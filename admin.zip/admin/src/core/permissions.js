/**
 * permissions.js — RBAC tekshiruvi.
 *
 * Sessiyada `permissions: ['orders.view', 'orders.update', ...]` ro'yxati turadi.
 * '*' — barcha ruxsatlar (owner).
 * Komponent yoki marshrut so'raydi: can('orders.update') → true/false.
 *
 * Adapter routes ham permission kalitiga ega bo'lishi mumkin:
 *   { key: 'settings', component: 'SettingsView', permission: 'settings.view' }
 */
(function () {
  'use strict';

  const { Auth } = window.Adminbot.Core;

  function can(permission) {
    if (!permission) return true;
    const s = Auth.getSession();
    if (!s.permissions) return false;
    if (s.permissions.includes('*')) return true;
    if (s.permissions.includes(permission)) return true;
    // Wildcard moduliga ruxsat — masalan 'orders.*'
    const parts = permission.split('.');
    for (let i = parts.length; i > 0; i--) {
      const wild = parts.slice(0, i - 1).concat('*').join('.');
      if (s.permissions.includes(wild)) return true;
    }
    return false;
  }

  function canRoute(route) {
    if (!route) return false;
    if (route.permission && !can(route.permission)) return false;
    return true;
  }

  function canAny(perms) {
    if (!perms || !perms.length) return true;
    return perms.some(p => can(p));
  }

  function canAll(perms) {
    if (!perms || !perms.length) return true;
    return perms.every(p => can(p));
  }

  /**
   * require(key, actionName) — agar ruxsat yo'q bo'lsa toast chiqaradi.
   *
   * MUHIM: bu xavfsizlik tekshiruvi EMAS. Bu faqat UX yordamchisi.
   * Real ruxsat backend tomonidan tasdiqlanadi (har write endpoint'da).
   * Frontend ruxsat tekshiruvi tugmalarni yashirish uchun ishlatiladi.
   *
   * Misol:
   *   if (!Permissions.require('staff.manage', 'Xodim qo\'shish')) return;
   *   // davom etadi
   */
  function require(key, actionName) {
    if (can(key)) return true;
    const { UI } = window.Adminbot.Core;
    if (UI && typeof UI.toast === 'function') {
      const label = actionName || key;
      UI.toast(`Ruxsat yo'q: ${label}`, { type: 'warn' });
    }
    return false;
  }

  window.Adminbot.Core.Permissions = { can, canRoute, canAny, canAll, require };
})();
