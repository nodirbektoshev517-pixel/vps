/**
 * utils.js — umumiy yordamchi funksiyalar.
 *
 * Hech qaysi biznes turiga bog'liq emas. Faqat sof JS yordamchilari.
 *
 * Xavfsizlik:
 *   - URL params O'QILMAYDI bu yerda — Startup modulga delegatsiya
 *   - mock mode SHARTLI — production buildda hech qachon true qaytarmaydi
 *   - real mode tokeni xotirada (page reload'da yo'qoladi — Telegram
 *     initData har refresh'da qayta keladi)
 *   - mock mode tokeni localStorage'da (dev qulayligi uchun)
 */
(function () {
  'use strict';

  const { Constants } = window.Adminbot.Core;

  // === Mock mode ===
  // Manba: Startup moduliga delegatsiya (allowlist + hostname + build flag).
  // Startup yuklanmagan bo'lsa — false (xavfsiz default).
  function isMockMode() {
    const S = window.Adminbot.Core.Startup;
    if (!S || typeof S.isMockAllowed !== 'function') return false;
    return S.isMockAllowed();
  }

  // === Tenant ===
  // 1) Startup tomonidan tekshirilgan tenant_id (URL'dan, allowlist'dan o'tgan)
  // 2) localStorage cache (faqat hint, backend bootstrap authoritative)
  function getTenantId() {
    const S = window.Adminbot.Core.Startup;
    if (S && typeof S.get === 'function') {
      const v = S.get('tenant_id');
      if (v) return v;
    }
    try {
      return localStorage.getItem(Constants.TENANT_KEY) || null;
    } catch (e) {
      return null;
    }
  }

  function setTenantId(id) {
    try {
      if (id) localStorage.setItem(Constants.TENANT_KEY, id);
      else localStorage.removeItem(Constants.TENANT_KEY);
    } catch (e) {}
  }

  // === Token ===
  // Real mode: xotirada (in-memory). Page refresh'da yo'qoladi —
  // Telegram initData har boot'da qayta keladi, qayta auth muammosi yo'q.
  // Mock mode: localStorage (dev qulayligi).
  const _tokenMem = { value: null };

  function getToken() {
    if (isMockMode()) {
      try { return localStorage.getItem(Constants.TOKEN_KEY) || null; } catch (e) { return null; }
    }
    return _tokenMem.value;
  }

  function setToken(t) {
    if (isMockMode()) {
      try {
        if (t) localStorage.setItem(Constants.TOKEN_KEY, t);
        else localStorage.removeItem(Constants.TOKEN_KEY);
      } catch (e) {}
    } else {
      _tokenMem.value = t || null;
    }
  }

  function clearAllAuthStorage() {
    // Lock/logout vaqtida hamma sensitive cache tozalanadi
    _tokenMem.value = null;
    try {
      localStorage.removeItem(Constants.TOKEN_KEY);
      // last_event_id ham tozalanmaydi — backend syncSince ishlasin
      // tenant cache esa odatda saqlanadi, ammo lock'da xavfsizroq tozalash
    } catch (e) {}
  }

  // === Xato matni ===
  // Backend formatlarini to'g'ri o'qishi kerak:
  //   1) Standard Error obyekt: err.message (string)
  //   2) Backend custom: { success: false, error: { message, code, field, ... } }
  //   3) FastAPI HTTPException: { detail: "..." }
  //   4) Pydantic validation: { detail: [{ loc, msg, type }, ...] }
  //   5) Plain string
  // MUHIM: hech qachon obyekt qaytarmasligi shart — concatenationda
  // "[object Object]" chiqib qoladi.
  function errorText(err) {
    if (!err) return 'Noma\'lum xato';
    if (typeof err === 'string') return err;

    // 1) Standard Error.message (faqat string bo'lsa)
    if (typeof err.message === 'string' && err.message) return err.message;

    // 2) Backend custom format: err.error obyekt bo'lishi mumkin
    if (err.error && typeof err.error === 'object') {
      if (typeof err.error.message === 'string' && err.error.message) return err.error.message;
      if (typeof err.error.detail === 'string' && err.error.detail) return err.error.detail;
      // field bilan: "Field 'X': Y" formatda
      if (typeof err.error.field === 'string' && err.error.field && typeof err.error.code === 'string') {
        return err.error.code + ' (' + err.error.field + ')';
      }
    }
    // err.error string ham bo'lishi mumkin (eski format)
    if (typeof err.error === 'string' && err.error) return err.error;

    // 3) FastAPI HTTPException: { detail: "..." }
    if (typeof err.detail === 'string' && err.detail) return err.detail;
    // 4) Pydantic validation array: [{loc, msg, type}, ...]
    if (Array.isArray(err.detail)) {
      return err.detail
        .map(d => (d && (d.msg || d.message)) || JSON.stringify(d))
        .join('; ');
    }

    // Last resort — JSON.stringify (lekin obyekt EMAS, string qaytadi)
    try {
      return JSON.stringify(err);
    } catch (e) {
      return 'Noma\'lum xato';
    }
  }

  // === Formatlash ===
  function formatMoney(n, currency = 'so\'m') {
    if (n == null || isNaN(n)) return '—';
    const formatted = new Intl.NumberFormat('uz-UZ', {
      maximumFractionDigits: 0,
    }).format(Number(n));
    return `${formatted} ${currency}`;
  }

  function formatDate(dt, opts = {}) {
    if (!dt) return '—';
    const d = (dt instanceof Date) ? dt : new Date(dt);
    if (isNaN(d.getTime())) return '—';
    const { date = true, time = true } = opts;
    const parts = [];
    if (date) {
      parts.push(d.toLocaleDateString('uz-UZ', {
        day: '2-digit', month: '2-digit', year: 'numeric',
      }));
    }
    if (time) {
      parts.push(d.toLocaleTimeString('uz-UZ', {
        hour: '2-digit', minute: '2-digit', hour12: false,
      }));
    }
    return parts.join(' ');
  }

  function formatTime(dt) {
    return formatDate(dt, { date: false, time: true });
  }

  function formatPhone(p) {
    if (!p) return '—';
    const s = String(p).replace(/[^\d+]/g, '');
    // +998 XX XXX XX XX
    if (s.startsWith('+998') && s.length === 13) {
      return `+998 ${s.slice(4, 6)} ${s.slice(6, 9)} ${s.slice(9, 11)} ${s.slice(11)}`;
    }
    return s;
  }

  function relativeTime(dt) {
    if (!dt) return '—';
    const d = (dt instanceof Date) ? dt : new Date(dt);
    if (isNaN(d.getTime())) return '—';
    const diff = (Date.now() - d.getTime()) / 1000;
    if (diff < 60) return 'hozir';
    if (diff < 3600) return `${Math.floor(diff / 60)} daq oldin`;
    if (diff < 86400) return `${Math.floor(diff / 3600)} soat oldin`;
    if (diff < 604800) return `${Math.floor(diff / 86400)} kun oldin`;
    return formatDate(d, { time: false });
  }

  function initials(obj) {
    // Foydalanuvchi yoki xodim ob'ektidan bosh harf
    if (!obj) return '?';
    if (typeof obj === 'string') {
      const parts = obj.trim().split(/\s+/);
      return ((parts[0] || '?')[0] + (parts[1] || '')[0] || '').toUpperCase() || '?';
    }
    const f = (obj.first_name || obj.firstName || '?')[0] || '';
    const l = (obj.last_name || obj.lastName || '')[0] || '';
    return ((f + l).toUpperCase()) || '?';
  }

  // === Klasslar ===
  function classNames(...parts) {
    // Klassik utility — `classNames('btn', { 'is-active': true, 'is-disabled': false }, ['btn--lg'])`
    const out = [];
    for (const p of parts) {
      if (!p) continue;
      if (typeof p === 'string') out.push(p);
      else if (Array.isArray(p)) out.push(classNames(...p));
      else if (typeof p === 'object') {
        for (const k of Object.keys(p)) if (p[k]) out.push(k);
      }
    }
    return out.filter(Boolean).join(' ');
  }

  // === JSON ===
  function safeJsonParse(s, fallback = null) {
    if (s == null) return fallback;
    try { return JSON.parse(s); } catch (e) { return fallback; }
  }

  // === Async helperlar ===
  function debounce(fn, ms = 300) {
    let h;
    return function (...args) {
      clearTimeout(h);
      h = setTimeout(() => fn.apply(this, args), ms);
    };
  }

  function throttle(fn, ms = 300) {
    let last = 0;
    let timer = null;
    return function (...args) {
      const now = Date.now();
      const wait = ms - (now - last);
      if (wait <= 0) {
        last = now;
        fn.apply(this, args);
      } else if (!timer) {
        timer = setTimeout(() => {
          last = Date.now();
          timer = null;
          fn.apply(this, args);
        }, wait);
      }
    };
  }

  function uuid() {
    // Client-side ID'lar uchun (kriptografik mustahkam emas)
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  function deepClone(o) {
    if (o == null) return o;
    return JSON.parse(JSON.stringify(o));
  }

  // === DEPRECATED ===
  // `qs(name)` — Startup.get(...) bilan almashtirilishi kerak.
  // Saqlanmoqda chunki ba'zi joylarda (eski mock'lar) hali ishlatiladi,
  // lekin yangi kod buni ishlatmasin.
  // Startup yuklanmagan bo'lsa — null (URL'ga to'g'ridan-to'g'ri murojaat YO'Q,
  // shuning uchun bu fayl ham startup_security qoidasiga to'g'ri keladi).
  function qs(name) {
    const S = window.Adminbot.Core.Startup;
    if (!S || typeof S.get !== 'function') return null;
    const v = S.get(name);
    if (v === undefined) return null;
    return typeof v === 'boolean' ? (v ? 'true' : null) : v;
  }

  window.Adminbot.Core.Utils = {
    isMockMode,
    qs,                  // DEPRECATED — yangi kod Startup'dan foydalansin
    getTenantId,
    setTenantId,
    getToken,
    setToken,
    clearAllAuthStorage,
    errorText,
    formatMoney,
    formatDate,
    formatTime,
    formatPhone,
    relativeTime,
    initials,
    classNames,
    safeJsonParse,
    debounce,
    throttle,
    uuid,
    deepClone,
  };
})();