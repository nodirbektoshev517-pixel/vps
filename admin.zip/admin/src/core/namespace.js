/**
 * namespace.js — global namespace ochiladi.
 *
 * Bu fayl barcha boshqa fayllardan oldin yuklanishi shart.
 * Hech qachon to'g'ridan-to'g'ri window ga yozilmaydi — hamma narsa
 * window.Adminbot ostida turadi.
 */
(function () {
  'use strict';

  if (window.Adminbot) return;

  window.Adminbot = {
    // Yadro modullari (utils, auth, cache, h.k.)
    Core: {},
    // Komponent bank — name → Vue component definition
    Components: {},
    // Biznes adapterlar — business_type → adapter object
    Business: {},
    // Bo'sh slot — boot fayli to'ldiradi (adapter, app instance)
    Runtime: {
      adapter: null,
      app: null,
      tenant: null,
      ready: false,
    },
    // Versiya
    version: '0.1.0',
  };
})();
