/**
 * theme.js — Telegram tema → CSS o'zgaruvchilar.
 *
 * Telegram Mini App'da `window.Telegram.WebApp.themeParams` ranglarni beradi
 * (light/dark — foydalanuvchi sozlamasi bo'yicha). Biz ularni
 * --tg-bg, --tg-text, --tg-hint, --tg-link, --tg-button, --tg-button-text
 * CSS o'zgaruvchilariga yozamiz. CSS shu o'zgaruvchilarni ishlatadi.
 *
 * Telegram mavjud bo'lmaganda — sukut bo'yicha dark tema beriladi.
 */
(function () {
  'use strict';

  const DEFAULTS = {
    light: {
      bg: '#ffffff',
      secondaryBg: '#f1f1f4',
      text: '#000000',
      hint: '#999999',
      link: '#2481cc',
      button: '#2481cc',
      buttonText: '#ffffff',
      destructive: '#ff3b30',
      header: '#ffffff',
    },
    dark: {
      bg: '#17212b',
      secondaryBg: '#232e3c',
      text: '#f5f5f5',
      hint: '#7d8b99',
      link: '#6ab3f3',
      button: '#5288c1',
      buttonText: '#ffffff',
      destructive: '#ff453a',
      header: '#17212b',
    },
  };

  function detectTelegram() {
    return !!(window.Telegram && window.Telegram.WebApp);
  }

  function getColorScheme() {
    if (detectTelegram() && window.Telegram.WebApp.colorScheme) {
      return window.Telegram.WebApp.colorScheme; // 'light' | 'dark'
    }
    // Brauzer preferences fallback
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return 'dark';
    }
    return 'light';
  }

  function readTelegramTheme() {
    const tg = detectTelegram() ? window.Telegram.WebApp : null;
    const tp = (tg && tg.themeParams) ? tg.themeParams : {};
    const scheme = getColorScheme();
    const defaults = DEFAULTS[scheme];
    return {
      scheme,
      bg: tp.bg_color || defaults.bg,
      secondaryBg: tp.secondary_bg_color || defaults.secondaryBg,
      text: tp.text_color || defaults.text,
      hint: tp.hint_color || defaults.hint,
      link: tp.link_color || defaults.link,
      button: tp.button_color || defaults.button,
      buttonText: tp.button_text_color || defaults.buttonText,
      destructive: tp.destructive_text_color || defaults.destructive,
      header: tp.header_bg_color || tp.bg_color || defaults.header,
    };
  }

  function apply(theme) {
    const r = document.documentElement;
    r.style.setProperty('--tg-bg', theme.bg);
    r.style.setProperty('--tg-secondary-bg', theme.secondaryBg);
    r.style.setProperty('--tg-text', theme.text);
    r.style.setProperty('--tg-hint', theme.hint);
    r.style.setProperty('--tg-link', theme.link);
    r.style.setProperty('--tg-button', theme.button);
    r.style.setProperty('--tg-button-text', theme.buttonText);
    r.style.setProperty('--tg-destructive', theme.destructive);
    r.style.setProperty('--tg-header', theme.header);
    r.setAttribute('data-theme', theme.scheme);
  }

  function init() {
    const theme = readTelegramTheme();
    apply(theme);

    // Telegram'dan tema o'zgarganida (foydalanuvchi setting'da almashtirsa)
    if (detectTelegram() && window.Telegram.WebApp.onEvent) {
      try {
        window.Telegram.WebApp.onEvent('themeChanged', () => {
          apply(readTelegramTheme());
        });
      } catch (e) {}
    }

    return theme;
  }

  window.Adminbot.Core.Theme = { init, apply, readTelegramTheme, getColorScheme };
})();
