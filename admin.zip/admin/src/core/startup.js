/**
 * startup.js — URL/deep-link parametrlarning yagona kirish nuqtasi.
 *
 * Xavfsizlik prinsipi:
 *   1. URL/hash/start_param FAQAT shu yerda o'qiladi
 *   2. Komponentlar va boshqa modullar Startup.params'dan foydalanadi
 *   3. Har parametr allowlist'dan o'tadi (turi va qiymati cheklangan)
 *   4. Noma'lum yoki noto'g'ri parametrlar jim e'tiborsiz qoldiriladi
 *   5. Boot tugagandan keyin xom URL tozalanadi (history.replaceState)
 *
 * Buni qilmasak — komponentlarda `location.search.match(...)` paydo bo'ladi
 * va deep-link orqali XSS yoki tenant aralashishi mumkin bo'ladi.
 *
 * Bu modul sukut bo'yicha xavfsiz qiymatlar bilan ishga tushadi —
 * keyinchalik Auth/Bootstrap real qiymatlarni overwrite qiladi.
 */
(function () {
  'use strict';

  // Allowlist qoidalari — har parametr uchun
  // dev_only: true bo'lsa, faqat dev buildda yoki localhost'da qabul qilinadi.
  const PARAM_RULES = {
    tenant_id: {
      validate: (v) => /^[A-Za-z0-9_\-]{1,64}$/.test(v),
      dev_only: false,
    },
    mock: {
      validate: (v) => v === 'true' || v === '1',
      dev_only: true,
      flag: true,
    },
    biz: {
      validate: (v) => [
        'shop', 'fastfood', 'restaurant', 'supplier',
        'appointment_service', 'custom_production', 'courier_service',
      ].includes(v),
      dev_only: true,
    },
    role: {
      validate: (v) => ['owner', 'manager', 'staff', 'courier'].includes(v),
      dev_only: true,
    },
    pin: {
      validate: (v) => v === 'on' || v === 'off',
      dev_only: true,
    },
    pin_locked: {
      validate: (v) => v === 'on' || v === 'off',
      dev_only: true,
    },
  };

  // start_param formatlari (Telegram WebApp.initDataUnsafe.start_param)
  // route:<key>  — boot tugagandan keyin shu route'ga o'tadi
  // event:<id>   — shu event'ni inbox'da fokusda ko'rsatadi
  // Faqat alphanumeric + dash + underscore qabul qilinadi
  const START_PARAM_PATTERNS = [
    { name: 'route',   re: /^route:([A-Za-z0-9_\-]{1,64})$/ },
    { name: 'event',   re: /^event:([A-Za-z0-9_\-]{1,128})$/ },
  ];

  // Hostname dev sifatida ko'riladimi?
  function isDevHost() {
    const h = (typeof location !== 'undefined' && location.hostname) || '';
    return (
      h === '' ||                  // file:// yoki jsdom default
      h === 'localhost' ||
      h === '127.0.0.1' ||
      h === '0.0.0.0' ||
      h === '::1' ||
      h.endsWith('.local') ||
      h.endsWith('.test')
    );
  }

  // Dev qiymatlar qabul qilinishi mumkinmi?
  // Production build (__ADMINBOT_PROD__) — har doim NO
  // Boshqa hollarda — faqat dev hostname'da
  function devParamsAllowed() {
    if (window.__ADMINBOT_PROD__ === true) return false;
    return isDevHost();
  }

  function parseQuery(searchStr) {
    const result = {};
    if (!searchStr) return result;
    const qs = searchStr.startsWith('?') ? searchStr.slice(1) : searchStr;
    if (!qs) return result;
    for (const pair of qs.split('&')) {
      if (!pair) continue;
      const eq = pair.indexOf('=');
      const rawKey = eq >= 0 ? pair.slice(0, eq) : pair;
      const rawVal = eq >= 0 ? pair.slice(eq + 1) : '';
      try {
        const key = decodeURIComponent(rawKey);
        const val = decodeURIComponent(rawVal);
        if (key && !(key in result)) result[key] = val;
      } catch (e) {
        // bad encoding — jim tashlanadi
      }
    }
    return result;
  }

  function buildParams() {
    const out = {};
    const raw = parseQuery((typeof location !== 'undefined' && location.search) || '');
    const allowDev = devParamsAllowed();

    for (const [key, rule] of Object.entries(PARAM_RULES)) {
      const v = raw[key];
      if (v == null) continue;
      if (rule.dev_only && !allowDev) {
        // Production yoki dev bo'lmagan host'da — jim tashlanadi
        continue;
      }
      if (!rule.validate(v)) continue;
      // Flag turidagi parametrlar boolean ga aylantiriladi
      if (rule.flag) {
        out[key] = (v === 'true' || v === '1');
      } else if (v === 'on' || v === 'off') {
        out[key] = (v === 'on');
      } else {
        out[key] = v;
      }
    }
    return out;
  }

  function parseStartParam() {
    try {
      const tg = window.Telegram && window.Telegram.WebApp;
      const raw = tg && tg.initDataUnsafe && tg.initDataUnsafe.start_param;
      if (!raw || typeof raw !== 'string') return null;
      // Maksimal uzunlik chegarasi
      if (raw.length > 200) return null;
      for (const pat of START_PARAM_PATTERNS) {
        const m = raw.match(pat.re);
        if (m) return { type: pat.name, value: m[1] };
      }
      // Plain alphanumeric — route deb hisoblaymiz
      if (/^[A-Za-z0-9_\-]{1,64}$/.test(raw)) {
        return { type: 'route', value: raw };
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  /**
   * URL'ni tozalash — xom paramlarni o'chirib, faqat path qoldirish.
   * Bu pastdagi xavfdan saqlanadi:
   *   - user refresh qilsa mock param qaytadan ishlamasligi
   *   - share qilingan URL'da boshqa tenant_id bo'lmasligi
   *   - browser history'da sensitive query'lar qolmasligi
   *
   * Eslatma: dev hostname'da URL'ni tozalamaymiz — debugging qulay bo'lsin.
   */
  function cleanUrl() {
    if (isDevHost()) return; // dev'da tozalamaymiz
    try {
      if (typeof history !== 'undefined' && history.replaceState) {
        const path = location.pathname || '/';
        history.replaceState(null, '', path);
      }
    } catch (e) {}
  }

  // === Public API ===
  const state = {
    initialized: false,
    params: {},           // tekshirilgan parametr'lar
    startHint: null,      // Telegram start_param dan keladigan hint
    isDev: false,         // dev rejim ekanligi
    buildMode: 'dev',     // 'dev' | 'prod'
  };

  function init() {
    if (state.initialized) return state;

    state.buildMode = (window.__ADMINBOT_BUILD__ === 'prod') ? 'prod' : 'dev';
    state.isDev = devParamsAllowed();
    state.params = buildParams();
    state.startHint = parseStartParam();
    state.initialized = true;

    // URL'ni production'da tozalash (boot tugagandan keyin auth.js
    // tenant_id'ni session'da saqlab qolgan bo'ladi)
    cleanUrl();

    return state;
  }

  function get(key) {
    return state.params[key];
  }

  /**
   * Mock mode'ga ruxsat bormi?
   *   - Production buildda: HECH QACHON
   *   - Dev buildda: faqat dev hostname'da VA ?mock=true bilan
   */
  function isMockAllowed() {
    if (window.__ADMINBOT_PROD__ === true) return false;
    if (!isDevHost()) return false;
    return state.params.mock === true;
  }

  window.Adminbot.Core.Startup = {
    init, get,
    isMockAllowed,
    isDevHost,
    get params() { return { ...state.params }; },
    get startHint() { return state.startHint; },
    get isDev() { return state.isDev; },
    get buildMode() { return state.buildMode; },
  };
})();
