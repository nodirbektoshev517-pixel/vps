/**
 * events.js — AdminEvents: lokal pub/sub + server hodisalari oqimi.
 *
 * ===========================================================================
 *  ENG MUHIM QOIDA: BU YERDA DOIMIY POLLING ISHLATILMAYDI.
 *  setInterval ham ishlatilmaydi.
 * ===========================================================================
 *
 *  3 qatlamli real aloqa modeli:
 *
 *  A) Mini App ochiq + active → WebSocket/SSE transport orqali server eventlar
 *  B) Mini App yopiq → backend Telegram bot orqali xabar yuboradi (frontend
 *     bilan aloqa yo'q; deep-link foydalanuvchini qaytaradi)
 *  C) App qayta ochilganda → syncSince(last_event_id) orqali missed eventlar
 *
 *  Bu modul:
 *   - lokal pub/sub (subscribe / emitLocal)
 *   - transport boshqaruvi (connect / disconnect / resume)
 *   - server hodisalari kelganda local subscriber'larga yetkazish
 *   - idempotency (bir xil event ID ikki marta kelsa ikkinchisini tashlaymiz)
 *   - cursor (last_event_id) — bu localStorage'da turadi (sensitive emas)
 *
 *  Mock transport avtomatik ravishda hodisa yaratmaydi. Test/dev uchun
 *  window.__mockPushEvent(event) chaqiriladi.
 */
(function () {
  'use strict';

  const { Constants } = window.Adminbot.Core;
  const LAST_EVENT_KEY = 'adminbot.last_event_id';
  const RECENT_IDS_MAX = 200;

  // === Local pub/sub ===
  const subs = new Map(); // event_type → Set<callback>

  function subscribe(type, fn) {
    if (!subs.has(type)) subs.set(type, new Set());
    subs.get(type).add(fn);
    return () => unsubscribe(type, fn);
  }

  // Eski API uchun alias'lar (boshqa core kod foydalanadi)
  const on = subscribe;
  function once(type, fn) {
    const wrap = (...args) => { unsubscribe(type, wrap); fn(...args); };
    return on(type, wrap);
  }

  function unsubscribe(type, fn) {
    const set = subs.get(type);
    if (set) set.delete(fn);
  }
  const off = unsubscribe;

  /**
   * Lokal hodisa — faqat ushbu app ichida. Server bilan aloqasi yo'q.
   * Misol: 'route.changed', 'api.session_expired', 'pin.locked'
   */
  function emitLocal(type, payload) {
    const set = subs.get(type);
    if (!set) return;
    for (const fn of Array.from(set)) {
      try { fn(payload); } catch (e) {
        console.error(`[Events] ${type} handler xatosi:`, e);
      }
    }
  }
  // Eski API uchun alias
  const emit = emitLocal;

  // === Transportlar ===
  /**
   * Har transport quyidagilarni ta'minlashi shart:
   *   - start(handlers): handlers = { onEvent, onOpen, onClose, onError }
   *   - stop(reason)
   *   - isConnected()
   */

  // Mock transport — hech narsa qilmaydi. Test fayli window.__mockPushEvent
  // orqali qo'lda event yuboradi.
  function MockEventTransport() {
    let connected = false;
    let _onEvent = null;
    return {
      start(handlers) {
        connected = true;
        _onEvent = handlers && handlers.onEvent;
        if (handlers && handlers.onOpen) handlers.onOpen();

        // __mockPushEvent — test/dev uchun global helper
        window.__mockPushEvent = function (event) {
          if (!connected || !_onEvent) return false;
          if (!event || !event.id || !event.type) {
            console.warn('__mockPushEvent: id va type talab qilinadi');
            return false;
          }
          _onEvent(event);
          return true;
        };
      },
      stop(_reason) {
        connected = false;
        _onEvent = null;
        try { delete window.__mockPushEvent; } catch (e) { window.__mockPushEvent = undefined; }
      },
      isConnected() { return connected; },
    };
  }

  // WebSocket transport — Bosqich 2/3 da to'liq amalga oshiriladi
  function WebSocketEventTransport(_url) {
    // Bosqich 1'da skeleton qoldiriladi.
    // Real implementatsiya: new WebSocket(_url), ws.onmessage → handlers.onEvent
    let ws = null;
    let connected = false;
    return {
      start(handlers) {
        if (!_url) {
          console.warn('[WS] URL berilmagan, ulanish o\'tkazib yuborildi');
          return;
        }
        try {
          ws = new WebSocket(_url);
          ws.onopen = () => { connected = true; handlers && handlers.onOpen && handlers.onOpen(); };
          ws.onclose = () => { connected = false; handlers && handlers.onClose && handlers.onClose(); };
          ws.onerror = (e) => { handlers && handlers.onError && handlers.onError(e); };
          ws.onmessage = (msg) => {
            try {
              const data = JSON.parse(msg.data);
              handlers && handlers.onEvent && handlers.onEvent(data);
            } catch (e) {}
          };
        } catch (e) {
          handlers && handlers.onError && handlers.onError(e);
        }
      },
      stop(_reason) {
        if (ws) { try { ws.close(); } catch (e) {} ws = null; }
        connected = false;
      },
      isConnected() { return connected; },
    };
  }

  // SSE transport — Bosqich 2/3 da
  function SSEEventTransport(_url) {
    let es = null;
    let connected = false;
    return {
      start(handlers) {
        if (!_url) return;
        try {
          es = new EventSource(_url);
          es.onopen = () => { connected = true; handlers && handlers.onOpen && handlers.onOpen(); };
          es.onerror = (e) => { handlers && handlers.onError && handlers.onError(e); };
          es.onmessage = (msg) => {
            try {
              const data = JSON.parse(msg.data);
              handlers && handlers.onEvent && handlers.onEvent(data);
            } catch (e) {}
          };
        } catch (e) {
          handlers && handlers.onError && handlers.onError(e);
        }
      },
      stop(_reason) {
        if (es) { try { es.close(); } catch (e) {} es = null; }
        connected = false;
      },
      isConnected() { return connected; },
    };
  }

  // === Connection state ===
  let transport = null;
  let recentIds = [];        // oxirgi ko'rilgan ID'lar — idempotency
  let connected = false;

  function getLastEventId() {
    try { return localStorage.getItem(LAST_EVENT_KEY) || null; } catch (e) { return null; }
  }
  function setLastEventId(id) {
    try { localStorage.setItem(LAST_EVENT_KEY, String(id)); } catch (e) {}
  }

  function trackId(id) {
    if (!id) return false;
    if (recentIds.includes(id)) return false; // duplicate
    recentIds.push(id);
    if (recentIds.length > RECENT_IDS_MAX) {
      recentIds = recentIds.slice(-RECENT_IDS_MAX);
    }
    return true;
  }

  function chooseTransport() {
    const { Utils } = window.Adminbot.Core;
    if (Utils.isMockMode()) return MockEventTransport();
    // Real mode'da WebSocket afzal, lekin URL backend orqali bootstrap'dan keladi
    // (Bosqich 1'da Mock qoldiramiz)
    return MockEventTransport();
  }

  /**
   * Server bilan aloqa o'rnatish. Bu yerda HECH QANDAY polling yo'q —
   * transport (WS/SSE) o'zi push qiladi yoki mock qo'lda push qilinadi.
   */
  function connect() {
    if (connected) return;
    transport = chooseTransport();
    transport.start({
      onOpen: () => { connected = true; emitLocal('events.connected'); },
      onClose: () => { connected = false; emitLocal('events.disconnected'); },
      onError: (e) => { emitLocal('events.error', { error: e }); },
      onEvent: handleServerEvent,
    });
  }

  function disconnect(reason = 'manual') {
    if (transport) {
      try { transport.stop(reason); } catch (e) {}
      transport = null;
    }
    connected = false;
    emitLocal('events.disconnected', { reason });
  }

  /**
   * Reconnect — masalan focus qaytganida.
   */
  function resume() {
    if (!connected) connect();
  }

  /**
   * Missed events — service layer orqali. Bu polling EMAS — bu bir martalik
   * sinxronlashtirish (app boot yoki focus qaytishi).
   */
  async function syncSince(cursor) {
    const { Services } = window.Adminbot.Core;
    const useCursor = cursor || getLastEventId();
    let resp;
    try {
      resp = await Services.events.syncSince(useCursor);
    } catch (e) {
      emitLocal('events.sync_failed', { error: e });
      return { events: [], failed: true };
    }
    const list = (resp && resp.events) || [];
    for (const ev of list) {
      handleServerEvent(ev);
    }
    return { events: list, failed: false };
  }

  /**
   * Server event keldi. Idempotency tekshir, lokal subscriber'larga yetkaz.
   */
  function handleServerEvent(event) {
    if (!event || !event.type) return;
    if (event.id && !trackId(event.id)) {
      // Duplikat — tashlanadi
      return;
    }
    if (event.id) setLastEventId(event.id);
    emitLocal('server.event', event);
    emitLocal(event.type, event);
  }

  /**
   * Eventni ack qilish (qabul qildim). Backend qaytadan yubormaslik uchun ishlatadi.
   */
  async function ack(eventId) {
    if (!eventId) return;
    const { Services } = window.Adminbot.Core;
    try { await Services.events.ack(eventId); } catch (e) {}
  }

  function isConnected() {
    return connected;
  }

  function clear(type) {
    if (type) subs.delete(type);
    else subs.clear();
  }

  /**
   * Visibility/focus — qaytib kelganda missed eventlarni sinxronlash.
   * Bu polling EMAS — har visibility change da bir martalik.
   */
  function init() {
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible' && connected) {
        // Soft resume — missed eventlar bo'lsa olib kelamiz
        // (cooldown — services.events.syncSince ko'p chaqirilmasin)
        syncSince(getLastEventId()).catch(() => {});
      }
    });
  }

  window.Adminbot.Core.Events = {
    // Connection
    connect, disconnect, resume, syncSince, ack,
    handleServerEvent, isConnected,

    // Pub/sub
    subscribe, unsubscribe,
    on, once, off, emit, emitLocal,
    clear,

    // Cursor
    getLastEventId, setLastEventId,

    // Transportlar (kelajak / testlar)
    transports: { MockEventTransport, WebSocketEventTransport, SSEEventTransport },

    init,
  };
})();
