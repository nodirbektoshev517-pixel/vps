#!/usr/bin/env python3
"""
SaaSBot Adminbot — Build skripti.

Bu skript src/ ostidagi barcha CSS va JS fayllarini birlashtirib,
yagona dist/index.html chiqaradi.

REJIMLAR:
  --mode=dev   (sukut) — mocks/ bundlga kiritiladi, __ADMINBOT_BUILD__ = "dev"
  --mode=prod  — mocks/ bundlga KIRITILMAYDI, __ADMINBOT_BUILD__ = "prod"

Production buildda:
  - mock fayllari mavjud emas (kod kichikroq + xavfsiz)
  - Utils.isMockMode() har doim false qaytaradi
  - Telegram initData yo'q bo'lsa auth muvaffaqiyatsiz bo'ladi

Yuklash tartibi:
  1. vendor/vue.global.prod.js (Vue 3)
  2. src/core/*.js (yadro)
  3. src/mocks/*.js (FAQAT dev rejimida)
  4. src/components/**/*.js (komponent bank)
  5. src/business/**/*.js (adapterlar + registry)
  6. src/app.js (boot)
"""

import argparse
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
VENDOR = ROOT / "vendor"
DIST = ROOT / "dist"
TEMPLATE = ROOT / "index.template.html"


# Yadro fayllarining majburiy tartibi (bog'liqliklarga ko'ra)
CORE_ORDER = [
    "namespace.js",      # window.Adminbot ochiladi (eng birinchi)
    "constants.js",      # API_BASE, TOKEN_KEY, h.k.
    "utils.js",          # umumiy helperlar
    "startup.js",        # URL params — allowlist (xavfsizlik)
    "i18n.js",           # term swap helper
    "theme.js",          # Telegram tema → CSS o'zgaruvchilarga
    "cache.js",          # AdminCache (TTL + cooldown)
    "labels.js",         # status/role label va badge mapping (yagona manba)
    "events.js",         # Pub/sub + transport — POLLING YO'Q
    "api.js",            # fetch wrapper (mock/real toggle)
    "services.js",       # service layer
    "auth.js",           # Telegram initData → JWT
    "permissions.js",    # can(), canRoute(), require() — UX filter
    "actions.js",        # runAction() wrapper
    "pin.js",            # backend-verified PIN
    "router.js",         # hash-based router
    "ui.js",             # toast, modal, sheet helpers
    "composables.js",    # Vue composable'lar (useEvents, ...)
]


def read_file(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def collect_css() -> str:
    out = []
    styles_dir = SRC / "styles"
    if not styles_dir.exists():
        return ""
    for f in sorted(styles_dir.glob("*.css")):
        out.append(f"/* === {f.name} === */\n{read_file(f)}\n")
    return "\n".join(out)


def collect_core_js() -> str:
    out = []
    core_dir = SRC / "core"
    seen = set()

    # Birinchi — buyurtmadagi fayllar
    for name in CORE_ORDER:
        p = core_dir / name
        if p.exists():
            out.append(f"/* === core/{name} === */\n{read_file(p)}\n")
            seen.add(name)

    # Qolgan fayllar (alfavit tartibida)
    for f in sorted(core_dir.glob("*.js")):
        if f.name not in seen:
            out.append(f"/* === core/{f.name} === */\n{read_file(f)}\n")

    return "\n".join(out)


def collect_components_js() -> str:
    out = []
    comp_dir = SRC / "components"
    if not comp_dir.exists():
        return ""
    for f in sorted(comp_dir.rglob("*.js")):
        rel = f.relative_to(SRC)
        out.append(f"/* === {rel} === */\n{read_file(f)}\n")
    return "\n".join(out)


def collect_business_js() -> str:
    out = []
    biz_dir = SRC / "business"
    if not biz_dir.exists():
        return ""
    adapters = sorted(p for p in biz_dir.rglob("*.js") if p.name != "registry.js")
    for f in adapters:
        rel = f.relative_to(SRC)
        out.append(f"/* === {rel} === */\n{read_file(f)}\n")
    registry = biz_dir / "registry.js"
    if registry.exists():
        out.append(f"/* === business/registry.js === */\n{read_file(registry)}\n")
    return "\n".join(out)


def collect_mocks_js() -> str:
    """src/mocks/ ichidagi mock data fayllar. FAQAT dev buildda chaqiriladi."""
    out = []
    mocks_dir = SRC / "mocks"
    if not mocks_dir.exists():
        return ""
    for f in sorted(mocks_dir.glob("*.js")):
        out.append(f"/* === mocks/{f.name} === */\n{read_file(f)}\n")
    return "\n".join(out)


def collect_app_js() -> str:
    p = SRC / "app.js"
    if p.exists():
        return f"/* === app.js === */\n{read_file(p)}\n"
    return ""


def collect_vendor_js() -> str:
    out = []
    if not VENDOR.exists():
        return ""
    for f in sorted(VENDOR.glob("*.js")):
        out.append(f"/* === vendor/{f.name} === */\n{read_file(f)}\n")
    return "\n".join(out)


def build(mode: str):
    if mode not in ("dev", "prod"):
        print(f"XATO: noma'lum rejim: {mode}. dev | prod", file=sys.stderr)
        sys.exit(2)

    if not TEMPLATE.exists():
        print(f"XATO: shablon topilmadi: {TEMPLATE}", file=sys.stderr)
        sys.exit(1)

    template = read_file(TEMPLATE)

    css = collect_css()
    vendor_js = collect_vendor_js()
    core_js = collect_core_js()
    components_js = collect_components_js()
    business_js = collect_business_js()
    app_js = collect_app_js()

    # Mocks faqat dev rejimida — production'da umuman bundle'ga kirmaydi
    mocks_js = collect_mocks_js() if mode == "dev" else ""

    # Boot rejim belgisi — eng yuqori darajada, har narsadan oldin
    build_flag_js = (
        f"/* === build flag === */\n"
        f'window.__ADMINBOT_BUILD__ = "{mode}";\n'
    )

    # Production buildda mock mavjud emasligini yana bir bor tasdiqlash
    if mode == "prod":
        build_flag_js += 'window.__ADMINBOT_PROD__ = true;\n'

    # JS tartib: build_flag → vendor → core → mocks (faqat dev) → components → business → app
    full_js = "\n".join([
        build_flag_js,
        vendor_js,
        core_js,
        mocks_js,
        components_js,
        business_js,
        app_js,
    ])

    html = template.replace("/* __CSS__ */", css)
    html = html.replace("/* __JS__ */", full_js)

    DIST.mkdir(parents=True, exist_ok=True)
    out_path = DIST / "index.html"
    out_path.write_text(html, encoding="utf-8")

    size_kb = len(html.encode("utf-8")) / 1024
    print(f"OK  dist/index.html yozildi  ({size_kb:.1f} KB) [rejim: {mode}]")
    print(f"    CSS:        {len(css.splitlines()):>5} qator")
    print(f"    Vendor JS:  {len(vendor_js.splitlines()):>5} qator (Vue 3)")
    print(f"    Core JS:    {len(core_js.splitlines()):>5} qator")
    if mode == "dev":
        print(f"    Mocks JS:   {len(mocks_js.splitlines()):>5} qator (dev)")
    else:
        print(f"    Mocks JS:       — (prod: chiqarib tashlandi)")
    print(f"    Component:  {len(components_js.splitlines()):>5} qator")
    print(f"    Business:   {len(business_js.splitlines()):>5} qator")
    print(f"    App boot:   {len(app_js.splitlines()):>5} qator")


def parse_args():
    parser = argparse.ArgumentParser(description="Adminbot build")
    parser.add_argument(
        "--mode", choices=["dev", "prod"], default="dev",
        help="dev: mocks bundle'ga kiritiladi (sukut). prod: mocks chiqarib tashlanadi.",
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    build(args.mode)
