# Bosqich 2.1 — Inbox bloki

> Birinchi haqiqiy operativ bloki. Bosqich 1 yadrosi va 1.5 design tizimi
> bilan qurilgan. Bosqich 1.6 helperlari namuna sifatida ishlatilgan.

---

## Bajarilgan ish

### 1. Mock backend

**`src/mocks/inbox.js`** — 32 ta tasodifiy buyurtma, cursor-based pagination,
status transition qoidalari, event push integratsiyasi.

```
GET    /adminbot/{tenant}/inbox?status={s}&cursor={c}&page_size={n}
PATCH  /adminbot/{tenant}/items/{id}/status   { status: '...' }
```

**Status transition jadvali** (mock backend tomonidan majburiy):
| Joriy | Keyingi (allowed) |
|---|---|
| new | accepted, cancelled |
| accepted | preparing, cancelled |
| preparing | ready, cancelled |
| ready | on_delivery, delivered, cancelled |
| on_delivery | delivered, cancelled |
| delivered, cancelled | (yo'q — terminal) |

Noto'g'ri transition → **409 Conflict**. Bu xavfsizlik chegarasi: backend
status mantiqini majburiy qiladi, frontend faqat tugmalarni ko'rsatadi.

**Dev console helper:**
```js
window.__mockNewOrder()   // yangi tasodifiy "new" buyurtma + event push
```

### 2. Komponentlar

| Komponent | Fayl | Vazifasi |
|---|---|---|
| `OrderStatusBadge` | `operational/OrderStatusBadge.js` | `Labels.formatStatus(status, 'order', terms)` orqali badge |
| `OrderCard` | `operational/OrderCard.js` | Universal kartochka: yuqori (raqam+status), o'rta (extensions), pastki (vaqt+summa+action) |
| `InboxList` | `operational/InboxList.js` | Universal ro'yxat: filter chip'lar + pagination + real-time push |
| `AddressBlock` | `extensions/AddressBlock.js` | Yetkazib berish manzili (extension) |
| `PaymentBlock` | `extensions/PaymentBlock.js` | To'lov usuli (extension) |
| `NoteBlock` | `extensions/NoteBlock.js` | Mijoz izohi (extension) |

### 3. Adapter konfiguratsiyasi

`shop/adapter.js`'da yangi `InboxList` va `OrderCard` config:

```js
InboxList: {
  item_card: 'OrderCard',
  statuses: ['new', 'accepted', 'preparing', 'ready', 'on_delivery', 'delivered', 'cancelled'],
  default_status: 'new',
  page_size: 20,
  terms: { item: 'Buyurtma', items: 'Buyurtmalar' },
},

OrderCard: {
  extensions: ['delivery_address', 'payment_method', 'note'],
  primary_actions: {
    new:         ['accepted'],
    accepted:    ['preparing'],
    preparing:   ['ready'],
    ready:       ['on_delivery'],
    on_delivery: ['delivered'],
  },
},
```

Hech qanday function. Adapter purity testi (Bosqich 1) hali yashil.

---

## Variant 2: Extension renderer arxitekturasi

Adapter `extensions: ['delivery_address', 'payment_method', 'note']` deb deklare
qiladi. `OrderCard` ichida `EXTENSION_MAP` (nom → komponent) va Vue'ning
`<component :is>` orqali yuklanadi:

```js
const EXTENSION_MAP = {
  delivery_address: 'AddressBlock',
  payment_method:   'PaymentBlock',
  note:             'NoteBlock',
};
```

Bosqich 2.4 (Supplier) va Bosqich 3 (Restaurant, Courier)'da yangi extension'lar
qo'shilganda — har biri uchun kichik komponent yoziladi va `EXTENSION_MAP`'ga
qo'shiladi. Adapter o'z ro'yxatini deklare qiladi.

**Misol kelajak:**
```js
// supplier adapter
OrderCard: {
  extensions: ['credit_terms', 'shipment_method', 'reference'],
}

// EXTENSION_MAP kengaytirish (OrderCard.js'da):
credit_terms:    'CreditTermsBlock',
shipment_method: 'ShipmentMethodBlock',
reference:       'ReferenceBlock',
```

Adapter purity buzilmaydi — string nom + alohida komponent.

---

## Real-time aloqa amaliyotda

Bosqich 1 arxitekturasi (event-driven, polling yo'q) endi konkret namuna bilan:

| Event | Manba | InboxList javobi |
|---|---|---|
| `order.created` | mock'da `__mockNewOrder()` yoki backend push | `seenIds`'da yo'q bo'lsa — ro'yxat boshiga **prepend** |
| `order.status_changed` | `Services.inbox.updateStatus()` yoki backend push | Mavjud item topib **yangilash**, agar filter bilan mos kelmasa — **ro'yxatdan olib tashlash** |

**Idempotency:**
```js
const seenIds = new Set();
function onOrderCreated(event) {
  if (seenIds.has(order.id)) return;     // duplikat tashlanadi
  seenIds.add(order.id);
  items.value = [order, ...items.value];
}
```

Test `Idempotency — duplikat event qo'shilmaydi` shu mantiqini tasdiqlaydi.

---

## Performance qoidalari (§7 amaliyotda)

| Qoida | Qanday qo'llanildi |
|---|---|
| Birinchi yuklash ≤20 item | `page_size: 20` adapter'da, backend mock cheklaydi |
| Cursor pagination | `Services.inbox.list({ cursor, page_size })` |
| Template'da og'ir filter/sort YO'Q | Static test bilan tasdiqlanadi: regex `{{[^}]*\.filter(\|\.sort(\|\.reduce(}}` |
| Deep watch YO'Q | Faqat `currentStatus` ref'i watch qilinadi |
| `computed` filter | `extensions`, `primaryActions`, `total`, `timeAgo` — barchasi computed |

---

## Bosqich 1.6 helperlar amaliyotda

| Helper | Qaerda ishlatilgan |
|---|---|
| `Services.inbox.list/updateStatus` | InboxList yuklash + OrderCard action |
| `Labels.formatStatus(key, kind, terms)` | OrderStatusBadge va OrderCard.primaryActions |
| `Actions.runAction({...})` | OrderCard.advance() — try/catch yo'q |
| `Composables.useEvents()` | InboxList event subscription + cleanup |
| `Utils.formatMoney/relativeTime` | OrderCard pastki qator |
| `Permissions.can('orders.update')` | runAction ichida tekshiriladi |
| `Cache.invalidate('inbox:')` | Filter o'zgartirilganda |

**Komponent murakkabligi:** InboxList ~250 qator, OrderCard ~110 qator,
extension'lar ~25 qator har biri. Hech qanday boilerplate try/catch yoki manual
listener cleanup.

---

## Test natijasi

### Bosqich 1: **152/152 PASS** (regress yo'q)
### Bosqich 2.1: **47/47 PASS**
### **Jami: 199/199 PASS**

Bosqich 2.1 test kategoriyalari:
- Services.inbox pagination (8) — page_size, cursor, has_more, status filter, duplikatsizlik
- Status update mock (3) — valid transition, 409 invalid transition
- OrderStatusBadge (3) — Labels orqali label/badge
- InboxList render (8) — filter chip'lar, OrderCard'lar, ≤20 item
- OrderCard ichi (4) — status badge, AddressBlock, PaymentBlock extensionlar
- Filter o'zgartirish (4) — chip click, active class, filter natijasi
- Real-time push (4) — order.created prepend, birinchi pozitsiya
- Idempotency (2) — duplikat event tashlanadi
- order.status_changed (1) — mavjud item yangilanadi
- Status advance via runAction (2) — tugma, filter'dan chiqishi
- Adapter terms override (2) — `delivered` → `Yetib bordi`
- useEvents cleanup (1) — route o'zgartirish duplikat listener yaratmaydi
- Pagination "Yana yuklash" (4) — ikkinchi sahifa, duplikatsiz
- Static performance (1) — template ichida og'ir operatsiya yo'q

---

## Bosqich 2.2 ga qoldirilgan ishlar

- **Katalog**: `CategoryCRUD`, `ProductCRUD`, `ImageUploader`
- **Yangi adapter**: `fastfood` (dine-in/delivery filter, kitchen flow)
- **Yangi adapter**: `supplier` (credit_terms, shipment_method extensionlari)
- **Audit log**: `EventsLog`, broadcast preview/confirm
- **Customer**: `CustomerList`, `CustomerProfile`
- **Hisobot**: `ReportsView`
- **StaffManager**: to'liq CRUD (modal form)

---

## Yangi qo'shilgan yo'riqnoma

`OrderCard`/InboxList shabloniga ergashayotgan har bir komponent quyidagicha bo'lishi shart:

1. **Service layer orqali** — `Services.<resource>.<action>()`
2. **runAction wrapper** — hech qanday manual try/catch
3. **Labels jadvali** — switch/if YO'Q
4. **useEvents** — manual `onUnmounted` YO'Q
5. **Pagination ≤20** birinchi yuklashda
6. **Filter — server-side** (cursor reset)
7. **Real-time push** event handler'lar **idempotent**
8. **Adapter declarativ** — function YO'Q, faqat string nom + config
9. **Extension Variant 2** — har qo'shimcha blok alohida kichik komponent

Bu qoidalar **199 ta test** orqali tekshiriladi. Buzilsa build FAIL bo'ladi.
