# Bosqich 2 — Operativ bloklar (to'liq)

> Bosqich 1 yadrosi + 1.5 design + 1.6 helperlar ustiga 17 ta yangi komponent.
> 4 ta kichik bosqich (2.1 - 2.5) bir hujjatda jamlandi.

---

## Yetkazib berilgan komponentlar

### Bosqich 2.1 — Inbox bloki (avval batafsil hujjatlangan)

| Komponent | Vazifa |
|---|---|
| `OrderStatusBadge` | Labels orqali status rangi + label |
| `OrderCard` | Universal kartochka, extension renderer, advance tugma |
| `InboxList` | Filter chip + cursor pagination + real-time push |
| `AddressBlock`, `PaymentBlock`, `NoteBlock` | OrderCard extension'lari |

### Bosqich 2.2 — Katalog

| Komponent | Vazifa |
|---|---|
| `ImageUploader` | MIME (jpeg/png/webp), max 3 MB, FileReader preview, async upload |
| `CategoryCRUD` | Ro'yxat + CRUD (sheet form). Tap = ProductCRUD subview |
| `ProductCRUD` | Per-kategoriya, pagination, CRUD, variants/addons extensions |
| `VariantsBlock`, `AddonsBlock` | Mahsulot extension'lari (v-model bilan) |

### Bosqich 2.3 — Mijozlar va hisobot

| Komponent | Vazifa |
|---|---|
| `CustomerList` | Debounced search + pagination + profile navigatsiyasi |
| `CustomerProfile` | Bitta mijoz + orders_history extension |
| `OrdersHistoryBlock` | Mijoz buyurtmalari tarixi (extension) |
| `ReportsView` | Adapter deklare qilgan hisobotlarni render qiladi |

### Bosqich 2.4 — Boshqaruv

| Komponent | Vazifa |
|---|---|
| `NotificationsBroadcast` | Yozish → preview confirm → send. Permission `broadcast.send` |
| `EventsLog` | Audit log ro'yxati (immutable), type filter, pagination |
| `StaffManager` (kengaytirildi) | To'liq CRUD: qo'shish, tahrirlash, o'chirish, rol o'zgartirish |

### Bosqich 2.5 — Supplier maxsus komponentlari

| Komponent | Vazifa |
|---|---|
| `BalanceOperation` | Immutable audit yozuvi (kichik kartochka) |
| `BalanceLedger` | Pagination + shop filter + operatsiya qo'shish |
| `TierAssigner` | bronze/silver/gold/platinum chip switcher per shop |
| `CreditLimitManager` | Har shop uchun kredit limit |
| `InviteCodeGenerator` | Yaratish, ko'rish, nusxalash, o'chirish |
| `ShopApprover` | Pending shops, approve/reject |

---

## Service layer kengaytirish

Yangi resurslar `Services` ostida ([core/services.js](src/core/services.js)):

```
Services.catalog.*       — listCategories, createCategory, updateCategory,
                           deleteCategory, listProducts, createProduct,
                           updateProduct, deleteProduct, uploadImage
Services.customers.*     — list({q, cursor, page_size}), get(id)
Services.reports.fetch   — har report key uchun
Services.broadcast.send  — message + audience
Services.audit.list      — type filter + pagination
Services.supplier.*      — listShops, setTier, setCreditLimit, listBalance,
                           addBalanceOperation, listInvites, createInvite,
                           deleteInvite, listPendingShops, approveShop, rejectShop
```

Hech bir komponent endpoint URL'larni bilmaydi.

---

## Yangi adapter konfiguratsiyasi (shop)

```js
component_configs: {
  CategoryCRUD: { terms: { catalog: 'Katalog' } },
  ProductCRUD:  { extensions: ['variants', 'addons'] },
  CustomerList: { terms: { customers: 'Mijozlar' } },
  CustomerProfile: { extensions: ['orders_history'] },
  ReportsView:  { reports: ['daily_sales', 'top_products', 'customer_summary'] },
}

routes: [
  // BottomNav (5 ta)
  { key: 'dashboard',  ... },
  { key: 'orders',     ... },
  { key: 'catalog',    ... },
  { key: 'customers',  ... },
  { key: 'settings',   ... },
  // Secondary (settings ichida "Boshqa bo'limlar"):
  { key: 'reports',   secondary: true },
  { key: 'broadcast', secondary: true },
  { key: 'staff',     secondary: true },
  { key: 'audit',     secondary: true },
]
```

`secondary: true` flag:
- `BottomNav` bu route'larni ko'rsatmaydi (5 ta tab cheklovi)
- `SettingsView` "Boshqa bo'limlar" sektsiyasida ro'yxat sifatida ko'rsatadi
- Permission filter har joyda qo'llaniladi

---

## Variant 2 extension paterni — namuna

Adapter `extensions: [...]` deklare qiladi, komponent `EXTENSION_MAP` (nom → komponent) bilan `<component :is>` orqali yuklaydi.

```js
// ProductCRUD.js
const EXTENSION_MAP = {
  variants: 'VariantsBlock',
  addons:   'AddonsBlock',
};

// CustomerProfile.js
const EXTENSION_MAP = {
  orders_history: 'OrdersHistoryBlock',
};

// OrderCard.js (Bosqich 2.1)
const EXTENSION_MAP = {
  delivery_address: 'AddressBlock',
  payment_method:   'PaymentBlock',
  note:             'NoteBlock',
};
```

Adapter purity buzilmaydi — function yo'q, faqat string.

---

## Auditga oid asosiy qarorlar

| Qaror | Sabab |
|---|---|
| Broadcast → audit log avtomatik | Operatorlar javobgar bo'lishi uchun |
| Audit immutable | Frontend faqat o'qiydi. POST/PATCH/DELETE yo'q |
| Balans operatsiyalari immutable | Eskini o'zgartirmaydi — yangi yozuv qo'shadi. `before_balance` va `after_balance` har yozuvda |
| Audit type filter | Operatorlar tezkor qidirishi uchun |
| `actor_id`/`actor_name` har audit yozuvida | Kim bajardi — aniq |

---

## Xavfsizlik (Bosqich 1.6 helperlar amaliyotda)

| Helper | Qaerda |
|---|---|
| `Permissions.require(key, label)` | Har CRUD action boshida |
| `Actions.runAction({permission, confirm, action, onSuccess})` | Har save/delete/approve |
| `Composables.useEvents()` | StaffManager `staff.changed` event auto-cleanup |
| `Utils.errorText(e)` | Barcha mock 422/409/404 xato matnini chiqarish |
| `UI.confirm({...})` | Destructive action'lar (broadcast send, delete, tier change) |
| Backend 401/403/423 | LockScreen orqali ushlanadi (komponentlar bilmaydi) |

`ImageUploader` validatsiya:
- MIME whitelist (`image/jpeg`, `image/png`, `image/webp`)
- Hajm cheklovi (3 MB)
- FileReader → data URL → backend uploadImage()
- Frontend chegara — backend ham qayta tekshiradi va re-encode qiladi

---

## Test natijasi

```
test_bosqich_1.js        → 152 PASS / 0 FAIL  (Bosqich 1, 1.5, 1.6)
test_bosqich_2_1.js      →  47 PASS / 0 FAIL  (Inbox bloki)
test_bosqich_2_rest.js   →  95 PASS / 0 FAIL  (2.2 - 2.5)
──────────────────────────────────────────────
JAMI:                       294 PASS / 0 FAIL
```

`test_bosqich_2_rest.js` kategoriyalari:

**2.2 Katalog (~22):** kategoriyalar CRUD, 409 (mahsulotli kategoriya o'chirilmaydi), mahsulotlar CRUD, 422 (name majburiy), ImageUploader (data_url 422), CategoryCRUD/ProductCRUD render, subview navigatsiyasi, extensions formada render.

**2.3 Mijozlar/Hisobot (~14):** customers.list pagination, search, get orders_history, CustomerList/Profile render, reports.fetch (daily_sales, top_products), 404 mavjud bo'lmagan, ReportsView 3 ta hisobot render.

**2.4 Boshqaruv (~13):** broadcast validation (422 qisqa), audit avtomatik yozish, audit pagination + filter, EventsLog render + filter chip, NotificationsBroadcast disabled state, StaffManager forma maydonlari.

**2.5 Supplier (~28):** shops/balance ro'yxat, before/after audit, addBalanceOperation, setTier (valid/invalid 422), setCreditLimit (valid/manfiy 422), invites CRUD, pending shops approve/reject, 6 ta komponent global registr.

**Static (~6):** setInterval YO'Q, to'g'ridan-to'g'ri fetch() YO'Q, location.search/hash YO'Q, v-html YO'Q, adapter purity (function yo'q).

---

## Loyiha statistikasi

| Metr | Bosqich 1 | Bosqich 2 oxiri |
|---|---:|---:|
| Komponentlar | 8 | 31 |
| Mock fayllar | 5 | 10 |
| Service resurslar | 6 | 12 |
| Adapter routes | 5 | 9 (5 + 4 secondary) |
| Test soni | 152 | 294 |
| dist/index.html (dev) | ~330 KB | ~435 KB |
| dist/index.html (prod) | ~320 KB | ~415 KB |

---

## Bosqich 3 ga qoldirilgan ish

Adapter'lar yozish uchun **barcha universal komponentlar tayyor**. Bosqich 3 — 4 ta biznes turi uchun maxsus komponentlar:

- **3.A Restaurant**: `TableMap`, `ReservationCard`, `BanquetManager`, `HallStatusBoard` (eslatma: alohida `ReservationsList` YO'Q — `InboxList` + `ReservationCard` ishlatiladi)
- **3.B Appointment**: `CalendarView`, `ServiceCRUD`, `SpecialistCRUD`, `AppointmentCard`, `WalkInQueue`
- **3.C Production**: `TechBriefViewer`, `OnSiteDispatch`, `StageAdvancer`, `PriceProposalSender`
- **3.D Courier**: `CourierList`, `CourierAssigner`, `LiveTracker` (push-based, no polling), `RouteMap`, `DeliveryStatusBoard`

Bosqich 4 — 7 ta adapter (shop kengaytirish, fastfood, supplier, restaurant, appointment, production, courier) + `WebSocketEventTransport` to'liq amalga oshiriladi.
