# Design tizimi

> Bu hujjat Bosqich 1.5'da o'rnatildi. Bosqich 2'dan boshlab har bir yangi komponent shu qoidalarga rioya qilishi shart.

---

## Asosiy printsiplar

1. **Yagona manba** — barcha rang, bo'shliq, shrift, radius CSS o'zgaruvchilar (`tokens`) orqali keladi.
2. **Komponentlar qattiq qiymat yozmaydi** — hech qachon `padding: 16px`, `color: #ff5555`. Faqat `padding: var(--space-4)`, `color: var(--color-danger)`.
3. **Primitive birinchi** — yangi komponent yozishdan oldin mavjud primitivlar (`.btn`, `.card`, `.list`, `.stack`, `.cluster`) bilan tugatishga harakat qiling.
4. **Domen-maxsus klassni minimal qiling** — agar primitive yetmasa, yangi klass komponent ichida emas, `03_primitives.css` da hammasi uchun yoziladi.
5. **`data-*` selektorlar testlar uchun** — CSS klasslarni testda ishlatmang. Element identifikatsiyasi uchun `data-component`, `data-route`, `data-action`, `data-stat` kabi atributlar ishlatiladi.

---

## Fayl tuzilishi

```
src/styles/
├── 01_tokens.css      CSS o'zgaruvchilar (yagona manba)
├── 02_base.css        Reset, html/body, element default'lari
├── 03_primitives.css  Qayta ishlatiladigan UI bloklari (.btn, .card, ...)
├── 04_layouts.css     Layout primitivlari va utility'lar (.page, .stack, .cluster)
└── 05_screens.css     Domen-maxsus layout'lar (.app-shell, .bottom-nav, .auth-screen, .pin-screen)
```

Yuklash tartibi `build.py` tomonidan alfavit bo'yicha avtomatik (raqamli prefiks).

---

## 1. Tokenlar (`01_tokens.css`)

### Ranglar

| Token | Maqsadi |
|---|---|
| `--color-bg` | Sahifa orqa fon |
| `--color-surface` | Stat'lar, ro'yxat tubidagi yuza |
| `--color-surface-2` | Kartochka, list bg (asosiy yuza ustida) |
| `--color-surface-3` | Active/hover holatlari uchun (yuza+) |
| `--color-text` | Asosiy matn |
| `--color-text-muted` | Yordamchi matn |
| `--color-text-inverse` | Solid tugma ichidagi matn |
| `--color-border` | Hech qaysi `border-color` qattiq yozilmaydi — shu ishlatiladi |
| `--color-divider` | List'larda qator orasidagi chiziq |
| `--color-primary` | Brend rang (Telegram tema'sidan) |
| `--color-primary-soft` | Brend rangning yumshoq fon varianti |
| `--color-success / -warning / -danger / -info` | Semantik solid |
| `--color-success-soft / -warning-soft / ...` | Semantik soft (badge fon) |

Telegram fon/matn ranglari `--tg-*` o'zgaruvchilaridan keladi. Telegram bo'lmasa fallback ishlatiladi.

### Bo'shliq (4px grid)
`--space-1` (4px) ... `--space-12` (48px), plus `--space-16` (64px).

### Shrift
`--text-xs` (11px) ... `--text-3xl` (28px). `--weight-normal/medium/semibold/bold`.

### Radius
`--radius-xs` (4px) ... `--radius-xl` (20px), plus `--radius-pill` (999px).

### Tap area
`--touch-sm` (36px), `--touch` (44px — sukut), `--touch-lg` (56px). WCAG va Telegram tavsiyasi.

### Soya, z-index, animatsiya
`--shadow-xs` ... `--shadow-xl`. `--z-bottom-nav: 100`, `--z-toast: 300`, `--z-dialog: 500`. `--transition-fast/base/slow`.

---

## 2. Primitivlar (`03_primitives.css`)

### `.heading`
```html
<h1 class="heading">Bosh sahifa</h1>
<h2 class="heading heading--md">Bo'lim sarlavhasi</h2>
<div class="heading heading--sm">UPPERCASE BO'LIM</div>
```

Variantlar: `--lg` (28px bold), default (24px bold), `--md` (20px semibold), `--sm` (13px semibold uppercase muted).

### `.btn`
Asosiy tugma — barcha boshqa tugma `.btn` ga moslashishi shart.

```html
<button class="btn btn--primary">Saqlash</button>
<button class="btn btn--secondary">Bekor</button>
<button class="btn btn--ghost">Kichik</button>
<button class="btn btn--danger">O'chirish</button>
<button class="btn btn--ghost btn--icon btn--sm">↻</button>
<button class="btn btn--primary btn--block">Block button</button>
```

| Modifikator | Effekt |
|---|---|
| `--primary` | Brend rangli solid |
| `--secondary` | Yuza rangli (subtle) |
| `--ghost` | Transparent (icon tugmalar uchun) |
| `--danger` | Qizil solid |
| `--success` | Yashil solid |
| `--sm` | 36px h, kichik text |
| `--lg` | 56px h, katta text |
| `--icon` | Kvadrat (icon-only) |
| `--block` | `width: 100%` |

States: `:disabled` (avto), `[aria-busy="true"]` (loading).

### `.card`
```html
<div class="card">
  <div class="stat__label">Tushum</div>
  <div class="stat__value">4 250 000 so'm</div>
</div>
<div class="card card--interactive">Bosish mumkin</div>
```

### `.list` + `.list__row`
```html
<div class="list">
  <div class="list__row">
    <div class="list__icon">🔒</div>
    <div class="list__main">
      <div class="list__title">PIN-kod</div>
      <div class="list__subtitle">O'rnatilgan</div>
    </div>
    <div class="list__trail">5 daq</div>
  </div>
  <div class="list__row list__row--interactive">
    <div class="list__icon">🔐</div>
    <div class="list__main">
      <div class="list__title">Hozir qulflash</div>
    </div>
    <div class="list__chevron">›</div>
  </div>
</div>
```

### `.field` (forma)
```html
<div class="field">
  <label class="field__label">Telegram username</label>
  <input type="text">
</div>
<div class="field field--error">
  <label class="field__label">Phone</label>
  <input type="tel">
  <div class="field__error">Format noto'g'ri</div>
</div>
```

### `.badge` (status indikator)
```html
<span class="badge">DEFAULT</span>
<span class="badge badge--success">FAOL</span>
<span class="badge badge--warning">KUTILMOQDA</span>
<span class="badge badge--danger">RAD</span>
<span class="badge badge--owner">Egasi</span>
```

### `.chip` (tap'ladigan filter)
```html
<button class="chip">Hammasi</button>
<button class="chip chip--active">Yangi</button>
```

### `.avatar`
```html
<div class="avatar">AK</div>
<div class="avatar avatar--lg">DT</div>
<div class="avatar avatar--sm">M</div>
```

### `.dialog`
RootShell tomonidan boshqariladi — to'g'ridan-to'g'ri ishlatilmaydi. `UI.confirm({ title, body, confirmText, cancelText })` orqali chiqariladi.

### `.sheet` (bottom sheet — Bosqich 2'da ishlatamiz)
```html
<div class="sheet">
  <div class="sheet__handle"></div>
  <div class="sheet__header">
    <div class="sheet__title">Filtrlar</div>
  </div>
  <div class="sheet__body">...</div>
</div>
```

### `.toast`
RootShell tomonidan boshqariladi. `UI.toast('Saqlandi', { type: 'success' })` orqali chiqariladi.

### `.empty` (bo'sh holat)
```html
<div class="empty">
  <div class="empty__icon">📦</div>
  <div class="empty__title">Buyurtmalar yo'q</div>
  <div class="empty__hint">Birinchi buyurtma kelganda shu yerda ko'rinadi.</div>
</div>
```

### `.spinner` va `.skeleton`
```html
<div class="spinner"></div>
<div class="spinner spinner--sm"></div>
<div class="skeleton" style="height: 12px; width: 60%;"></div>
```

### `.stat__*` (Card ichidagi statistika)
```html
<div class="card">
  <div class="stat__label">Bugungi tushum</div>
  <div class="stat__value">4 250 000 so'm</div>
  <div class="stat__delta">+8% (1 hafta)</div>
  <div class="stat__delta stat__delta--down">-3% (1 hafta)</div>
</div>
```

---

## 3. Layout primitivlari (`04_layouts.css`)

### `.page`
Har route'ning eng tashqi konteyneri. Padding, max-width, bottom-nav uchun joy reservatsiyasi — hammasi ichida.

```html
<div class="page">
  ...sahifa mazmuni...
</div>
```

### `.stack` (vertikal)
```html
<div class="stack">
  <div>Item 1</div>
  <div>Item 2</div>
</div>
```

Variantlar: `--tight` (8px), `--snug` (12px), default (16px), `--loose` (24px), `--airy` (32px).

### `.cluster` (horizontal, wrap mumkin)
```html
<div class="cluster cluster--between">
  <h1 class="heading">Sarlavha</h1>
  <button class="btn btn--primary btn--sm">+ Qo'shish</button>
</div>
```

Variantlar: `--tight/snug/loose`, `--between`, `--center`, `--end`, `--start`, `--baseline`.

### `.row` (horizontal, no wrap)
Kichik element'lar uchun (avatar + matn). Stack farqi: gorizontal.

### `.grid`
```html
<div class="grid">2 ustun</div>
<div class="grid grid--3">3 ustun</div>
<div class="grid grid--auto">auto-fit (min 140px)</div>
```

### Utility'lar (kamtarona ro'yxat)
`text-muted`, `text-sm`, `text-bold`, `text-center`, `text-truncate`, `flex-1`, `w-full`, `h-full`, `hidden`, `mt-auto`, `ml-auto`.

**Diqqat:** utility ortiqcha ishlatmang. Agar takror-takror ishlatilsa, primitive yarating.

---

## 4. Domen-maxsus screens (`05_screens.css`)

Bu klasslar **bitta joyda ishlatiladi** va primitive emas:

- `.app-shell` + `.app-shell__main` — top-level
- `.bottom-nav` + `.bottom-nav__item` + `.bottom-nav__icon` — pastki nav
- `.auth-screen` + `.auth-screen__logo` + `.auth-screen__hint` + `.auth-screen__error` — boot ekran
- `.pin-screen` + `.pin-screen__icon` + `.pin-screen__title` + `.pin-screen__hint` — lock/PIN
- `.pin-keypad` + `.pin-key` + `.pin-key--clear` + `.pin-key--del` — keypad
- `.pin-dots` + `.pin-dot` (+ `.is-filled`, `.is-error`) — PIN nuqtalar
- `.overlay` — modal backdrop
- `.toast-stack` — toast konteyner

---

## 5. Yangi komponent yozish

### Algoritm:
1. **Layout** — `.page` ichida `.stack` yoki `.cluster`'larni birlashtir
2. **Sarlavha** — `.heading` yoki `.heading--sm`
3. **Tugma** — `.btn` + variants
4. **Element ro'yxati** — `.list` + `.list__row`
5. **Kartochka** — `.card` + ichida `.stack` yoki maxsus content
6. **Status** — `.badge` yoki `.chip`
7. **Bo'sh holat** — `.empty`
8. **Loading** — `.spinner` yoki `.skeleton`

### Misol — `OrderCard` (Bosqich 2'da yoziladi):
```html
<div class="card card--interactive" :data-order-id="order.id">
  <div class="cluster cluster--between">
    <div class="stack stack--tight">
      <div class="text-medium">#{{ order.number }}</div>
      <div class="text-muted text-sm">{{ order.customer_name }}</div>
    </div>
    <span class="badge" :class="'badge--' + order.status_color">{{ order.status_label }}</span>
  </div>
  <div class="cluster cluster--between" style="margin-top: var(--space-3)">
    <div class="text-bold">{{ formatMoney(order.total) }}</div>
    <div class="text-muted text-sm">{{ timeAgo(order.created_at) }}</div>
  </div>
</div>
```

E'tibor bering — bu komponent **hech qanday yangi CSS** talab qilmaydi.

### Inline `style` qachon ruxsat?
Faqat bir joyga xos joylashuv (masalan `margin-top: var(--space-3)`) — token ishlatish sharti bilan. Hech qachon hardcoded `16px` yoki `#ff5555` emas. Test inline `px`'larni hisoblaydi (cheklov: 15 tadan kam).

---

## 6. Tema (dark/light)

Telegram tema'siga avtomatik moslashadi:
- `--tg-bg-color`, `--tg-text-color`, `--tg-button-color` Telegram'dan keladi
- Tokens shu o'zgaruvchilardan default qiymat oladi
- `@media (prefers-color-scheme: dark)` qo'shimcha dark overrides (border, shadow)

Komponent darajada hech narsa qilish kerak emas — token'lar avtomatik moslashadi.

---

## 7. Statistika

Bosqich 1.5 dan keyin:

| Ko'rsatkich | Qiymat |
|---|---|
| CSS fayl soni | 5 (toza tasniflangan) |
| CSS qator | 1131 (token + 18 primitive + layout) |
| Mavjud primitiv'lar | 16 ta |
| `01_tokens.css` o'zgaruvchilar | 60+ |
| Dist hajmi | 286 KB |
| Testlar | 95/95 PASS |

Bosqich 2'da 20+ yangi komponent yoziladi. **Yangi CSS qo'shilishi taxminan 10-15% bo'lishi kutiladi** (faqat haqiqatan domen-maxsus joylar uchun).
