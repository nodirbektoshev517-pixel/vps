# BOSQICH 1 — Yadro va asosiy infrastruktura

> SaaSBot Adminbot — Telegram Mini App.
> Versiya: 0.1.0
> Sana: 2026-05-31

Bu hujjat Bosqich 1'da nima bajarilganini, qanday qaror qabul qilinganini va keyingi bosqichlarga qoldirilgan ishlarni qamrab oladi.

---

## 1. Bajarilgan ish

### Loyiha tuzilmasi va build

```
adminbot/
├── build.py                  # fayllarni dist/index.html ga konkatenatsiya
├── index.template.html       # placeholder'lar bilan shablon
├── vendor/
│   └── vue.global.prod.js    # Vue 3.5.13 (offline)
├── src/
│   ├── core/                 # 14 ta yadro fayli (~1825 qator)
│   ├── components/
│   │   └── infrastructure/   # 7 ta Bosqich 1 komponenti + RootShell
│   ├── business/
│   │   ├── shop/adapter.js   # reference adapter (sof deklarativ)
│   │   └── registry.js
│   ├── mocks/                # 5 ta mock fayl
│   ├── styles/               # 3 ta CSS fayl
│   └── app.js                # boot
├── dist/index.html           # build natijasi (274 KB)
└── tests/
    └── test_bosqich_1.js     # 73 ta integratsiya testi (hammasi PASS)
```

### Yadro (CORE) — 14 fayl

| Fayl | Maqsadi |
|---|---|
| `namespace.js` | `window.Adminbot` global namespace |
| `constants.js` | API_BASE, localStorage kalitlari, sukut qiymatlar |
| `utils.js` | yordamchilar: `getTenantId`, `formatMoney`, `debounce`, `sha256`, ... |
| `i18n.js` | term swap (`t(terms, 'customer', 'Mijoz')`) |
| `theme.js` | Telegram tema → CSS o'zgaruvchilar |
| `cache.js` | TTL + cooldown bilan klient cache |
| `events.js` | **event-driven** pub/sub + transport boshqaruvi |
| `api.js` | fetch wrapper (mock/real toggle) |
| `services.js` | service layer (endpoint abstraktsiyasi) |
| `auth.js` | Telegram initData → JWT (bootstrap authoritative) |
| `permissions.js` | `can()`, `canRoute()` — UX filter |
| `pin.js` | **backend-verified** PIN, setTimeout (polling EMAS) |
| `router.js` | hash-asoslangan router |
| `ui.js` | toast, modal, sheet helpers |

### Komponentlar (Bosqich 1)

| Komponent | Maqsadi |
|---|---|
| `RootShell` | top-level state machine (booting/locked/pin/app) |
| `AuthGate` | auth + bootstrap + adapter tanlash |
| `PinGate` | PIN keypad — backend (mock) orqali tasdiqlanadi |
| `LockScreen` | timeout / security_hold / session_expired holatlari |
| `BottomNav` | adapter routes'dan, permission filter bilan |
| `Dashboard` | universal stat kartochkalar (config'dan) |
| `SettingsView` | **faqat operativ** sozlamalar |
| `StaffManager` | xodimlar ro'yxati + CRUD skeleton |

### Adapter

`business/shop/adapter.js` — **sof deklarativ**, hech qanday `function` yo'q. Adapter purity runtime'da `BusinessRegistry.validatePurity()` orqali tekshiriladi.

### Testlar

73 ta tekshiruv. Quyidagilar qamrab olingan:

- Static kod tahlili (setInterval yo'qligi, adapter purity)
- Boot oqimi (mock mode'da Telegram bo'lmasdan)
- Event API to'liqligi (connect/disconnect/resume/syncSince/ack/...)
- Event push + idempotency (duplikat tashlanishi)
- PIN backend orqali tasdiqlanishi
- PIN localStorage'da hash saqlanmaganligi
- Backend xato kodlari (401/403/423) ishlanishi
- Permission UX filter (route va action darajasida)
- Dashboard va StaffManager render

---

## 2. Qo'shimcha xavfsizlik va arxitektura qarorlari

### 2.1. Polling QAT'IYAN ishlatilmaydi

**Qaror:** `setInterval` butun frontend kodida ishlatilmaydi. Doimiy `/events`, `/orders`, `/dashboard` so'rovlari yuborilmaydi.

**Sabab:** SaaSBot ko'p tenantli. 1000+ biznes × 2-3 admin × har 1-2 sek polling = serverni yiqitadi.

**Tekshiruv:** test fayli `src/**/*.js` ni grep qiladi, `setInterval(...)` topsa, test FAIL bo'ladi.

**Qanday istisno:**
- `setTimeout` (bir martalik) ruxsat — toast auto-dismiss, debounce, throttle, API timeout, PIN lock scheduler.
- Bu polling emas — bir martalik kechiktirilgan harakat.

### 2.2. Polling o'rniga 3 qatlamli aloqa

**A) Mini App ochiq + active** — `Events.connect()` transport orqali server push qiladi:
- `MockEventTransport` (Bosqich 1, default) — hech narsa qilmaydi, `window.__mockPushEvent()` orqali qo'lda yuboriladi
- `WebSocketEventTransport` (skeleton, Bosqich 2/3'da to'liq)
- `SSEEventTransport` (skeleton)

**B) Mini App yopiq** — Adminbot frontend ishtirok etmaydi. Backend Telegram bot orqali xabar yuboradi:
- xabarda **"Adminbotda ochish"** tugmasi
- `tg://resolve?domain=...&startapp=route:orders` formatda deep-link
- backend rate limit va digest siyosatini ushlaydi

**C) App qayta ochilganda** — `Events.syncSince(last_event_id)`:
- bir martalik so'rov (polling EMAS)
- `last_event_id` localStorage'da turadi (sensitive emas)
- backend cursor'dan keyingi missed eventlarni qaytaradi
- frontend `handleServerEvent()` orqali har birini local subscriber'larga yetkazadi
- duplikat ID lar tashlanadi (idempotency, oxirgi 200 ta tracked)

### 2.3. PIN faqat frontend modal EMAS

**Qaror:** PIN backend (yoki mock) tomonidan tasdiqlanadi. Frontend localStorage'da PIN hash SAQLAMAYDI.

**Eski (taqiqlangan) model:**
```js
// ❌ NOTO'G'RI
const hash = await sha256(pin);
if (hash === localStorage.getItem('pin_hash')) unlock();
```

**Yangi (to'g'ri) model:**
```js
// ✓ TO'G'RI
const resp = await Services.auth.verifyPin(pin);
if (resp.ok) unlock(resp.session);
// 423 qaytsa — security_hold lock holatiga o'tamiz
// 429 qaytsa — rate limit toast
```

**Frontend qiladigan ishlar:**
- PIN oynasini ko'rsatish
- PIN ni service layer'ga yuborish
- Backend javobiga ko'ra UI'ni yangilash
- Failed attempts UI ko'rsatuvi (backend o'z hisobini yuritadi)
- `pin.locked` event eshitish (timeout, security_hold)

**Ushbu yondashuv kelajakda:**
- backend `auth_version`, `jti`, `revoke` bilan integratsiya qila oladi
- bir nechta urinishdan keyin backend bloklasa, frontend `LockScreen` security_hold'da turadi
- owner panic/recovery oqimini backend tomonidan boshqarish mumkin

### 2.4. Permission ikki qavatli

**Qaror:** Frontend permission **faqat UX filter**. Xavfsizlik manbai — backend.

```
┌────────────────────────────────────────────────────────────┐
│  Frontend (UX layer)                                       │
│  - permission yo'q route — BottomNav'da ko'rinmaydi        │
│  - permission yo'q tugma — chiqmaydi                       │
│  - bu xavfsizlik EMAS — faqat tartibli UX                  │
├────────────────────────────────────────────────────────────┤
│  Backend (Security layer — AUTHORITATIVE)                  │
│  - har write endpoint permission tekshiradi                │
│  - 403 qaytarsa — frontend "ruxsat yo'q" toast             │
│  - 401 qaytarsa — sessiya tugagan, qayta auth/PIN          │
│  - 423 qaytarsa — security_hold, LockScreen                │
│  - 409 qaytarsa — version conflict toast                   │
│  - 422 qaytarsa — validation error formaga                 │
└────────────────────────────────────────────────────────────┘
```

`services.js` ichida `handleApiError()` markaziy ishlovchi shu xato kodlarini event'larga aylantiradi (`api.session_expired`, `api.permission_denied`, `api.security_hold`, ...). `pin.js`, `RootShell.js` shu event'larga subscribe qiladi va mos UI ko'rsatadi.

### 2.5. URL'dagi tenant_id faqat hint

**Qaror:** `?tenant_id=...` URL parametri faqat boshlang'ich ishora. Backend bootstrap javobi authoritative.

Mock mode'da hint ishlatiladi (sodda dev oqimi). Real mode'da:
- `auth.js login()` Telegram initData yuboradi
- backend qaysi tenantga ruxsat berishini hal qiladi
- `bootstrap.fetch()` real tenant'ni qaytaradi
- `Auth.applyBootstrap()` session'ni overwrite qiladi
- agar foydalanuvchi URL'da boshqa tenant yozgan bo'lsa, backend 403 qaytaradi va `api.permission_denied` event bo'ladi

### 2.6. Adapter sof deklarativ

**Qaror:** Adapter faylida `function`, `=>`, `mapEvents: (x) => ...` taqiqlanadi.

**Tasdiq:**
1. Static test: shop adapter regex bilan tekshiriladi (`: function` yoki `=>` topilsa FAIL)
2. Runtime test: `BusinessRegistry.validatePurity(adapter)` chuqur skan qilib, qiymat sifatida function topilsa violation qaytaradi

Agar adapter biror mantiqqa muhtoj bo'lsa, **string mapper nomi** beriladi:

```js
// ✓ TO'G'RI
CalendarView: { event_mapper: "reservation_calendar_mapper" }

// ❌ NOTO'G'RI
CalendarView: { mapEvents: (r) => r.map(...) }
```

Mapper implementatsiyasi komponent ichida yoki yadro'da turadi.

### 2.7. localStorage xavfsizligi

**Ruxsat:**
- `adminbot.tenant` — tenant ID (hint)
- `adminbot.last_event_id` — event cursor
- `adminbot.last_active` — faollik vaqti (PIN timeout uchun)
- `adminbot.theme` (kelajakda) — UI tema preference

**Taqiqlanadi:**
- PIN hash / PIN plaintext / PIN session token (xotirada turadi xolos)
- Uzoq muddatli haqiqiy access token (mock token saqlanishi mumkin, lekin lock/logout vaqtida tozalanadi)
- Permissions abadiy cache

`Auth.clearSession()` chaqirilganda token va sensitive cache tozalanadi.

### 2.8. SettingsView chegarasi

**Adminbotdagi SettingsView faqat operativ sozlamalar uchun:**
- profil ma'lumoti (read-only)
- PIN holati va o'zgartirish
- notification preferences (Bosqich 2'da)
- Tema (Telegram auto)
- Lock / Logout

**Adminbotdagi SettingsView'da YO'Q (SaaSBot SPA'da qoladi):**
- `business_type` o'zgartirish
- Vitrina dizayn
- To'lov provayder
- Yetkazib berish narx algoritmi
- Global ish vaqti
- Chuqur biznes konfiguratsiya

### 2.9. Mavjud va target endpoint'lar

**Mavjud (eski SaaSBot backend — shop-spec):**
- `POST /platform/auth/telegram`
- `GET /platform/admin/bootstrap`
- `GET /platform/admin/orders?...`
- `GET /platform/admin/events?after=0`

**Target (universal /platform/adminbot/* contract):**
- `POST /platform/adminbot/auth/telegram`
- `POST /platform/adminbot/auth/pin/verify`
- `POST /platform/adminbot/auth/pin/set`
- `POST /platform/adminbot/auth/pin/remove`
- `POST /platform/adminbot/auth/lock`
- `GET /platform/adminbot/{tenant}/bootstrap`
- `GET /platform/adminbot/{tenant}/dashboard`
- `GET /platform/adminbot/{tenant}/inbox`
- `PATCH /platform/adminbot/{tenant}/items/{id}/status`
- `GET /platform/adminbot/{tenant}/catalog`
- `GET /platform/adminbot/{tenant}/staff`
- `GET /platform/adminbot/{tenant}/customers`
- `GET /platform/adminbot/{tenant}/reports`
- `GET /platform/adminbot/{tenant}/events?since={cursor}`
- `POST /platform/adminbot/{tenant}/events/{event_id}/ack`

**Strategy:** Service layer (`core/services.js`) target endpoint'lardan foydalanadi. Bosqich 2/3 da backend tayyor bo'lganda real mode ulanadi. Hozircha hammasi mock orqali ishlaydi.

Agar real backend hali `/platform/adminbot/*` ga ko'tarilmagan bo'lsa, service layer "compatibility" rejimda eski `/platform/admin/*` ga fallback qila oladi (kelajak ishi).

### 2.10. Telegram bot notification — kontract

App yopiq turganda backend bot orqali xabar yuboradi. Frontend bu yuborishni amalga oshirmaydi (backend ishi), lekin **deep-link orqali kelganini handle qiladi**:

```js
// RootShell.js ichida boot vaqtida
const param = window.Telegram.WebApp.initDataUnsafe.start_param;
// param = "route:orders" → Router.go('orders')
```

Backend uchun notification policy:
- har mayda event uchun xabar yuborilmaydi
- prioritet: high (yangi buyurtma) → xabar; low (status update) → faqat in-app
- rate limit backendda
- digest/batch — kelajakda

---

## 3. Sinash yo'riqnomasi

### Lokal build
```bash
cd adminbot
python3 build.py
# dist/index.html yaratiladi
```

### Lokal sinov (brauzerda)
```bash
cd adminbot/dist
python3 -m http.server 8000
# Browser: http://localhost:8000/?mock=true
```

URL parametrlar (test/dev uchun):
- `?mock=true` — mock mode (sukut bo'yicha Telegram bo'lmasa avtomatik mock)
- `?tenant_id=test_t` — tenant hint
- `?biz=shop|fastfood|restaurant|...` — biznes turi (Bosqich 2/3 da kerak bo'ladi)
- `?role=owner|manager|staff` — sinov role
- `?pin=on` — PIN o'rnatilgan deb hisoblash
- `?pin_locked=on` — boshlanish holatida lock'da

### Testlar
```bash
cd adminbot/tests
node test_bosqich_1.js
# 73 ta tekshiruv kutiladi
```

### Test kategoriyalari
- Static kod tahlili
- Boot oqimi
- Event API to'liqligi
- Event push va idempotency
- PIN backend verification
- Backend xato kodlari
- Permission UX filter
- Dashboard / StaffManager render

---

## 4. Bosqich 2 va 3'ga qoldirilgan ishlar

### Bosqich 2 (kelasi)
- `InboxList`, `OrderCard`, `OrderStatusBadge` (universal buyurtmalar)
- `CategoryCRUD`, `ProductCRUD`, `ImageUploader`
- `CustomerList`, `CustomerProfile`, `ReportsView`, `NotificationsBroadcast`, `EventsLog`
- Supplier komponentlari (`BalanceLedger`, `TierAssigner`, ...)
- 3 ta adapter: `shop` (kengaytirish), `fastfood` (yangi), `supplier` (yangi)
- `WebSocketEventTransport` to'liq amalga oshirish
- StaffManager to'liq CRUD (Bosqich 1'da faqat ro'yxat)

### Bosqich 3 (yakuniy)
- Kalendar (`CalendarView`, `AppointmentCard`, ...)
- Restaurant (`TableMap`, `ReservationCard`, `BanquetManager`)
- Production (`StageAdvancer`, `TechBriefViewer`, ...)
- Courier (`LiveTracker` push-based, `RouteMap`, ...)
- 4 ta adapter: `restaurant`, `appointment_service`, `custom_production`, `courier_service`
- `restaurant` uchun: **alohida ReservationsList YO'Q** — `InboxList + ReservationCard` ishlatiladi

### Backend bog'liq
- Real `/platform/adminbot/*` endpoint implementatsiyasi
- WebSocket/SSE infrastruktura
- Telegram bot xabar yuborish (notification policy bilan)
- Rate limiting va audit log
- Image storage (private/public)

---

## 5. Taxminlar (assumption'lar)

Topshiriqda aniq belgilanmagan, lekin biz quyidagi taxminlarni qildik:

1. **Vue 3 CDN o'rniga vendor inline** — network cheklovi (jsdom test) tufayli Vue local'ga embed qilindi. Production'da CDN'dan yuklab olish ham ishlaydi, lekin offline ham tayyor.
2. **PIN sukut "1234"** — mock uchun. Real backend PIN'ni o'z DB'da hash bilan saqlaydi.
3. **Mock auth bootstrap'i shop business_type'ni qaytaradi** — Bosqich 2/3 da boshqa turlar uchun mock kengaytiriladi.
4. **`__mockPushEvent`** global helper — test va dev uchun. Production build'da ham bor (mock mode'da ishlaydi). Bu xavfsiz, chunki Telegram WebApp arxitekturasida client-side code o'zgartirish backend xavfsizligini buzmaydi.
5. **PIN lock taymeri visibility'changeda** — tab background'ga ketganda taymer ishlamaydi; qaytganda tekshiramiz. Bu ko'p sonli pinda foydalanuvchi tajribasini chiroyli qiladi.
6. **`OperationalSettingsView` o'rniga `SettingsView`** — nom sodda qoldirildi, lekin chegara hujjat va kodda aniq belgilangan.

---

## 6. Statistika

| Ko'rsatkich | Qiymat |
|---|---|
| Jami qator (CSS + JS bizniki) | ~3441 qator |
| Yadro JS | 1825 qator |
| Komponentlar JS | 1016 qator |
| Mocks JS | 378 qator |
| Business JS | 141 qator |
| App boot | 69 qator |
| CSS | 881 qator (3 fayl) |
| `dist/index.html` hajmi | 274 KB (gzip bilan kichikroq) |
| Testlar | 73 ta tekshiruv, hammasi PASS |

---

**Bosqich 1 — TUGAGAN.** Bosqich 2 boshlash uchun tayyor.
