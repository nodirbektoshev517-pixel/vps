# Bosqich 4 — Adapter'lar (qisman)

> Bosqich 3 universal komponent kutubxonasi ustiga **sof deklarativ** adapter'lar.
> 6 ta biznes turi uchun adapter yozildi. **Courier** Bosqich 4'ning oxirgi qadami
> sifatida qoldirildi (LiveTracker bilan integratsiya testi alohida tekshiriladi).

---

## Yetkazib berilgan adapter'lar (6 ta)

| Biznes | Fayl | enabled_components | BottomNav | Secondary |
|---|---|---:|---:|---:|
| **shop** | `shop/adapter.js` | 23 | 5 | 4 |
| **fastfood** | `fastfood/adapter.js` | 17 | 4 | 4 |
| **supplier** | `supplier/adapter.js` | 25 | 5 | 6 |
| **restaurant** | `restaurant/adapter.js` | 23 | 5 | 6 |
| **appointment_service** | `appointment_service/adapter.js` | 18 | 5 | 7 |
| **custom_production** | `custom_production/adapter.js` | 17 | 4 | 5 |

`courier` Bosqich 4 yakunida yaratiladi.

Barcha adapter'lar **sof deklarativ** — function YO'Q. Avtomatik build (`src/business/**/*.js`).

---

## Adapter pattern (yakuniy)

Har adapter `window.Adminbot.Business.<biz>`'ga yozadi:

```js
{
  business_type: 'shop',
  label: 'Do\'kon',

  enabled_components: ['Dashboard', 'InboxList', ...],

  component_configs: {
    InboxList: {
      data_source: { service: 'inbox', method: 'list' },   // generic
      status_field: 'status',                               // yoki 'stage'
      status_kind: 'order',                                 // Labels lookup
      created_event: 'order.created',
      status_changed_event: 'order.status_changed',
      item_card: 'OrderCard',                               // yoki Reservation/Appointment/BriefCard
      statuses: [...],
      default_status: 'new',
      page_size: 20,
      terms: { item: 'Buyurtma', items: 'Buyurtmalar' },
    },
    // ... boshqa komponent konfiguratsiyalari
  },

  routes: [
    { key, component, icon, label, permission },
    { ..., secondary: true },    // Settings ichida "Boshqa bo'limlar"
  ],
}
```

---

## Eng kuchli pattern — universal InboxList

`InboxList` to'liq biznes-agnostik. 4 ta yangi adapter (`restaurant`, `appointment_service`, `custom_production`, va kelajakda `courier`) hech qanday qo'shimcha komponent yozmasdan InboxList'ni ishlatadi:

```js
// Restaurant adapter — InboxList'ni bron ro'yxati sifatida
InboxList: {
  data_source: { service: 'restaurant', method: 'listReservations' },
  status_kind: 'reservation',
  item_card: 'ReservationCard',
  ...
}

// Appointment_service adapter
InboxList: {
  data_source: { service: 'appointment', method: 'listAppointments' },
  status_kind: 'appointment',
  item_card: 'AppointmentCard',
  ...
}

// Custom_production adapter
InboxList: {
  data_source: { service: 'production', method: 'listBriefs' },
  status_field: 'stage',                  // E'TIBOR: 'stage', 'status' emas
  status_kind: 'production',
  item_card: 'BriefCard',
  ...
}
```

Generic data_source orqali shu komponent 5 xil resursni boshqaradi (orders, reservations, appointments, briefs, deliveries) — biznes mantiqi YO'Q.

---

## Asosiy biznes farqlar

### `shop` vs `fastfood`
- shop: yetkazib berish bor (delivery_address extension), 5 BottomNav tab, mijoz profili
- fastfood: pickup biznes (manzil YO'Q), 4 tab (customers yo'q), label override "Tayyor" → "Olib ketishga tayyor"

### `supplier` (B2B)
- shipped status (on_delivery/delivered YO'Q — consumer terms)
- Mijozlar "do'konlar" — TierAssigner, CreditLimitManager, BalanceLedger, InviteCodeGenerator, ShopApprover
- "Do'konlar" tab dashboard'dan keyin

### `restaurant`
- Asosiy ekran — bronlar (InboxList + ReservationCard)
- TableMap alohida tab
- BanquetManager, HallStatusBoard secondary'da
- Mijoz profili YO'Q (anonim — zal mijozlari)

### `appointment_service`
- Asosiy ekran — CalendarView (jadval)
- Uchrashuvlar ro'yxati ham bor (InboxList)
- ServiceCRUD asosiy, SpecialistCRUD secondary
- WalkInQueue navbat boshqaruvi
- Mijoz profili BOR (qaytaruvchi mijozlar)

### `custom_production`
- "Katalog" YO'Q — har buyurtma noyob (brief)
- Brieflar ro'yxati InboxList orqali (`status_field: 'stage'`, 9 bosqich)
- BriefCard → TechBriefViewer (single brief)
- OnSiteDispatch alohida tab
- 4 BottomNav tab (catalog yo'q)

---

## Komponent konfiguratsiyalari — joriy soni

Bosqich 4 yakunida adapter'lar foydalanadigan komponentlar:

```
49 ta universal komponent (Bosqich 1-3 dan)
 +  1 ta BriefCard (production InboxList uchun)
─────────────────────────────────────────
50 ta jami
```

Hech bir komponent biznes turini bilmaydi — barcha o'zgaruvchanlik adapter konfiguratsiyasidan keladi.

---

## Test natijasi

```
test_bosqich_1.js          → 152 PASS / 0 FAIL  (Bosqich 1, 1.5, 1.6)
test_bosqich_2_1.js        →  47 PASS / 0 FAIL  (Inbox)
test_bosqich_2_rest.js     →  95 PASS / 0 FAIL  (Katalog, mijoz, hisobot, audit, supplier)
test_bosqich_3.js          → 100 PASS / 0 FAIL  (Restaurant, appointment, production, courier)
test_fastfood_adapter.js   →  27 PASS / 0 FAIL  (Fastfood adapter)
test_adapters_phase4.js    →  80 PASS / 0 FAIL  (Qolgan 5 adapter)
─────────────────────────────────────────────────
JAMI:                         501 PASS / 0 FAIL
```

`test_adapters_phase4.js` har adapter uchun tekshiradi:
- Adapter ro'yxatga olingan, business_type to'g'ri
- **Sof deklarativ** — chuqur recursive tekshiruv, function topilsa FAIL
- enabled_components mavjud komponentlar
- routes komponentlari enabled_components da
- InboxList.data_source haqiqiy Service.method'ga ishora qiladi
- Status oqimi va Labels mosligi
- Terms override Labels.formatStatus orqali ishlaydi
- Biznes turining xususiyatlari (B2B ≠ B2C; pickup ≠ delivery; statik katalog yoki yo'q)

---

## Loyiha statistikasi

| Metr | Bosqich 3 | Bosqich 4 (qisman) |
|---|---:|---:|
| Biznes turlari (adapter) | 1 | **6** (courier kelyapti) |
| Komponentlar | 49 | **50** (+ BriefCard) |
| Mock fayllar | 14 | 14 |
| Service resurslar | 16 | 16 |
| Test soni | 394 | **501** |
| dist/index.html (dev) | ~565 KB | **~588 KB** |
| Adapter qatorlari | 96 (shop) | **~605** (6 ta) |

---

## Bosqich 4 ga qolgan ish

1. **Courier adapter** (`courier/adapter.js`) — barcha 5 Phase 3.D komponentlari bilan
2. **WebSocketEventTransport** to'liq amalga oshirish (`api/transport.js` yoki shunga o'xshash)
3. Adapter'lar ichida `Runtime.adapter` lookup'i Router/BottomNav bilan integratsiya testi
4. Yakuniy E2E test — har biznes turi uchun: boot → BottomNav → asosiy ekran → bitta action

Birinchi 3 ta — kichik, sof deklarativ. 4-si esa joriy adapter'larning ishlashini validatsiya qiladi.
