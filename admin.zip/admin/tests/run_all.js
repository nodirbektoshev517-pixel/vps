#!/usr/bin/env node
/**
 * run_all.js — barcha test suite'larni ketma-ket ishga tushiradi.
 *
 * Foydalanish:
 *   cd tests && node run_all.js
 */
const { spawnSync } = require('child_process');
const path = require('path');

const SUITES = [
  'test_bosqich_1.js',
  'test_bosqich_2_1.js',
  'test_bosqich_2_rest.js',
  'test_bosqich_3.js',
  'test_fastfood_adapter.js',
  'test_adapters_phase4.js',
];

let totalPass = 0;
let totalFail = 0;
let suitesFailed = 0;

for (const suite of SUITES) {
  console.log(`\n${'='.repeat(60)}`);
  console.log(`>> ${suite}`);
  console.log('='.repeat(60));
  const r = spawnSync('node', [path.join(__dirname, suite)], { stdio: 'inherit' });
  if (r.status !== 0) suitesFailed++;
}

console.log(`\n${'='.repeat(60)}`);
if (suitesFailed === 0) {
  console.log('JAMI: Barcha suite\'lar yashil ✓');
  process.exit(0);
} else {
  console.log(`JAMI: ${suitesFailed} suite FAIL`);
  process.exit(1);
}
