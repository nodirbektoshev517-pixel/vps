/**
 * test_bosqich_3.js — Bosqich 3 (operativ biznes-spetsifik komponentlar).
 *
 * Qamrov:
 *   3.A Restaurant (TableMap, ReservationCard, BanquetManager, HallStatusBoard)
 *   3.B Appointment (CalendarView, ServiceCRUD, SpecialistCRUD, AppointmentCard, WalkInQueue)
 *   3.C Production (TechBriefViewer, StageAdvancer, PriceProposalSender, OnSiteDispatch)
 *   3.D Courier (CourierList, CourierAssigner, LiveTracker, RouteMap, DeliveryStatusBoard)
 *
 * Tekshiriladi:
 *   - Service layer: filter, pagination, transition (4xx/409)
 *   - Mock backend: state mutation, real-time event push
 *   - Komponentlar: global registr
 *   - Real-time idempotency (LiveTracker uchun seenEventIds)
 *   - Static asoslar: setInterval YO'Q, polling YO'Q
 */
const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const DIST = path.join(__dirname, '..', 'dist', 'index.html');
const html = fs.readFileSync(DIST, 'utf8');

let pass = 0, fail = 0;
const failures = [];

function check(name, cond, detail = '') {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; failures.push(name + (detail ? ' — ' + detail : '')); console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`); }
}

async function section(name, fn) {
  console.log(`\n=== ${name} ===`);
  await fn();
}

function bootDom() {
  const vc = new VirtualConsole();
  vc.on('jsdomError', () => {});
  const dom = new JSDOM(html, {
    runScripts: 'dangerously',
    url: 'http://localhost:8000/?mock=true&tenant_id=tn_demo&biz=shop&role=owner&pin=off',
    virtualConsole: vc,
  });
  return dom;
}

async function waitForBoot(window, predicate, timeoutMs = 2000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    try { if (predicate(window)) return true; } catch (_) {}
    await new Promise(r => setTimeout(r, 50));
  }
  return false;
}

(async () => {
  // ===========================================================
  // Bosqich 3.A — Restaurant
  // ===========================================================
  await section('3.A Restaurant — Mock backend va Service', async () => {
    const dom = bootDom();
    const ok = await waitForBoot(dom.window, w =>
      w.Adminbot && w.Adminbot.Core && w.Adminbot.Core.Services && w.Adminbot.Core.Services.restaurant);
    check('Services.restaurant ro\'yxatga olingan', ok);
    if (!ok) return;
    const S = dom.window.Adminbot.Core.Services.restaurant;

    // listTables — zal va stollar
    const tables = await S.listTables();
    check('listTables natijasi items + halls qaytaradi',
      Array.isArray(tables.items) && Array.isArray(tables.halls) && tables.items.length === 12);
    check('Zal 2 ta (asosiy va VIP)', tables.halls.length === 2);

    // setTableStatus — to'g'ri status
    const t = tables.items[0];
    const updated = await S.setTableStatus(t.id, 'cleaning');
    check('Stol statusi yangilanadi', updated.status === 'cleaning');

    // setTableStatus — noto'g'ri status (422)
    let caught = null;
    try { await S.setTableStatus(t.id, 'invalid'); }
    catch (e) { caught = e; }
    check('Noto\'g\'ri stol statusi 422 qaytaradi', caught && caught.status === 422);

    // setTableStatus — mavjud emas (404)
    caught = null;
    try { await S.setTableStatus('tbl_nonexistent', 'free'); }
    catch (e) { caught = e; }
    check('Mavjud emas stol 404 qaytaradi', caught && caught.status === 404);

    // Real-time event keldimi (status_changed)
    let eventReceived = false;
    dom.window.Adminbot.Core.Events.subscribe('table.status_changed', () => { eventReceived = true; });
    await S.setTableStatus(t.id, 'free');
    await new Promise(r => setTimeout(r, 100));
    check('table.status_changed event push qilinadi', eventReceived);

    // listReservations — pagination
    const r1 = await S.listReservations({ page_size: 5 });
    check('Reservations pagination ishlaydi', r1.items.length === 5 && r1.has_more === true);
    check('next_cursor qaytariladi', !!r1.next_cursor);

    // Cursor bilan keyingi sahifa
    const r2 = await S.listReservations({ page_size: 5, cursor: r1.next_cursor });
    check('Cursor keyingi sahifaga olib o\'tadi',
      r2.items.length > 0 && r2.items[0].id !== r1.items[0].id);

    // Status filter
    const conf = await S.listReservations({ status: 'confirmed' });
    check('Reservations status filter ishlaydi',
      conf.items.every(x => x.status === 'confirmed'));

    // Transition: requested → confirmed (ruxsat)
    const reqRes = (await S.listReservations({ status: 'requested' })).items[0];
    if (reqRes) {
      const conf = await S.updateReservationStatus(reqRes.id, 'confirmed');
      check('Reservation transition ruxsat (requested → confirmed)', conf.status === 'confirmed');
    }

    // Transition: confirmed → preparing (rad — 409)
    const confRes = (await S.listReservations({ status: 'confirmed' })).items[0];
    if (confRes) {
      caught = null;
      try { await S.updateReservationStatus(confRes.id, 'preparing'); }
      catch (e) { caught = e; }
      check('Noto\'g\'ri transition 409 qaytaradi', caught && caught.status === 409);
    }

    // Banquets CRUD
    const bnq = await S.createBanquet({
      name: 'Test banket', date: new Date().toISOString(), guest_count: 30,
      hall_id: 'hall_main', menu_summary: 'Test menyu',
    });
    check('Banket yaratiladi', bnq && bnq.id && bnq.name === 'Test banket');

    const upd = await S.updateBanquet(bnq.id, { guest_count: 40 });
    check('Banket yangilanadi', upd.guest_count === 40);

    await S.deleteBanquet(bnq.id);
    const banquets = await S.listBanquets();
    check('Banket o\'chiriladi',
      !banquets.items.some(b => b.id === bnq.id));

    // Banket — name majburiy
    caught = null;
    try { await S.createBanquet({ date: new Date().toISOString() }); }
    catch (e) { caught = e; }
    check('Banket name majburiy (422)', caught && caught.status === 422);

    // __mockNewReservation helper
    if (typeof dom.window.__mockNewReservation === 'function') {
      const newR = dom.window.__mockNewReservation();
      check('__mockNewReservation yangi bron yaratadi', newR && newR.id);
    }

    dom.window.close();
  });

  await section('3.A Restaurant — Komponentlar registratsiya', async () => {
    const dom = bootDom();
    await waitForBoot(dom.window, w => w.Adminbot && w.Adminbot.Components);
    const C = dom.window.Adminbot.Components;
    check('TableMap ro\'yxatga olingan', !!C.TableMap);
    check('ReservationCard ro\'yxatga olingan', !!C.ReservationCard);
    check('BanquetManager ro\'yxatga olingan', !!C.BanquetManager);
    check('HallStatusBoard ro\'yxatga olingan', !!C.HallStatusBoard);
    check('SpecialRequestsBlock extension', !!C.SpecialRequestsBlock);
    check('DepositStatusBlock extension', !!C.DepositStatusBlock);
    check('PartyInfoBlock extension', !!C.PartyInfoBlock);
    dom.window.close();
  });

  // ===========================================================
  // Bosqich 3.B — Appointment
  // ===========================================================
  await section('3.B Appointment — Mock backend va Service', async () => {
    const dom = bootDom();
    await waitForBoot(dom.window, w =>
      w.Adminbot && w.Adminbot.Core.Services && w.Adminbot.Core.Services.appointment);
    const S = dom.window.Adminbot.Core.Services.appointment;

    // Services CRUD
    const svcList = await S.listServices();
    check('listServices natijasi qaytaradi', Array.isArray(svcList.items) && svcList.items.length >= 5);

    const newSvc = await S.createService({ name: 'Test xizmat', duration_min: 45, price: 80000 });
    check('Xizmat yaratiladi', newSvc && newSvc.id && newSvc.duration_min === 45);

    const updSvc = await S.updateService(newSvc.id, { price: 90000 });
    check('Xizmat yangilanadi', updSvc.price === 90000);

    await S.deleteService(newSvc.id);
    const after = await S.listServices();
    check('Xizmat o\'chiriladi', !after.items.some(s => s.id === newSvc.id));

    // Specialists CRUD
    const spcList = await S.listSpecialists();
    check('Mutaxassislar ro\'yxati', Array.isArray(spcList.items) && spcList.items.length >= 3);

    const newSpc = await S.createSpecialist({
      first_name: 'Test', last_name: 'Mutaxassis',
      services: ['svc_1'], working_hours: '10:00-18:00',
    });
    check('Mutaxassis yaratiladi', newSpc && newSpc.id && newSpc.services.includes('svc_1'));

    await S.deleteSpecialist(newSpc.id);
    const aftSpc = await S.listSpecialists();
    check('Mutaxassis o\'chiriladi', !aftSpc.items.some(s => s.id === newSpc.id));

    // Mutaxassis — first_name majburiy
    let caught = null;
    try { await S.createSpecialist({ last_name: 'Faqat' }); }
    catch (e) { caught = e; }
    check('Mutaxassis first_name majburiy (422)', caught && caught.status === 422);

    // Appointments filter + transition
    const all = await S.listAppointments({});
    check('Appointments listi qaytariladi', Array.isArray(all.items) && all.items.length > 0);

    const sched = await S.listAppointments({ status: 'scheduled' });
    check('Appointment status filter',
      sched.items.every(a => a.status === 'scheduled'));

    const bySpc = await S.listAppointments({ specialist_id: 'spc_1' });
    check('Appointment specialist filter',
      bySpc.items.every(a => a.specialist_id === 'spc_1'));

    // Transition: scheduled → in_progress (ruxsat)
    if (sched.items.length > 0) {
      const upd = await S.updateAppointmentStatus(sched.items[0].id, 'in_progress');
      check('Appointment transition (scheduled → in_progress)', upd.status === 'in_progress');
    }

    // Noto'g'ri transition: in_progress → scheduled (409)
    const ipList = await S.listAppointments({ status: 'in_progress' });
    if (ipList.items.length > 0) {
      caught = null;
      try { await S.updateAppointmentStatus(ipList.items[0].id, 'scheduled'); }
      catch (e) { caught = e; }
      check('Noto\'g\'ri appointment transition 409', caught && caught.status === 409);
    }

    // Walk-in queue
    const wlk = await S.listWalkIn();
    check('Walk-in queue qaytariladi', Array.isArray(wlk.items));

    const newW = await S.addWalkIn({ customer_name: 'Test mehmon', service_id: 'svc_1' });
    check('Walk-in qo\'shiladi', newW && newW.id);

    await S.removeWalkIn(newW.id);
    const aftW = await S.listWalkIn();
    check('Walk-in chiqariladi', !aftW.items.some(w => w.id === newW.id));

    // Walk-in: customer_name majburiy
    caught = null;
    try { await S.addWalkIn({ service_id: 'svc_1' }); }
    catch (e) { caught = e; }
    check('Walk-in customer_name majburiy (422)', caught && caught.status === 422);

    dom.window.close();
  });

  await section('3.B Appointment — Komponentlar registratsiya', async () => {
    const dom = bootDom();
    await waitForBoot(dom.window, w => w.Adminbot && w.Adminbot.Components);
    const C = dom.window.Adminbot.Components;
    check('CalendarView ro\'yxatga olingan', !!C.CalendarView);
    check('ServiceCRUD ro\'yxatga olingan', !!C.ServiceCRUD);
    check('SpecialistCRUD ro\'yxatga olingan', !!C.SpecialistCRUD);
    check('AppointmentCard ro\'yxatga olingan', !!C.AppointmentCard);
    check('WalkInQueue ro\'yxatga olingan', !!C.WalkInQueue);
    dom.window.close();
  });

  // ===========================================================
  // Bosqich 3.C — Custom Production
  // ===========================================================
  await section('3.C Production — Mock backend va Service', async () => {
    const dom = bootDom();
    await waitForBoot(dom.window, w =>
      w.Adminbot && w.Adminbot.Core.Services && w.Adminbot.Core.Services.production);
    const S = dom.window.Adminbot.Core.Services.production;

    // Briefs pagination
    const r1 = await S.listBriefs({ page_size: 5 });
    check('Briefs pagination', r1.items.length === 5 && r1.has_more === true);

    const r2 = await S.listBriefs({ page_size: 5, cursor: r1.next_cursor });
    check('Briefs cursor pagination', r2.items.length > 0 && r2.items[0].id !== r1.items[0].id);

    // Stage filter
    const review = await S.listBriefs({ stage: 'brief_review' });
    check('Briefs stage filter', review.items.every(b => b.stage === 'brief_review'));

    // Get one brief
    const b = await S.getBrief(r1.items[0].id);
    check('getBrief topshiriqni qaytaradi', b && b.id === r1.items[0].id);

    // getBrief 404
    let caught = null;
    try { await S.getBrief('brf_nonexistent'); }
    catch (e) { caught = e; }
    check('getBrief mavjud emasda 404', caught && caught.status === 404);

    // Stage advance — to'g'ri transition
    const reviewBrief = review.items[0];
    if (reviewBrief) {
      const adv = await S.advanceStage(reviewBrief.id, 'proposal_sent');
      check('Stage advance (brief_review → proposal_sent)', adv.stage === 'proposal_sent');
    }

    // Stage advance — noto'g'ri transition (409)
    const next = (await S.listBriefs({ stage: 'design' })).items[0];
    if (next) {
      caught = null;
      try { await S.advanceStage(next.id, 'brief_review'); }
      catch (e) { caught = e; }
      check('Noto\'g\'ri stage transition 409', caught && caught.status === 409);
    }

    // sendProposal — faqat brief_review bosqichida
    const reviewList = await S.listBriefs({ stage: 'brief_review' });
    if (reviewList.items.length > 0) {
      const upd = await S.sendProposal(reviewList.items[0].id, 5_000_000);
      check('sendProposal brief_review da ishlaydi va proposal_sent ga o\'tadi',
        upd.proposed_price === 5_000_000 && upd.stage === 'proposal_sent');
    }

    // sendProposal — boshqa bosqichda (409)
    const designList = await S.listBriefs({ stage: 'design' });
    if (designList.items.length > 0) {
      caught = null;
      try { await S.sendProposal(designList.items[0].id, 1_000_000); }
      catch (e) { caught = e; }
      check('sendProposal design bosqichida 409', caught && caught.status === 409);
    }

    // sendProposal — price majburiy
    const newReview = (await S.listBriefs({ stage: 'brief_review' })).items[0];
    if (newReview) {
      caught = null;
      try { await S.sendProposal(newReview.id, 0); }
      catch (e) { caught = e; }
      check('sendProposal price > 0 majburiy (422)', caught && caught.status === 422);
    }

    // Real-time stage_changed event — approved → design transition
    let eventReceived = false;
    dom.window.Adminbot.Core.Events.subscribe('brief.stage_changed', () => { eventReceived = true; });
    const approved = (await S.listBriefs({ stage: 'approved' })).items[0];
    if (approved) {
      await S.advanceStage(approved.id, 'design');
      await new Promise(r => setTimeout(r, 100));
      check('brief.stage_changed event push qilinadi', eventReceived);
    } else {
      check('brief.stage_changed event (approved brief topilmadi)', true);
    }

    // Dispatches CRUD
    const disp = await S.listDispatches();
    check('Dispatches ro\'yxati', Array.isArray(disp.items));

    const newDisp = await S.createDispatch({
      brief_id: 'brf_1', worker_name: 'Test', address: 'Test addr',
      scheduled_at: new Date().toISOString(), purpose: 'O\'lcham olish',
    });
    check('Dispatch yaratiladi', newDisp && newDisp.id);

    const updDisp = await S.updateDispatchStatus(newDisp.id, 'in_progress');
    check('Dispatch status yangilanadi', updDisp.status === 'in_progress');

    // Dispatch — brief_id majburiy
    caught = null;
    try { await S.createDispatch({ worker_name: 'Faqat ish' }); }
    catch (e) { caught = e; }
    check('Dispatch brief_id majburiy (422)', caught && caught.status === 422);

    dom.window.close();
  });

  await section('3.C Production — Komponentlar registratsiya', async () => {
    const dom = bootDom();
    await waitForBoot(dom.window, w => w.Adminbot && w.Adminbot.Components);
    const C = dom.window.Adminbot.Components;
    check('TechBriefViewer ro\'yxatga olingan', !!C.TechBriefViewer);
    check('StageAdvancer ro\'yxatga olingan', !!C.StageAdvancer);
    check('PriceProposalSender ro\'yxatga olingan', !!C.PriceProposalSender);
    check('OnSiteDispatch ro\'yxatga olingan', !!C.OnSiteDispatch);
    dom.window.close();
  });

  // ===========================================================
  // Bosqich 3.D — Courier
  // ===========================================================
  await section('3.D Courier — Mock backend va Service', async () => {
    const dom = bootDom();
    await waitForBoot(dom.window, w =>
      w.Adminbot && w.Adminbot.Core.Services && w.Adminbot.Core.Services.courier);
    const S = dom.window.Adminbot.Core.Services.courier;

    // listCouriers
    const all = await S.listCouriers();
    check('Couriers ro\'yxati', Array.isArray(all.items) && all.items.length === 5);

    // status filter
    const avail = await S.listCouriers({ status: 'available' });
    check('Courier status filter', avail.items.every(c => c.status === 'available'));

    // setCourierStatus
    const c = all.items[0];
    const upd = await S.setCourierStatus(c.id, 'busy');
    check('Courier status yangilanadi', upd.status === 'busy');

    // Noto'g'ri status
    let caught = null;
    try { await S.setCourierStatus(c.id, 'invalid'); }
    catch (e) { caught = e; }
    check('Noto\'g\'ri courier status 422', caught && caught.status === 422);

    // listDeliveries pagination
    const r1 = await S.listDeliveries({ page_size: 5 });
    check('Deliveries pagination', r1.items.length === 5);

    // Pending uchun filter
    const pending = await S.listDeliveries({ status: 'pending_assignment' });
    check('Pending deliveries filter',
      pending.items.every(d => d.status === 'pending_assignment'));

    // assignDelivery — to'g'ri kuryer
    if (pending.items.length > 0) {
      const availC = all.items.find(c => c.status !== 'offline');
      // Avval qaytadan available qilamiz (avvalgi setStatus busy qildi)
      await S.setCourierStatus(availC.id, 'available');
      const assigned = await S.assignDelivery(pending.items[0].id, availC.id);
      check('Delivery tayinlandi', assigned.courier_id === availC.id && assigned.status === 'assigned');
    }

    // assignDelivery — oflayn kuryerga (409)
    const offline = all.items.find(c => c.status === 'offline');
    const pending2 = await S.listDeliveries({ status: 'pending_assignment' });
    if (offline && pending2.items.length > 0) {
      caught = null;
      try { await S.assignDelivery(pending2.items[0].id, offline.id); }
      catch (e) { caught = e; }
      check('Oflayn kuryerga tayinlash 409', caught && caught.status === 409);
    }

    // assignDelivery — mavjud bo'lmagan kuryer
    if (pending2.items.length > 0) {
      caught = null;
      try { await S.assignDelivery(pending2.items[0].id, 'crr_nonexistent'); }
      catch (e) { caught = e; }
      check('Mavjud emas kuryer 404', caught && caught.status === 404);
    }

    // __mockCourierLocation — event push
    let locEvents = 0;
    dom.window.Adminbot.Core.Events.subscribe('courier.location_updated', () => locEvents++);
    if (typeof dom.window.__mockCourierLocation === 'function') {
      dom.window.__mockCourierLocation('crr_1', 41.40, 69.30);
      await new Promise(r => setTimeout(r, 50));
      check('__mockCourierLocation event push qiladi', locEvents === 1);
    }

    // delivery.assigned event push
    let assignedEvents = 0;
    dom.window.Adminbot.Core.Events.subscribe('delivery.assigned', () => assignedEvents++);
    const pendNow = await S.listDeliveries({ status: 'pending_assignment' });
    const freshC = all.items.find(x => x.status !== 'offline');
    if (pendNow.items.length > 0 && freshC) {
      await S.setCourierStatus(freshC.id, 'available');
      await S.assignDelivery(pendNow.items[0].id, freshC.id);
      await new Promise(r => setTimeout(r, 100));
      check('delivery.assigned event push qilinadi', assignedEvents >= 1);
    }

    dom.window.close();
  });

  await section('3.D Courier — Komponentlar registratsiya', async () => {
    const dom = bootDom();
    await waitForBoot(dom.window, w => w.Adminbot && w.Adminbot.Components);
    const C = dom.window.Adminbot.Components;
    check('CourierList ro\'yxatga olingan', !!C.CourierList);
    check('CourierAssigner ro\'yxatga olingan', !!C.CourierAssigner);
    check('LiveTracker ro\'yxatga olingan', !!C.LiveTracker);
    check('RouteMap ro\'yxatga olingan', !!C.RouteMap);
    check('DeliveryStatusBoard ro\'yxatga olingan', !!C.DeliveryStatusBoard);
    dom.window.close();
  });

  // ===========================================================
  // LiveTracker idempotency — bir xil event ikki marta push qilinsa
  // ===========================================================
  await section('LiveTracker — event idempotency (seenIds)', async () => {
    // LiveTracker setup() kodi seenEventIds Set ishlatadi.
    // Buni to'g'ridan-to'g'ri tekshirish — manba kodida bor:
    const src = fs.readFileSync(
      path.join(__dirname, '..', 'src', 'components', 'operational', 'LiveTracker.js'), 'utf8');
    check('LiveTracker seenEventIds Set ishlatadi',
      src.includes('seenEventIds') && src.includes('new Set()'));
    check('LiveTracker setInterval ishlatmaydi (push-based)',
      !src.includes('setInterval'));
    check('LiveTracker duplicate event check qiladi',
      src.includes('seenEventIds.has') && src.includes('seenEventIds.add'));
  });

  // ===========================================================
  // Static asoslar — Bosqich 3 manba kodi
  // ===========================================================
  await section('Static asoslar — Bosqich 3', async () => {
    const dirs = ['mocks/restaurant.js', 'mocks/appointment.js', 'mocks/production.js', 'mocks/courier.js'];
    for (const f of dirs) {
      const src = fs.readFileSync(path.join(__dirname, '..', 'src', f), 'utf8');
      // setInterval — faqat dev helper'larda bo'lishi mumkin emas
      check(`${f}: setInterval YO'Q (polling yo'q)`, !src.includes('setInterval'));
    }

    const compFiles = [
      'TableMap.js', 'ReservationCard.js', 'BanquetManager.js', 'HallStatusBoard.js',
      'CalendarView.js', 'ServiceCRUD.js', 'SpecialistCRUD.js', 'AppointmentCard.js', 'WalkInQueue.js',
      'TechBriefViewer.js', 'StageAdvancer.js', 'PriceProposalSender.js', 'OnSiteDispatch.js',
      'CourierList.js', 'CourierAssigner.js', 'LiveTracker.js', 'RouteMap.js', 'DeliveryStatusBoard.js',
    ];
    let setIntervalFound = [];
    let fetchFound = [];
    let vhtmlFound = [];
    for (const f of compFiles) {
      const src = fs.readFileSync(path.join(__dirname, '..', 'src', 'components', 'operational', f), 'utf8');
      if (src.includes('setInterval')) setIntervalFound.push(f);
      if (/[^a-zA-Z_]fetch\(/.test(src)) fetchFound.push(f);
      if (src.includes('v-html')) vhtmlFound.push(f);
    }
    check('Bosqich 3 komponentlari: setInterval YO\'Q',
      setIntervalFound.length === 0, setIntervalFound.join(', '));
    check('Bosqich 3 komponentlari: to\'g\'ridan-to\'g\'ri fetch() YO\'Q',
      fetchFound.length === 0, fetchFound.join(', '));
    check('Bosqich 3 komponentlari: v-html YO\'Q (XSS xavfsizlik)',
      vhtmlFound.length === 0, vhtmlFound.join(', '));
  });

  // ===========================================================
  // Labels — yangi statuslar
  // ===========================================================
  await section('Labels — Bosqich 3 statuslari', async () => {
    const dom = bootDom();
    await waitForBoot(dom.window, w => w.Adminbot && w.Adminbot.Core && w.Adminbot.Core.Labels);
    const L = dom.window.Adminbot.Core.Labels;

    check('TABLE_STATUS mavjud', !!L.TABLE_STATUS && !!L.TABLE_STATUS.free);
    check('APPOINTMENT_STATUS mavjud', !!L.APPOINTMENT_STATUS && !!L.APPOINTMENT_STATUS.scheduled);
    check('PRODUCTION_STAGE mavjud', !!L.PRODUCTION_STAGE && !!L.PRODUCTION_STAGE.brief_review);
    check('COURIER_STATUS mavjud', !!L.COURIER_STATUS && !!L.COURIER_STATUS.available);

    check('formatStatus(\'free\', \'table\')',
      L.formatStatus('free', 'table').label === 'Bo\'sh');
    check('formatStatus(\'scheduled\', \'appointment\')',
      L.formatStatus('scheduled', 'appointment').label === 'Belgilangan');
    check('formatStatus(\'design\', \'production\')',
      L.formatStatus('design', 'production').label === 'Dizayn');
    check('formatStatus(\'on_route\', \'courier\')',
      L.formatStatus('on_route', 'courier').label === 'Yo\'lda');

    check('listStatuses(\'table\') 4 ta', L.listStatuses('table').length === 4);
    check('listStatuses(\'production\') 9 ta', L.listStatuses('production').length === 9);

    dom.window.close();
  });

  // === Yakuniy
  console.log(`\nNatija: ${pass} PASS / ${fail} FAIL`);
  if (failures.length) {
    console.log('FAIL detallari:');
    for (const f of failures) console.log('  -', f);
  }
  process.exit(fail > 0 ? 1 : 0);
})();
