/**
 * test_adapters_phase4.js — Bosqich 4 adapter testlari.
 *
 * 4 ta adapter (kuryerdan tashqari, u Bosqich 4'da yakunlanadi):
 *   - supplier
 *   - restaurant
 *   - appointment_service
 *   - custom_production
 *
 * Har biri uchun tekshiriladi:
 *   - Adapter ro'yxatga olingan, business_type to'g'ri
 *   - Sof deklarativ (function YO'Q — chuqur tekshiruv)
 *   - enabled_components mavjud komponentlarga ishora qiladi
 *   - routes komponentlari enabled_components ichida
 *   - InboxList data_source mavjud Service.method'ga ishora qiladi
 *   - status oqimi va labels mosligi
 *   - terms override Labels.formatStatus orqali ishlaydi
 */
const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const DIST = path.join(__dirname, '..', 'dist', 'index.html');
const html = fs.readFileSync(DIST, 'utf8');

let pass = 0, fail = 0;
function check(name, cond, detail = '') {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`); }
}

function bootDom(biz) {
  const vc = new VirtualConsole();
  vc.on('jsdomError', () => {});
  return new JSDOM(html, {
    runScripts: 'dangerously',
    url: `http://localhost:8000/?mock=true&tenant_id=tn_demo&biz=${biz}&role=owner&pin=off`,
    virtualConsole: vc,
  });
}
async function waitBoot(dom, predicate, ms = 2000) {
  const start = Date.now();
  while (Date.now() - start < ms) {
    try { if (predicate(dom.window)) return true; } catch (_) {}
    await new Promise(r => setTimeout(r, 50));
  }
  return false;
}

async function testAdapter(bizKey, label, opts) {
  console.log(`\n=== ${bizKey} adapter — ${label} ===`);
  const dom = bootDom(bizKey);
  await waitBoot(dom, w =>
    w.Adminbot && w.Adminbot.Business && w.Adminbot.Business[bizKey]);
  const adapter = dom.window.Adminbot.Business[bizKey];
  check(`Business.${bizKey} ro\'yxatga olingan`, !!adapter);
  if (!adapter) { dom.window.close(); return; }

  // Asosiy
  check(`business_type = '${bizKey}'`, adapter.business_type === bizKey);
  check(`label uzbek tilida`, typeof adapter.label === 'string' && adapter.label.length > 0);

  // Sof deklarativ — chuqur (har kalitda ham)
  const reg = dom.window.Adminbot.Core.BusinessRegistry;
  const purity = reg.validatePurity(adapter);
  check(`Adapter sof deklarativ (function YO'Q)`,
    purity.ok, purity.violations ? purity.violations.join('; ') : '');

  // enabled_components massiv
  check(`enabled_components massiv`, Array.isArray(adapter.enabled_components));

  // Routes massiv
  check(`routes massiv`, Array.isArray(adapter.routes));

  // BottomNav (asosiy) tab soni
  const mainRoutes = adapter.routes.filter(r => !r.secondary);
  check(`Asosiy routes (${opts.mainCount} ta)`, mainRoutes.length === opts.mainCount,
    `topildi: ${mainRoutes.length}`);

  // Settings asosiy routes ichida
  check(`Settings asosiy routes ichida`,
    mainRoutes.some(r => r.key === 'settings'));

  // Dashboard birinchi
  check(`Dashboard birinchi route`, mainRoutes[0] && mainRoutes[0].key === 'dashboard');

  // Routes komponentlari enabled_components ichida
  const enabledSet = new Set(adapter.enabled_components);
  const orphanRoutes = adapter.routes.filter(r =>
    !enabledSet.has(r.component) &&
    !['AuthGate', 'PinGate', 'LockScreen', 'BottomNav', 'RootShell'].includes(r.component)
  );
  check(`Barcha routes komponentlari enabled_components da`,
    orphanRoutes.length === 0,
    orphanRoutes.length ? orphanRoutes.map(r => r.key + '→' + r.component).join(', ') : '');

  // Adapter-spetsifik tekshiruvlar
  if (opts.extraChecks) opts.extraChecks(adapter, dom);

  dom.window.close();
}

(async () => {
  // === Supplier ===
  await testAdapter('supplier', 'B2B ulgurji', {
    mainCount: 5,                            // dashboard, orders, shops, catalog, settings
    extraChecks: (a, dom) => {
      const il = a.component_configs.InboxList;
      check('Supplier: shipped status BOR (B2B)',
        il.statuses.includes('shipped'));
      check('Supplier: on_delivery YO\'Q (B2B emas consumer)',
        !il.statuses.includes('on_delivery'));
      check('Supplier: delivered YO\'Q',
        !il.statuses.includes('delivered'));
      check('Supplier: 6 ta supplier-spetsifik komponent enabled',
        ['TierAssigner', 'CreditLimitManager', 'BalanceLedger',
         'BalanceOperation', 'InviteCodeGenerator', 'ShopApprover']
          .every(c => a.enabled_components.includes(c)));
      check('Supplier secondary routes: balance, credit, invites, pending bor',
        ['balance', 'credit', 'invites', 'pending'].every(k =>
          a.routes.some(r => r.key === k && r.secondary)));
      // OrderCard primary_actions B2B oqimi
      const oc = a.component_configs.OrderCard;
      check('Supplier OrderCard: accepted → shipped',
        oc.primary_actions.accepted && oc.primary_actions.accepted[0] === 'shipped');
    },
  });

  // === Restaurant ===
  await testAdapter('restaurant', 'Restoran', {
    mainCount: 5,                            // dashboard, reservations, tables, catalog, settings
    extraChecks: (a, dom) => {
      const il = a.component_configs.InboxList;
      check('Restaurant InboxList → reservations data_source',
        il.data_source.service === 'restaurant' &&
        il.data_source.method === 'listReservations');
      check('Restaurant InboxList status_kind = reservation',
        il.status_kind === 'reservation');
      check('Restaurant InboxList item_card = ReservationCard',
        il.item_card === 'ReservationCard');
      check('Reservation statuslari: requested, confirmed, seated, completed, cancelled, no_show',
        il.statuses.includes('requested') && il.statuses.includes('seated') &&
        il.statuses.includes('no_show'));
      check('Restaurant: tables route TableMap ga ishora',
        a.routes.find(r => r.key === 'tables').component === 'TableMap');
      check('Restaurant: banquets va hall_status secondary',
        ['banquets', 'hall_status'].every(k =>
          a.routes.some(r => r.key === k && r.secondary)));
      // ReservationCard extensions
      const rc = a.component_configs.ReservationCard;
      check('ReservationCard extensions: special_requests, deposit_status, party_info',
        rc.extensions.length === 3 &&
        rc.extensions.includes('special_requests') &&
        rc.extensions.includes('deposit_status') &&
        rc.extensions.includes('party_info'));
      // primary_actions
      check('ReservationCard: requested → confirmed',
        rc.primary_actions.requested[0] === 'confirmed');
      check('ReservationCard: seated → completed',
        rc.primary_actions.seated[0] === 'completed');
    },
  });

  // === Appointment service ===
  await testAdapter('appointment_service', 'Servis', {
    mainCount: 5,                            // dashboard, calendar, appointments, services, settings
    extraChecks: (a, dom) => {
      const il = a.component_configs.InboxList;
      check('Appointment InboxList → appointments data_source',
        il.data_source.service === 'appointment' &&
        il.data_source.method === 'listAppointments');
      check('Appointment status_kind = appointment',
        il.status_kind === 'appointment');
      check('Appointment item_card = AppointmentCard',
        il.item_card === 'AppointmentCard');
      check('Appointment statuslari: scheduled, in_progress, completed, cancelled, no_show',
        il.statuses.length === 5);
      check('Appointment: calendar route CalendarView',
        a.routes.find(r => r.key === 'calendar').component === 'CalendarView');
      check('Appointment: services route ServiceCRUD',
        a.routes.find(r => r.key === 'services').component === 'ServiceCRUD');
      check('Appointment: specialists, walkin secondary',
        ['specialists', 'walkin'].every(k =>
          a.routes.some(r => r.key === k && r.secondary)));
      // AppointmentCard primary_actions
      const ac = a.component_configs.AppointmentCard;
      check('AppointmentCard: scheduled → in_progress',
        ac.primary_actions.scheduled[0] === 'in_progress');
      check('AppointmentCard: in_progress → completed',
        ac.primary_actions.in_progress[0] === 'completed');
    },
  });

  // === Custom production ===
  await testAdapter('custom_production', 'Buyurtma ishlab chiqarish', {
    mainCount: 4,                            // dashboard, briefs, dispatches, settings — katalog YO'Q
    extraChecks: (a, dom) => {
      const il = a.component_configs.InboxList;
      check('Production InboxList → briefs data_source',
        il.data_source.service === 'production' &&
        il.data_source.method === 'listBriefs');
      check('Production status_kind = production',
        il.status_kind === 'production');
      check('Production status_field = stage (status emas)',
        il.status_field === 'stage');
      check('Production item_card = BriefCard',
        il.item_card === 'BriefCard');
      check('Production 9 ta bosqich + cancelled = 9 element (cancelled stage list ichida)',
        il.statuses.length === 9 &&
        il.statuses.includes('brief_review') &&
        il.statuses.includes('proposal_sent') &&
        il.statuses.includes('cancelled'));
      check('Production: katalog YO\'Q (statik mahsulot yo\'q)',
        !a.routes.some(r => r.key === 'catalog'));
      check('Production: briefs route InboxList',
        a.routes.find(r => r.key === 'briefs').component === 'InboxList');
      check('Production: dispatches route OnSiteDispatch',
        a.routes.find(r => r.key === 'dispatches').component === 'OnSiteDispatch');
      // BriefCard enabled
      check('BriefCard component enabled', a.enabled_components.includes('BriefCard'));
      check('TechBriefViewer enabled (route yo\'q lekin secondary navigatsiya uchun)',
        a.enabled_components.includes('TechBriefViewer'));
    },
  });

  // === Umumiy tekshiruvlar — barcha adapterlar bir vaqtning o'zida yuklanganda ===
  console.log('\n=== Umumiy registratsiya ===');
  const dom = bootDom('shop');           // shop bilan boot, lekin barcha adapter'lar yuklanadi
  await waitBoot(dom, w =>
    w.Adminbot && w.Adminbot.Business && Object.keys(w.Adminbot.Business).length >= 5);
  const list = dom.window.Adminbot.Core.BusinessRegistry.list();
  check('BusinessRegistry.list() 6 ta tur: shop, fastfood, supplier, restaurant, appointment_service, custom_production',
    list.length === 6 &&
    ['shop', 'fastfood', 'supplier', 'restaurant', 'appointment_service', 'custom_production']
      .every(b => list.includes(b)),
    `topildi: [${list.join(', ')}]`);
  check('Courier biznes turi adapter YO\'Q (LiveTracker hozircha tayyor emas)',
    !list.includes('courier_service'));

  // Har adapter purity (umumiy)
  const allPure = list.every(b => {
    const a = dom.window.Adminbot.Business[b];
    return dom.window.Adminbot.Core.BusinessRegistry.validatePurity(a).ok;
  });
  check('Barcha 6 adapter sof deklarativ', allPure);

  dom.window.close();

  // === Service.method mavjudligi tekshiruvi ===
  console.log('\n=== InboxList data_source — Service.method mavjud ===');
  const dom2 = bootDom('shop');
  await waitBoot(dom2, w => w.Adminbot && w.Adminbot.Core && w.Adminbot.Core.Services);
  const S = dom2.window.Adminbot.Core.Services;
  // Restaurant
  check('Services.restaurant.listReservations mavjud',
    S.restaurant && typeof S.restaurant.listReservations === 'function');
  // Appointment
  check('Services.appointment.listAppointments mavjud',
    S.appointment && typeof S.appointment.listAppointments === 'function');
  // Production
  check('Services.production.listBriefs mavjud',
    S.production && typeof S.production.listBriefs === 'function');
  dom2.window.close();

  console.log(`\nNatija: ${pass} PASS / ${fail} FAIL`);
  process.exit(fail > 0 ? 1 : 0);
})();
