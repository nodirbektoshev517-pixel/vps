/**
 * test_bosqich_2_rest.js — Bosqich 2.2-2.5 testlari.
 *
 * 2.2 Katalog: ImageUploader, CategoryCRUD, ProductCRUD, VariantsBlock, AddonsBlock
 * 2.3 Mijozlar va hisobot: CustomerList, CustomerProfile, ReportsView, OrdersHistoryBlock
 * 2.4 Boshqaruv: NotificationsBroadcast, EventsLog, StaffManager full CRUD
 * 2.5 Supplier: BalanceLedger, BalanceOperation, TierAssigner, CreditLimitManager,
 *               InviteCodeGenerator, ShopApprover
 */
const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const ROOT = path.resolve(__dirname, '..');
const HTML_PATH = path.join(ROOT, 'dist', 'index.html');
const HTML = fs.readFileSync(HTML_PATH, 'utf8');

let passed = 0, failed = 0;
const failures = [];

function check(name, cond, detail) {
  if (cond) { passed++; console.log(`  ✓ ${name}`); }
  else { failed++; failures.push({ name, detail }); console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`); }
}

async function withDom(url, fn) {
  const vc = new VirtualConsole();
  vc.on('jsdomError', () => {});
  const dom = new JSDOM(HTML, {
    runScripts: 'dangerously',
    url,
    pretendToBeVisual: true,
    virtualConsole: vc,
    resources: 'usable',
  });
  await new Promise(r => setTimeout(r, 700));
  try { await fn(dom); }
  finally { dom.window.close(); }
}

async function section(title, fn) {
  console.log(`\n— ${title} —`);
  await fn();
}

(async () => {
  console.log('=== Bosqich 2.2-2.5 testlari ===');

  // === 2.2 KATALOG ===
  await withDom('http://localhost/?mock=true&role=owner', async (dom) => {
    await section('2.2 Services.catalog — kategoriyalar', async () => {
      const S = dom.window.Adminbot.Core.Services;
      const r = await S.catalog.listCategories();
      check('listCategories items qaytadi', r && Array.isArray(r.items) && r.items.length > 0);
      check('Kategoriyada products_count maydoni bor', r.items[0].products_count != null);

      const created = await S.catalog.createCategory({ name: 'Test kat', icon: '🧪' });
      check('createCategory id qaytaradi', !!created.id);

      const updated = await S.catalog.updateCategory(created.id, { name: 'Yangi nom' });
      check('updateCategory ishlaydi', updated.name === 'Yangi nom');

      await S.catalog.deleteCategory(created.id);
      const r2 = await S.catalog.listCategories();
      check('deleteCategory bajarildi', !r2.items.find(c => c.id === created.id));

      // O'chirib bo'lmaydigan kategoriya — products_count > 0
      const withProducts = r.items.find(c => c.products_count > 0);
      let bad = null;
      try { await S.catalog.deleteCategory(withProducts.id); }
      catch (e) { bad = e; }
      check('Mahsulotli kategoriya o\'chirilmaydi (409)', bad && bad.status === 409);
    });

    await section('2.2 Services.catalog — mahsulotlar', async () => {
      const S = dom.window.Adminbot.Core.Services;
      const cats = await S.catalog.listCategories();
      const catId = cats.items[0].id;

      const r = await S.catalog.listProducts({ category_id: catId, page_size: 20 });
      check('listProducts pagination qaytaradi',
        r && Array.isArray(r.items) && r.items.length <= 20);
      check('Faqat tanlangan kategoriya mahsulotlari',
        r.items.every(p => p.category_id === catId));

      const created = await S.catalog.createProduct({
        category_id: catId,
        name: 'Test mahsulot',
        price: 25000,
        status: 'active',
      });
      check('createProduct id qaytaradi', !!created.id);

      // 422 - bo'sh name
      let bad = null;
      try { await S.catalog.createProduct({ category_id: catId, price: 1000 }); }
      catch (e) { bad = e; }
      check('Mahsulot nomi majburiy (422)', bad && bad.status === 422);

      await S.catalog.deleteProduct(created.id);
    });

    await section('2.2 ImageUploader — MIME va hajm validatsiya', async () => {
      const S = dom.window.Adminbot.Core.Services;
      const r = await S.catalog.uploadImage('data:image/png;base64,iVBORw0KGgo=');
      check('uploadImage url qaytaradi', !!r.url);

      let bad = null;
      try { await S.catalog.uploadImage(''); }
      catch (e) { bad = e; }
      check('Bo\'sh data_url 422', bad && bad.status === 422);
    });

    await section('2.2 CategoryCRUD render', async () => {
      const w = dom.window;
      w.Adminbot.Core.Router.go('catalog');
      await new Promise(r => setTimeout(r, 300));

      const list = w.document.querySelector('[data-component="category-list"]');
      check('CategoryCRUD list render bo\'ldi', !!list);
      const cats = w.document.querySelectorAll('[data-category-id]');
      check('Kategoriya kartochkalari bor', cats.length > 0);

      // Add tugma owner uchun chiqishi kerak
      const addBtn = w.document.querySelector('[data-action="add-category"]');
      check('Owner uchun "+ Yangi" tugma bor', !!addBtn);

      // Edit modal ochiladi
      addBtn.click();
      await new Promise(r => setTimeout(r, 100));
      const form = w.document.querySelector('[data-component="category-form"]');
      check('Yangi kategoriya formasi ochildi', !!form);

      // Cancel
      const cancel = form.querySelector('.btn.btn--secondary');
      cancel.click();
      await new Promise(r => setTimeout(r, 100));
      check('Cancel formani yopadi',
        !w.document.querySelector('[data-component="category-form"]'));
    });

    await section('2.2 ProductCRUD subview', async () => {
      const w = dom.window;
      w.Adminbot.Core.Router.go('catalog');
      await new Promise(r => setTimeout(r, 300));

      // Bosh kategoriyaga kirish
      const cat = w.document.querySelector('[data-category-id]');
      cat.click();
      await new Promise(r => setTimeout(r, 300));

      const productList = w.document.querySelector('[data-component="product-list"]');
      check('ProductCRUD subview ochildi', !!productList);

      const products = w.document.querySelectorAll('[data-product-id]');
      check('Mahsulotlar render bo\'ldi', products.length > 0);
      check('Birinchi sahifada ≤20 item (performance)', products.length <= 20);

      // Status badge bor
      const badge = products[0].querySelector('.badge');
      check('Mahsulot status badge\'i bor', !!badge);

      // Back tugma
      const back = w.document.querySelector('[data-action="back"]');
      check('Back tugma bor', !!back);
      back.click();
      await new Promise(r => setTimeout(r, 200));
      check('Back kategoriyalarga qaytardi',
        !!w.document.querySelector('[data-component="category-list"]'));
    });

    await section('2.2 ProductCRUD — variants/addons extensions', async () => {
      const w = dom.window;
      // Adapter ProductCRUD.extensions: ['variants', 'addons'] — extension komponentlari bor
      check('VariantsBlock komponent global registr',
        !!w.Adminbot.Components.VariantsBlock);
      check('AddonsBlock komponent global registr',
        !!w.Adminbot.Components.AddonsBlock);

      w.Adminbot.Core.Router.go('catalog');
      await new Promise(r => setTimeout(r, 300));
      const cat = w.document.querySelector('[data-category-id]');
      cat.click();
      await new Promise(r => setTimeout(r, 300));
      const addBtn = w.document.querySelector('[data-action="add-product"]');
      addBtn.click();
      await new Promise(r => setTimeout(r, 200));

      const form = w.document.querySelector('[data-component="product-form"]');
      check('Mahsulot formasi ochildi', !!form);
      // Extension'lar form ichida
      const variants = form.querySelector('[data-ext="variants"]');
      const addons = form.querySelector('[data-ext="addons"]');
      check('VariantsBlock formada render bo\'ldi', !!variants);
      check('AddonsBlock formada render bo\'ldi', !!addons);
    });
  });

  // === 2.3 MIJOZLAR ===
  await withDom('http://localhost/?mock=true&role=owner', async (dom) => {
    await section('2.3 Services.customers', async () => {
      const S = dom.window.Adminbot.Core.Services;
      const r = await S.customers.list({ page_size: 20 });
      check('customers.list items', r && Array.isArray(r.items) && r.items.length > 0);
      check('Mijozda orders_count bor', r.items[0].orders_count != null);
      check('Birinchi sahifa ≤20 item', r.items.length <= 20);

      // Search
      const fname = r.items[0].first_name;
      const filtered = await S.customers.list({ q: fname.toLowerCase() });
      check('Search ism orqali ishlaydi',
        filtered.items.some(c => c.first_name === fname));

      const detail = await S.customers.get(r.items[0].id);
      check('customers.get orders_history qaytaradi',
        detail && Array.isArray(detail.orders_history));
    });

    await section('2.3 CustomerList render va search', async () => {
      const w = dom.window;
      w.Adminbot.Core.Router.go('customers');
      await new Promise(r => setTimeout(r, 300));

      check('CustomerList render bo\'ldi',
        !!w.document.querySelector('[data-component="customer-list"]'));
      const cards = w.document.querySelectorAll('[data-customer-id]');
      check('Mijoz kartalari render bo\'ldi', cards.length > 0);

      // Profile ochish
      cards[0].click();
      await new Promise(r => setTimeout(r, 300));
      check('CustomerProfile ochildi',
        !!w.document.querySelector('[data-component="customer-profile"]'));

      // OrdersHistory extension
      const history = w.document.querySelector('[data-ext="orders_history"]');
      check('OrdersHistoryBlock extension render bo\'ldi', !!history);
    });

    await section('2.3 Services.reports', async () => {
      const S = dom.window.Adminbot.Core.Services;
      const daily = await S.reports.fetch('daily_sales');
      check('daily_sales hisoboti olindi',
        daily && Array.isArray(daily.rows) && daily.rows.length > 0);
      check('daily_sales total bor', daily.total > 0);
      check('daily_sales format=money', daily.format === 'money');

      const top = await S.reports.fetch('top_products');
      check('top_products olindi', top && top.rows.length > 0);

      let bad = null;
      try { await S.reports.fetch('nonexistent'); }
      catch (e) { bad = e; }
      check('Mavjud bo\'lmagan key 404', bad && bad.status === 404);
    });

    await section('2.3 ReportsView render', async () => {
      const w = dom.window;
      w.Adminbot.Core.Router.go('reports');
      await new Promise(r => setTimeout(r, 400));
      check('ReportsView render bo\'ldi',
        !!w.document.querySelector('[data-component="reports-list"]'));
      const reports = w.document.querySelectorAll('[data-report-key]');
      check('Adapter ko\'rsatgan barcha hisobotlar render',
        reports.length === 3,    // daily_sales, top_products, customer_summary
        `topildi: ${reports.length}`);
    });
  });

  // === 2.4 BOSHQARUV ===
  await withDom('http://localhost/?mock=true&role=owner', async (dom) => {
    await section('2.4 Services.broadcast — validation va audit', async () => {
      const S = dom.window.Adminbot.Core.Services;

      // Qisqa xabar 422
      let bad = null;
      try { await S.broadcast.send({ message: 'hi', audience: 'all' }); }
      catch (e) { bad = e; }
      check('Qisqa xabar 422 qaytaradi', bad && bad.status === 422);

      // Muvaffaqiyatli yuborish
      const before = await S.audit.list({ page_size: 50 });
      const r = await S.broadcast.send({ message: 'Test broadcast xabari', audience: 'all' });
      check('Broadcast ok va sent_to bor', r && r.ok && r.sent_to > 0);

      // Audit log avtomatik yozildi
      const after = await S.audit.list({ page_size: 50 });
      check('Broadcast audit log\'ga yozildi',
        after.items.length > before.items.length);
      check('Eng yangi audit type=broadcast.sent',
        after.items[0].type === 'broadcast.sent');
    });

    await section('2.4 Services.audit — pagination va filter', async () => {
      const S = dom.window.Adminbot.Core.Services;
      const r = await S.audit.list({ page_size: 5 });
      check('Audit pagination ishlaydi', r.items.length === 5);
      check('has_more true', r.has_more);

      const filtered = await S.audit.list({ type: 'order.status_changed' });
      check('Type filter ishlaydi',
        filtered.items.every(a => a.type === 'order.status_changed'));
    });

    await section('2.4 EventsLog render va filter', async () => {
      const w = dom.window;
      w.Adminbot.Core.Router.go('audit');
      await new Promise(r => setTimeout(r, 300));
      check('EventsLog render bo\'ldi',
        !!w.document.querySelector('[data-component="events-log"]'));
      const audits = w.document.querySelectorAll('[data-audit-id]');
      check('Audit yozuvlari render', audits.length > 0);

      // Filter chip click
      const filterChip = w.document.querySelector('[data-type-filter="broadcast.sent"]');
      check('Type filter chip mavjud', !!filterChip);
      filterChip.click();
      await new Promise(r => setTimeout(r, 250));
      const active = w.document.querySelector('.chip--active');
      check('Active filter chip active class oldi',
        active && active.getAttribute('data-type-filter') === 'broadcast.sent');
    });

    await section('2.4 NotificationsBroadcast render', async () => {
      const w = dom.window;
      w.Adminbot.Core.Router.go('broadcast');
      await new Promise(r => setTimeout(r, 300));
      check('NotificationsBroadcast render bo\'ldi',
        !!w.document.querySelector('[data-component="broadcast-view"]'));
      const sendBtn = w.document.querySelector('[data-action="send-broadcast"]');
      check('Send tugma bor', !!sendBtn);
      check('Send tugma boshlang\'ich disabled (xabar bo\'sh)',
        sendBtn.disabled === true);

      const msgField = w.document.querySelector('[data-field="message"]');
      check('Message field bor', !!msgField);
    });

    await section('2.4 StaffManager full CRUD', async () => {
      const w = dom.window;
      w.Adminbot.Core.Router.go('staff');
      await new Promise(r => setTimeout(r, 300));

      const addBtn = w.document.querySelector('[data-action="add-staff"]');
      check('"+ Qo\'shish" tugma owner uchun bor', !!addBtn);

      addBtn.click();
      await new Promise(r => setTimeout(r, 100));
      const form = w.document.querySelector('[data-component="staff-form"]');
      check('Staff form ochildi', !!form);

      // Forma maydonlari
      check('first_name maydoni bor', !!form.querySelector('[data-field="first_name"]'));
      check('last_name maydoni bor', !!form.querySelector('[data-field="last_name"]'));
      check('role maydoni bor', !!form.querySelector('[data-field="role"]'));
      check('phone maydoni bor', !!form.querySelector('[data-field="phone"]'));

      // Cancel
      const cancel = form.querySelector('.btn.btn--secondary');
      cancel.click();
      await new Promise(r => setTimeout(r, 100));
      check('Forma yopildi',
        !w.document.querySelector('[data-component="staff-form"]'));
    });
  });

  // === 2.5 SUPPLIER ===
  await withDom('http://localhost/?mock=true&role=owner', async (dom) => {
    await section('2.5 Services.supplier — shops va balance', async () => {
      const S = dom.window.Adminbot.Core.Services;
      const r = await S.supplier.listShops();
      check('listShops items', r && r.items && r.items.length > 0);
      check('Do\'konda tier, credit_limit, balance bor',
        r.items[0].tier && r.items[0].credit_limit != null && r.items[0].balance != null);

      const bal = await S.supplier.listBalance({ page_size: 20 });
      check('listBalance items', bal && bal.items.length > 0);
      check('Operatsiyada before/after_balance bor (audit)',
        bal.items[0].before_balance != null && bal.items[0].after_balance != null);
      check('Operatsiyada actor_name (audit)', !!bal.items[0].actor_name);

      // Operatsiya qo'shish
      const shop = r.items[0];
      const op = await S.supplier.addBalanceOperation({
        shop_id: shop.id,
        shop_name: shop.name,
        operation_type: 'credit',
        amount: 100000,
        reason: 'Test',
      });
      check('addBalanceOperation yangi yozuv qaytaradi',
        op && op.id && op.after_balance === op.before_balance + 100000);
    });

    await section('2.5 Services.supplier — tier va credit limit', async () => {
      const S = dom.window.Adminbot.Core.Services;
      const r = await S.supplier.listShops();
      const shop = r.items[0];
      const oldTier = shop.tier;
      const newTier = oldTier === 'gold' ? 'platinum' : 'gold';

      const updated = await S.supplier.setTier(shop.id, newTier);
      check('setTier yangi tier qaytaradi', updated.tier === newTier);

      let bad = null;
      try { await S.supplier.setTier(shop.id, 'invalid'); }
      catch (e) { bad = e; }
      check('Noto\'g\'ri tier 422', bad && bad.status === 422);

      const limited = await S.supplier.setCreditLimit(shop.id, 15_000_000);
      check('setCreditLimit ishlaydi', limited.credit_limit === 15_000_000);

      let bad2 = null;
      try { await S.supplier.setCreditLimit(shop.id, -1000); }
      catch (e) { bad2 = e; }
      check('Manfiy limit 422', bad2 && bad2.status === 422);
    });

    await section('2.5 Services.supplier — invites va pending shops', async () => {
      const S = dom.window.Adminbot.Core.Services;
      const inv = await S.supplier.createInvite({
        tier_preset: 'silver',
        credit_limit_preset: 5_000_000,
      });
      check('createInvite kod qaytaradi', !!inv.code && inv.code.startsWith('INV-'));
      check('tier_preset saqlandi', inv.tier_preset === 'silver');

      const list = await S.supplier.listInvites();
      check('listInvites yangi kodni topadi',
        list.items.some(i => i.id === inv.id));

      await S.supplier.deleteInvite(inv.id);
      const list2 = await S.supplier.listInvites();
      check('deleteInvite o\'chiradi',
        !list2.items.some(i => i.id === inv.id));

      // Pending shops
      const pending = await S.supplier.listPendingShops();
      check('listPendingShops items', pending && pending.items.length > 0);

      const p = pending.items[0];
      const apr = await S.supplier.approveShop(p.id);
      check('approveShop ok', apr && apr.ok);

      const pending2 = await S.supplier.listPendingShops();
      check('Tasdiqlangan shop pending\'dan chiqdi',
        !pending2.items.some(x => x.id === p.id));
    });

    // Supplier komponentlari ham global registr (har biznes turida ishlatilishi mumkin)
    await section('2.5 Supplier komponentlari global registr', async () => {
      const Comps = dom.window.Adminbot.Components;
      check('BalanceLedger registr', !!Comps.BalanceLedger);
      check('BalanceOperation registr', !!Comps.BalanceOperation);
      check('TierAssigner registr', !!Comps.TierAssigner);
      check('CreditLimitManager registr', !!Comps.CreditLimitManager);
      check('InviteCodeGenerator registr', !!Comps.InviteCodeGenerator);
      check('ShopApprover registr', !!Comps.ShopApprover);
    });
  });

  // === STATIC: yangi komponentlar standartlari ===
  await (async () => {
    await section('Static: yangi komponentlar Variant 2 patternga mos', async () => {
      const opDir = path.join(ROOT, 'src/components/operational');
      const opFiles = fs.readdirSync(opDir).map(f => path.join(opDir, f));

      // Hech bir komponent setInterval ishlatmasligi kerak
      const intervalOffenders = [];
      // Hech bir komponent fetch'ni to'g'ridan ishlatmasligi kerak (Services orqali bo'lishi shart)
      const fetchOffenders = [];
      // Hech bir komponent location.search/hash ishlatmasligi shart (Startup orqali)
      const locationOffenders = [];
      // v-html taqiqlangan
      const vhtmlOffenders = [];

      for (const f of opFiles) {
        const txt = fs.readFileSync(f, 'utf8');
        if (/\bsetInterval\s*\(/.test(txt)) intervalOffenders.push(path.basename(f));
        // Faqat to'g'ridan-to'g'ri fetch() chaqirilishini topamiz, .fetch() method emas
        if (/(?:^|[^.\w])fetch\s*\(/.test(txt)) fetchOffenders.push(path.basename(f));
        if (/location\.(search|hash)/.test(txt)) locationOffenders.push(path.basename(f));
        if (/v-html/.test(txt)) vhtmlOffenders.push(path.basename(f));
      }
      check('Yangi komponentlarda setInterval YO\'Q',
        intervalOffenders.length === 0, intervalOffenders.join(','));
      check('Yangi komponentlarda to\'g\'ridan-to\'g\'ri fetch() YO\'Q',
        fetchOffenders.length === 0, fetchOffenders.join(','));
      check('Yangi komponentlarda location.search/hash YO\'Q',
        locationOffenders.length === 0, locationOffenders.join(','));
      check('Yangi komponentlarda v-html YO\'Q',
        vhtmlOffenders.length === 0, vhtmlOffenders.join(','));
    });

    await section('Static: adapter purity (function yo\'q)', async () => {
      const f = path.join(ROOT, 'src/business/shop/adapter.js');
      const txt = fs.readFileSync(f, 'utf8');
      // Faqat IIFE wrapper'ning ichidagi function topilishi kerak.
      // component_configs ichida hech qanday function bo'lmasligi kerak.
      const cfgMatch = txt.match(/component_configs\s*:\s*\{([\s\S]*?)\n\s{4}\}/);
      check('component_configs topildi', !!cfgMatch);
      if (cfgMatch) {
        const cfg = cfgMatch[1];
        check('component_configs ichida function YO\'Q',
          !/function\s*\(/.test(cfg) && !/=>\s*[\{\(]/.test(cfg));
      }
    });
  })();

  console.log('\n=========================');
  console.log(`Natija: ${passed} PASS / ${failed} FAIL`);
  if (failures.length) {
    console.log('\nFAIL detallari:');
    for (const f of failures) console.log(`  - ${f.name}` + (f.detail ? ` — ${f.detail}` : ''));
    process.exit(1);
  } else {
    console.log('Hammasi yashil ✓');
  }
})().catch(e => {
  console.error('Test runner crashed:', e);
  process.exit(2);
});
