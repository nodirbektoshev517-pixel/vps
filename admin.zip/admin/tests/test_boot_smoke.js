/**
 * BOOT SMOKE — to'liq boot oqimini har biznes turi uchun tekshiradi:
 *   AuthGate → /auth/telegram → /bootstrap → adapter → Router → BottomNav
 *
 * Maqsad: agar har qanday joyda kontrakt buzilsa
 * (kalit nomi mosligi, permission yo'qolishi, adapter null, ...)
 * BU TEST QULAB TUSHADI — jim emas.
 */
const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const DIST = path.join(__dirname, '..', 'dist', 'index.html');
const html = fs.readFileSync(DIST, 'utf8');

let pass = 0, fail = 0;
function check(name, cond, detail) {
  if (cond) { console.log('  \u2713 ' + name); pass++; }
  else { console.log('  \u2717 ' + name + (detail ? ' — ' + detail : '')); fail++; }
}

async function bootOnce(biz) {
  const vc = new VirtualConsole();
  const errors = [];
  vc.on('jsdomError', (e) => errors.push(e.message));
  vc.on('error', (...args) => errors.push(args.join(' ')));

  const url = `http://localhost:8000/?mock=true&tenant_id=tn_demo&biz=${biz}&role=owner&pin=off`;
  const dom = new JSDOM(html, { runScripts: 'dangerously', url, virtualConsole: vc });

  // Boot tugashini kutamiz (Runtime.ready === true)
  const start = Date.now();
  while (Date.now() - start < 3000) {
    if (dom.window.Adminbot && dom.window.Adminbot.Runtime && dom.window.Adminbot.Runtime.ready) break;
    await new Promise(r => setTimeout(r, 30));
  }

  const A = dom.window.Adminbot;
  const result = {
    ready: !!(A && A.Runtime && A.Runtime.ready),
    adapter: A && A.Runtime && A.Runtime.adapter ? A.Runtime.adapter.business_type : null,
    routesCount: A && A.Core && A.Core.Router ? A.Core.Router.routes.value.length : 0,
    visibleRoutes: [],
    sessionValid: false,
    errors,
  };

  if (A && A.Core && A.Core.Auth) {
    const check = A.Core.Auth.validateSession();
    result.sessionValid = check.ok;
    result.sessionErrors = check.errors;
  }

  if (A && A.Core && A.Core.Router && A.Core.Permissions) {
    result.visibleRoutes = A.Core.Router.routes.value
      .filter(r => !r.secondary && A.Core.Permissions.canRoute(r))
      .map(r => r.key);
  }

  dom.window.close();
  return result;
}

(async () => {
  const businessTypes = ['restaurant', 'shop', 'fastfood', 'appointment_service', 'supplier', 'custom_production'];

  for (const biz of businessTypes) {
    console.log(`\n=== ${biz} ===`);
    const r = await bootOnce(biz);

    check(`boot tugadi (Runtime.ready)`, r.ready,
      r.errors.length ? r.errors.slice(0, 2).join(' | ') : 'timeout');
    check(`adapter to'g'ri tanlandi (${biz})`, r.adapter === biz, `got: ${r.adapter}`);
    check(`session yaroqli`, r.sessionValid,
      r.sessionErrors ? r.sessionErrors.join('; ') : '');
    check(`route'lar mavjud (>0)`, r.routesCount > 0, `routes: ${r.routesCount}`);
    check(`BottomNav 2+ tugma ko'rsatadi`, r.visibleRoutes.length >= 2,
      `visible: [${r.visibleRoutes.join(', ')}]`);
    check(`BottomNav faqat "settings" bilan qolmagan`,
      !(r.visibleRoutes.length === 1 && r.visibleRoutes[0] === 'settings'),
      `visible: [${r.visibleRoutes.join(', ')}] — bu aynan o'sha xato simptomi!`);
  }

  console.log(`\nNatija: ${pass} PASS / ${fail} FAIL`);
  process.exit(fail === 0 ? 0 : 1);
})();
