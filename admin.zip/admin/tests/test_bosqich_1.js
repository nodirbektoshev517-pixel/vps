/**
 * test_bosqich_1.js — Bosqich 1 integratsiya testlari.
 *
 * Sinov nuqtalari (spec §20 va qo'shimcha prompt §20):
 *   1. dist/index.html jsdom'da yuklanadi
 *   2. Mock mode'da Telegram bo'lmasa ham boot tugaydi
 *   3. Bootstrap mock business_type qaytaradi
 *   4. Adapter routes BottomNav'da ko'rinadi
 *   5. Permission yo'q route yashiriladi
 *   6. setInterval kodda yo'q (no-polling)
 *   7. AdminEvents.connect/syncSince mavjud
 *   8. __mockPushEvent ishlaydi
 *   9. Duplicate event tashlaydi
 *   10. PIN backend (mock) orqali tasdiqlanadi (lokal hash emas)
 *   11. PIN noto'g'ri urinishda failed attempt
 *   12. PIN security_hold (423) lock holatiga olib keladi
 *   13. Backend 403 → permission_denied event
 *   14. Backend 401 → session_expired event → lock
 *   15. Adapter sof deklarativ (function yo'q)
 *   16. SettingsView faqat operativ sozlamalarga ega
 *   17. StaffManager mock orqali ro'yxat ko'rsatadi
 */

const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const ROOT = path.resolve(__dirname, '..');
const HTML_PATH = path.join(ROOT, 'dist', 'index.html');
const HTML = fs.readFileSync(HTML_PATH, 'utf8');

let passed = 0;
let failed = 0;
const failures = [];

function check(name, cond, detail) {
  if (cond) {
    passed++;
    console.log(`  ✓ ${name}`);
  } else {
    failed++;
    failures.push({ name, detail });
    console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`);
  }
}

function pass(name) { check(name, true); }

async function withDom(url, fn) {
  const vc = new VirtualConsole();
  // Faqat real xato va ogohlantirishlarni ko'rsatamiz
  vc.on('error', (e) => console.log('  [jsdom error]', e && e.message));
  vc.on('jsdomError', (e) => console.log('  [jsdom]', e && e.message));
  // Telegram CDN script tag jsdom'da yuklanmaydi (network) — bu OK
  const dom = new JSDOM(HTML, {
    runScripts: 'dangerously',
    url,
    pretendToBeVisual: true,
    virtualConsole: vc,
    resources: 'usable',
  });
  // Boot uchun kutish
  await new Promise(r => setTimeout(r, 600));
  try {
    await fn(dom);
  } finally {
    dom.window.close();
  }
}

async function section(title, fn) {
  console.log(`\n— ${title} —`);
  await fn();
}

(async () => {
  console.log('=== Bosqich 1 testlari ===');

  // 0. Static kod tekshiruvi (DOM ishga tushirilmasdan)
  await section('Static kod tekshiruvi', async () => {
    // setInterval ishlatilmaganligi (vendor Vue ichidagi yo'q — biz src/ ni tekshiramiz)
    const srcDir = path.join(ROOT, 'src');
    const files = [];
    function walk(d) {
      for (const e of fs.readdirSync(d, { withFileTypes: true })) {
        const p = path.join(d, e.name);
        if (e.isDirectory()) walk(p);
        else if (e.name.endsWith('.js')) files.push(p);
      }
    }
    walk(srcDir);

    let setIntervalCount = 0;
    const offenders = [];
    for (const f of files) {
      const txt = fs.readFileSync(f, 'utf8');
      // Komment'larni olib tashlash (sodda regex)
      const stripped = txt
        .replace(/\/\*[\s\S]*?\*\//g, '')
        .replace(/^\s*\/\/.*$/gm, '');
      const matches = stripped.match(/\bsetInterval\s*\(/g);
      if (matches) {
        setIntervalCount += matches.length;
        offenders.push(path.relative(ROOT, f));
      }
    }
    check(
      'src/**/*.js ichida setInterval ishlatilmagan',
      setIntervalCount === 0,
      offenders.length ? `topildi: ${offenders.join(', ')}` : '',
    );

    // Adapter sof deklarativ — function yo'q
    const shopAdapter = fs.readFileSync(
      path.join(ROOT, 'src/business/shop/adapter.js'), 'utf8'
    );
    // Adapter obyekt ichida value sifatida function: => yoki function() qidiramiz
    // (IIFE wrapper'idan tashqari)
    const adapterBody = shopAdapter.match(/window\.Adminbot\.Business\.shop\s*=\s*(\{[\s\S]*?\});/);
    check('shop adapter obyekti topildi', !!adapterBody);
    if (adapterBody) {
      const bodyStr = adapterBody[1];
      // ': function' yoki '=>' yoki 'function(' — adapter qiymatida function bo'lmasligi kerak
      const hasFn = /:\s*function\b/.test(bodyStr) || /=>\s*/.test(bodyStr);
      check('shop adapter ichida function YO\'Q (sof deklarativ)', !hasFn,
        hasFn ? 'function ifoda topildi' : '');
    }
  });

  // 1. Mock mode'da boot
  await withDom('http://localhost/?mock=true&tenant_id=test_t', async (dom) => {
    await section('Mock mode boot (Telegram yo\'q)', async () => {
      const w = dom.window;
      check('window.Adminbot mavjud', !!w.Adminbot);
      check('Vue yuklanган', !!w.Vue);
      check('Core.Auth mavjud', !!(w.Adminbot && w.Adminbot.Core.Auth));
      check('Core.Pin mavjud', !!(w.Adminbot && w.Adminbot.Core.Pin));
      check('Core.Events mavjud', !!(w.Adminbot && w.Adminbot.Core.Events));
      check('Core.Services mavjud', !!(w.Adminbot && w.Adminbot.Core.Services));
      check('BusinessRegistry mavjud', !!(w.Adminbot && w.Adminbot.Core.BusinessRegistry));

      // Boot tugaganligi
      check('Runtime.ready === true', w.Adminbot.Runtime.ready === true);
      check('Runtime.adapter o\'rnatilgan', !!w.Adminbot.Runtime.adapter);
      check('Adapter business_type = shop', w.Adminbot.Runtime.adapter &&
        w.Adminbot.Runtime.adapter.business_type === 'shop');

      // App mount bo'lganmi
      const app = w.document.querySelector('#app');
      check('#app DOM\'da mavjud', !!app);
      check('App shell render bo\'ldi', app && app.innerHTML.length > 100);
    });

    await section('Adapter va router', async () => {
      const w = dom.window;
      const nav = w.document.querySelector('.bottom-nav');
      check('BottomNav render bo\'ldi', !!nav);
      const navItems = w.document.querySelectorAll('.bottom-nav__item');
      check('BottomNav element\'lar bor', navItems.length > 0,
        `topildi: ${navItems.length}`);
      // Adapter 5 ta route bergan — owner permissions ['*'] bilan barchasi ko'rinishi kerak
      check('Owner barcha route\'lar (5)', navItems.length === 5,
        `kutilgan 5, topilgan ${navItems.length}`);
    });

    await section('AdminEvents API (no-polling, event-driven)', async () => {
      const w = dom.window;
      const E = w.Adminbot.Core.Events;
      check('Events.connect mavjud', typeof E.connect === 'function');
      check('Events.disconnect mavjud', typeof E.disconnect === 'function');
      check('Events.resume mavjud', typeof E.resume === 'function');
      check('Events.syncSince mavjud', typeof E.syncSince === 'function');
      check('Events.ack mavjud', typeof E.ack === 'function');
      check('Events.subscribe mavjud', typeof E.subscribe === 'function');
      check('Events.handleServerEvent mavjud', typeof E.handleServerEvent === 'function');
      check('Events.emitLocal mavjud', typeof E.emitLocal === 'function');
      check('Events.transports.MockEventTransport bor',
        !!(E.transports && E.transports.MockEventTransport));
      check('Events.transports.WebSocketEventTransport bor',
        !!(E.transports && E.transports.WebSocketEventTransport));
      check('Events.transports.SSEEventTransport bor',
        !!(E.transports && E.transports.SSEEventTransport));
      check('__mockPushEvent (mock transport) mavjud',
        typeof w.__mockPushEvent === 'function');
    });

    await section('Event push va idempotency', async () => {
      const w = dom.window;
      const E = w.Adminbot.Core.Events;
      let count = 0;
      const off = E.subscribe('order.created', () => { count++; });

      // 1-marta yuborish
      const ok1 = w.__mockPushEvent({
        id: 'evt_1', type: 'order.created', entity_id: 'ord_1', payload: {},
      });
      check('__mockPushEvent muvaffaqiyatli ishladi', ok1 === true);
      check('Event 1 marta keldi', count === 1, `count=${count}`);

      // Duplikat — tashlanishi kerak
      w.__mockPushEvent({
        id: 'evt_1', type: 'order.created', entity_id: 'ord_1', payload: {},
      });
      check('Duplikat event tashlandi (idempotency)', count === 1, `count=${count}`);

      // Boshqa ID — qabul qilinadi
      w.__mockPushEvent({
        id: 'evt_2', type: 'order.created', entity_id: 'ord_2', payload: {},
      });
      check('Yangi ID qabul qilindi', count === 2, `count=${count}`);

      off();
    });

    await section('Service layer (API endpoint abstraktsiyasi)', async () => {
      const w = dom.window;
      const S = w.Adminbot.Core.Services;
      check('Services.auth.telegramLogin', typeof S.auth.telegramLogin === 'function');
      check('Services.auth.verifyPin', typeof S.auth.verifyPin === 'function');
      check('Services.auth.setPin', typeof S.auth.setPin === 'function');
      check('Services.auth.removePin', typeof S.auth.removePin === 'function');
      check('Services.bootstrap.fetch', typeof S.bootstrap.fetch === 'function');
      check('Services.dashboard.fetch', typeof S.dashboard.fetch === 'function');
      check('Services.staff.list', typeof S.staff.list === 'function');
      check('Services.events.syncSince', typeof S.events.syncSince === 'function');
    });

    await section('Adapter purity (kod tekshiruvi runtime\'da)', async () => {
      const w = dom.window;
      const Reg = w.Adminbot.Core.BusinessRegistry;
      const adapter = Reg.get('shop');
      const v = Reg.validatePurity(adapter);
      check('shop adapter sof deklarativ', v.ok,
        v.violations && v.violations.length ? v.violations.join('; ') : '');
    });
  });

  // PIN test — `?pin=on` bilan boot
  await withDom('http://localhost/?mock=true&pin=on&pin_locked=on', async (dom) => {
    await section('PIN backend-verified (lokal hash emas)', async () => {
      const w = dom.window;
      // PIN ekrani ko'rinishi kerak
      const pinScreen = w.document.querySelector('.pin-screen');
      check('PIN screen ko\'rsatildi', !!pinScreen);

      // localStorage'da PIN hash YO'Q (lekin last_active va tenant bo'lishi mumkin)
      const pinInStorage = w.localStorage.getItem('adminbot.pin_hash');
      check('localStorage\'da PIN hash YO\'Q', pinInStorage == null,
        pinInStorage ? `topildi: ${pinInStorage.slice(0, 20)}...` : '');

      // Backend (mock) orqali tasdiqlash — to'g'ri PIN "1234"
      const result = await w.Adminbot.Core.Pin.verifyPin('1234');
      check('Mock PIN "1234" qabul qilindi', result && result.ok === true,
        JSON.stringify(result));

      // Noto'g'ri PIN
      const bad = await w.Adminbot.Core.Pin.verifyPin('9999');
      check('Noto\'g\'ri PIN rad etildi', bad && bad.ok === false,
        JSON.stringify(bad));
      check('attempts_left qaytarildi', bad && typeof bad.attempts_left === 'number');
    });

    await section('PIN security_hold (423)', async () => {
      const w = dom.window;
      // Mock holatini lock holatiga qo'yamiz
      const ms = w.__mockAuthState;
      check('__mockAuthState mavjud', !!ms);
      if (ms) {
        ms.locked = true;
        const lockResult = await w.Adminbot.Core.Pin.verifyPin('1234');
        check('Security_hold da PIN rad etildi', lockResult && lockResult.ok === false);
        // Pin state lockReason = 'security_hold' bo'lishi kerak
        await new Promise(r => setTimeout(r, 50));
        const ps = w.Adminbot.Core.Pin.getState();
        check('Pin.state.lockReason === security_hold',
          ps.lockReason === 'security_hold', `topildi: ${ps.lockReason}`);
        ms.locked = false; // tozalaymiz
      }
    });
  });

  // Permission test — staff role bilan
  await withDom('http://localhost/?mock=true&role=staff', async (dom) => {
    await section('Permission UX filter (staff role)', async () => {
      const w = dom.window;
      check('Boot tugadi', w.Adminbot.Runtime.ready === true);
      const session = w.Adminbot.Core.Auth.getSession();
      check('Role = staff', session.user && session.user.role === 'staff');
      check('Permissions bor', Array.isArray(session.permissions) && session.permissions.length > 0);
      check('Wildcard "*" yo\'q', !session.permissions.includes('*'));

      // can() funksiyasi
      const P = w.Adminbot.Core.Permissions;
      check('can("orders.view") = true (staff)', P.can('orders.view') === true);
      check('can("staff.manage") = false (staff)', P.can('staff.manage') === false);
      check('can("orders.update") = true', P.can('orders.update') === true);

      // BottomNav — staff ko'ra olmaydigan route'lar yashiriladi
      const navItems = w.document.querySelectorAll('.bottom-nav__item');
      // staff bor route'lar: dashboard(view), orders(view), settings(no perm).
      // catalog (catalog.view yo'q), staff (staff.view yo'q) — yashiriladi
      const visibleKeys = Array.from(navItems).map(el => el.getAttribute('data-route'));
      check('staff route yashirildi', !visibleKeys.includes('staff'),
        `ko'rinadi: ${visibleKeys.join(', ')}`);
      check('catalog route yashirildi', !visibleKeys.includes('catalog'),
        `ko'rinadi: ${visibleKeys.join(', ')}`);
      check('dashboard route ko\'rinadi', visibleKeys.includes('dashboard'));
      check('orders route ko\'rinadi', visibleKeys.includes('orders'));
      check('settings route ko\'rinadi (permission yo\'q)', visibleKeys.includes('settings'));

      // §20.8: permission yo'q action yashirilishi (staff.manage yo'q → "+ Qo'shish" yo'q)
      // Router.go('staff') ishlamaydi (route yashirilgan), shuning uchun
      // to'g'ridan-to'g'ri StaffManager render qilish uchun manual o'tamiz
      // Actually staff role'da staff route umuman yo'q, ammo can() tekshiruvi
      // komponent ichida ham bor — biz aniq DOM darajada tekshiramiz:
      // staff role can('staff.manage') = false bo'lishi kerak
      const canManage = P.can('staff.manage');
      check('§20.8: staff can("staff.manage") === false (action yashirilishi sababi)',
        canManage === false);
    });
  });

  // Backend xato kodlari — 401/403/423 ishlanishi
  await withDom('http://localhost/?mock=true', async (dom) => {
    await section('Backend xato kodlari', async () => {
      const w = dom.window;
      const E = w.Adminbot.Core.Events;
      const Services = w.Adminbot.Core.Services;

      // 401 — session_expired
      let got401 = false;
      E.on('api.session_expired', () => { got401 = true; });
      const err401 = new Error('401'); err401.status = 401;
      Services.handleApiError(err401);
      check('401 → api.session_expired event', got401);

      // 403 — permission_denied
      let got403 = false;
      E.on('api.permission_denied', () => { got403 = true; });
      const err403 = new Error('403'); err403.status = 403;
      Services.handleApiError(err403);
      check('403 → api.permission_denied event', got403);

      // 423 — security_hold
      let got423 = false;
      E.on('api.security_hold', () => { got423 = true; });
      const err423 = new Error('423'); err423.status = 423;
      Services.handleApiError(err423);
      check('423 → api.security_hold event', got423);

      // PIN lock holatiga o'tdi (security_hold subscribe orqali)
      await new Promise(r => setTimeout(r, 50));
      const ps = w.Adminbot.Core.Pin.getState();
      check('423 dan keyin Pin lock holatida',
        ps.lockReason === 'security_hold' || ps.lockReason === 'session_expired',
        `lockReason: ${ps.lockReason}`);
    });
  });

  // Dashboard va Staff render testi
  await withDom('http://localhost/?mock=true', async (dom) => {
    await section('Dashboard render (stat-card\'lar)', async () => {
      const w = dom.window;
      // Dashboard'ga o'tamiz (router)
      w.Adminbot.Core.Router.go('dashboard');
      await new Promise(r => setTimeout(r, 250));
      const grid = w.document.querySelector('[data-component="dashboard-stats"]');
      check('Dashboard stat-grid render bo\'ldi', !!grid);
      const cards = w.document.querySelectorAll('[data-stat]');
      check('Stat kartochkalar yaratildi', cards.length >= 3,
        `topildi: ${cards.length}`);
      // Adapter dashboardstat_cards: 4 ta kalit — todays_orders, new_orders, revenue, customers
      const keys = Array.from(cards).map(c => c.getAttribute('data-stat'));
      check('todays_orders ko\'rsatildi', keys.includes('todays_orders'));
      check('revenue ko\'rsatildi', keys.includes('revenue'));
    });

    await section('StaffManager render (mock list)', async () => {
      const w = dom.window;
      w.Adminbot.Core.Router.go('staff');
      await new Promise(r => setTimeout(r, 250));
      const list = w.document.querySelector('[data-component="staff-list"]');
      check('Staff list render bo\'ldi', !!list);
      const rows = w.document.querySelectorAll('[data-staff-id]');
      check('Staff qatorlari yaratildi', rows.length === 4,
        `kutilgan 4, topilgan ${rows.length}`);
      // §20.8: owner uchun "+ Qo'shish" tugmasi ko'rinadi
      const addBtn = w.document.querySelector('[data-action="add-staff"]');
      check('Owner uchun "+ Qo\'shish" tugmasi ko\'rinadi', !!addBtn);
    });

    await section('Resume sync (visibilitychange → syncSince)', async () => {
      const w = dom.window;
      const E = w.Adminbot.Core.Events;
      const Services = w.Adminbot.Core.Services;
      // syncSince chaqirilganini track qilamiz
      let syncCalls = 0;
      const origSync = Services.events.syncSince;
      Services.events.syncSince = async (cursor) => {
        syncCalls++;
        return origSync(cursor);
      };
      // connect bo'lgan bo'lishi kerak (boot vaqtida)
      check('Events ulangan', E.isConnected() === true);

      // visibilitychange hidden → visible simulyatsiya
      Object.defineProperty(w.document, 'visibilityState', {
        configurable: true, get: () => 'visible',
      });
      const ev = new w.Event('visibilitychange');
      w.document.dispatchEvent(ev);
      await new Promise(r => setTimeout(r, 100));
      check('visibilitychange syncSince ni chaqirdi', syncCalls > 0,
        `syncCalls=${syncCalls}`);
      Services.events.syncSince = origSync;
    });
  });

  // === Bosqich 1.6 — JS optimizatsiya va xavfsizlik ===

  // 1.6.A: Static security va kod tahlili
  await section('Static security tekshiruvi (Bosqich 1.6)', async () => {
    const srcDir = path.join(ROOT, 'src');
    const files = [];
    function walk(d) {
      for (const e of fs.readdirSync(d, { withFileTypes: true })) {
        const p = path.join(d, e.name);
        if (e.isDirectory()) walk(p);
        else if (e.name.endsWith('.js')) files.push(p);
      }
    }
    walk(srcDir);

    // Komment'lar va string'lardagi tasodifiy mosliklarni minimallashtirish:
    // faqat token boshlanishi `bo'lmagan` joydan boshlanadigan
    function strip(txt) {
      return txt
        .replace(/\/\*[\s\S]*?\*\//g, '')
        .replace(/^\s*\/\/.*$/gm, '');
    }

    function findOffenders(pattern, allowFiles = []) {
      const offenders = [];
      for (const f of files) {
        const rel = path.relative(ROOT, f);
        if (allowFiles.includes(rel)) continue;
        const txt = strip(fs.readFileSync(f, 'utf8'));
        if (pattern.test(txt)) offenders.push(rel);
      }
      return offenders;
    }

    // v-html taqiqlangan
    const vhtml = findOffenders(/\bv-html\b/);
    check('v-html ishlatilmagan (taqiqlangan)', vhtml.length === 0,
      vhtml.length ? `topildi: ${vhtml.join(', ')}` : '');

    // innerHTML/outerHTML/insertAdjacentHTML taqiqlangan
    const innerHTML = findOffenders(/\.(innerHTML|outerHTML|insertAdjacentHTML)\s*=/);
    check('innerHTML/outerHTML/insertAdjacentHTML ishlatilmagan',
      innerHTML.length === 0,
      innerHTML.length ? `topildi: ${innerHTML.join(', ')}` : '');

    // eval va new Function taqiqlangan
    const evalUse = findOffenders(/\beval\s*\(|new\s+Function\s*\(/);
    check('eval/new Function ishlatilmagan', evalUse.length === 0,
      evalUse.length ? `topildi: ${evalUse.join(', ')}` : '');

    // location.search/hash faqat startup.js va router.js'da
    // (router.js hash-asoslangan router uchun zarur)
    const locUse = findOffenders(
      /\blocation\.(search|hash)\b/,
      ['src/core/startup.js', 'src/core/router.js'],
    );
    check('location.search/hash faqat startup.js va router.js\'da',
      locUse.length === 0,
      locUse.length ? `boshqa joyda: ${locUse.join(', ')}` : '');

    // setInterval butun src'da yo'q (Bosqich 1'dan)
    const intervalUse = findOffenders(/\bsetInterval\s*\(/);
    check('setInterval ishlatilmagan (Bosqich 1\'dan)', intervalUse.length === 0,
      intervalUse.length ? `topildi: ${intervalUse.join(', ')}` : '');
  });

  // 1.6.B: Production build mocks yo'qligi
  await section('Production build mocks chiqarib tashlanganligi', async () => {
    const distFile = HTML;
    // Mocks.register chaqiruvlari faqat docstring/komentariy bo'lib
    // qolganligi (real chaqiruv emas) — dev build'da bor bo'lishi mumkin.
    // Prod build alohida sinov:
    const { execSync } = require('child_process');
    const tmpOut = '/tmp/adminbot_prod_test.html';
    try {
      execSync('python3 build.py --mode=prod', { cwd: ROOT, stdio: 'pipe' });
      const prodHtml = fs.readFileSync(path.join(ROOT, 'dist', 'index.html'), 'utf8');

      // 1. Prod flag bor
      check('Prod buildda __ADMINBOT_PROD__ = true',
        /__ADMINBOT_PROD__\s*=\s*true/.test(prodHtml));

      // 2. Mock register chaqiruvi YO'Q (faqat docstring qolishi mumkin)
      // Real `M.register(...)` chaqiruvlari — mocks/*.js fayllarida edi
      const mockRegisterCalls = (prodHtml.match(/^\s*M\.register\(/gm) || []).length;
      check('Prod buildda M.register(...) chaqiruvlari yo\'q',
        mockRegisterCalls === 0,
        `topildi: ${mockRegisterCalls}`);

      // 3. window.__mockAuthState, __mockStaffState bo'lmasin
      check('Prod buildda __mockAuthState yo\'q',
        !/__mockAuthState\s*=/.test(prodHtml));
      check('Prod buildda __mockStaffState yo\'q',
        !/__mockStaffState\s*=/.test(prodHtml));

      // Dev build'ni qaytarib o'rnatamiz
      execSync('python3 build.py', { cwd: ROOT, stdio: 'pipe' });
    } catch (e) {
      check('Prod build muvaffaqiyatli', false, e.message);
    }
  });

  // 1.6.C: Startup module xavfsizligi
  await withDom('http://localhost/?mock=true&tenant_id=test_t&biz=fastfood&role=manager', async (dom) => {
    await section('Startup module — allowlist ishlashi', async () => {
      const w = dom.window;
      const S = w.Adminbot.Core.Startup;
      check('Startup mavjud', !!S);
      check('Startup.init() ishlagan', S.params != null);
      check('tenant_id allowlist\'dan o\'tdi', S.get('tenant_id') === 'test_t');
      check('biz allowlist (fastfood)', S.get('biz') === 'fastfood');
      check('role allowlist (manager)', S.get('role') === 'manager');
      check('mock flag boolean', S.get('mock') === true);
      check('isDevHost() = true (localhost)', S.isDevHost() === true);
      check('isMockAllowed() = true', S.isMockAllowed() === true);
      check('buildMode = "dev"', S.buildMode === 'dev');
    });
  });

  // 1.6.D: Noto'g'ri URL parametrlar tashlanadi
  await withDom('http://localhost/?biz=invalid_biz&role=hacker&tenant_id=<script>&unknown_param=x', async (dom) => {
    await section('Startup — noto\'g\'ri parametrlar tashlanadi', async () => {
      const w = dom.window;
      const S = w.Adminbot.Core.Startup;
      check('Noto\'g\'ri biz tashlandi', S.get('biz') === undefined);
      check('Noto\'g\'ri role tashlandi', S.get('role') === undefined);
      check('XSS-shubhali tenant_id tashlandi', S.get('tenant_id') === undefined);
      check('Noma\'lum parametr o\'qilmadi', S.get('unknown_param') === undefined);
    });
  });

  // 1.6.E: Prod hostname'da dev paramlar tashlanadi (simulyatsiya)
  // jsdom URL = http://example.com/?mock=true → mock RUXSAT BERILMAYDI
  await withDom('http://example.com/?mock=true&role=owner', async (dom) => {
    await section('Production hostname\'da mock RUXSAT BERILMAYDI', async () => {
      const w = dom.window;
      const S = w.Adminbot.Core.Startup;
      check('isDevHost() = false (example.com)', S.isDevHost() === false);
      check('isMockAllowed() = false', S.isMockAllowed() === false);
      check('mock parametri tashlandi (dev_only)', S.get('mock') === undefined);
      check('role parametri tashlandi (dev_only)', S.get('role') === undefined);
      // Boot xato bo'lishi kerak — chunki real Telegram initData yo'q
      check('Mock mode auto-fallback BERILMADI', w.Adminbot.Core.Utils.isMockMode() === false);
    });
  });

  // 1.6.F: In-memory token (real mode)
  await withDom('http://example.com/', async (dom) => {
    await section('Real mode token in-memory (localStorage emas)', async () => {
      const w = dom.window;
      const Utils = w.Adminbot.Core.Utils;
      check('Mock mode YOQILMAGAN', Utils.isMockMode() === false);
      // Token o'rnatamiz
      Utils.setToken('test_token_abc');
      check('Token o\'qildi', Utils.getToken() === 'test_token_abc');
      // localStorage'da YO'Q (real mode'da in-memory)
      const inLs = w.localStorage.getItem('adminbot.token');
      check('Real mode tokeni localStorage\'da yo\'q', inLs == null,
        inLs ? `topildi: ${inLs.slice(0, 15)}...` : '');
      // Clear
      Utils.setToken(null);
      check('Token tozalandi', Utils.getToken() == null);
    });
  });

  // 1.6.G: Permissions.require()
  await withDom('http://localhost/?mock=true&role=staff', async (dom) => {
    await section('Permissions.require() — toast + boolean', async () => {
      const w = dom.window;
      const P = w.Adminbot.Core.Permissions;
      check('Permissions.require mavjud', typeof P.require === 'function');
      // Staff'da staff.manage yo'q
      const result1 = P.require('staff.manage', 'Xodim qo\'shish');
      check('require() permission yo\'q → false qaytaradi', result1 === false);
      // UI.toasts'da xabar paydo bo'ldi (Vue ref — .value bilan)
      const toasts = w.Adminbot.Core.UI.toasts;
      const toastsArr = toasts && (toasts.value || toasts);
      const toastCount = Array.isArray(toastsArr) ? toastsArr.length : 0;
      check('require() permission yo\'q → toast chiqdi', toastCount > 0,
        `toast count=${toastCount}`);

      // Permissions bor bo'lsa true qaytaradi va toast chiqarmaydi
      const result2 = P.require('orders.view', 'Buyurtmalarni ko\'rish');
      check('require() permission bor → true qaytaradi', result2 === true);
    });
  });

  // 1.6.H: runAction wrapper
  await withDom('http://localhost/?mock=true&role=owner', async (dom) => {
    await section('Actions.runAction() — permission + action + onSuccess', async () => {
      const w = dom.window;
      const A = w.Adminbot.Core.Actions;
      check('Actions.runAction mavjud', typeof A.runAction === 'function');

      // 1. Muvaffaqiyatli scenario
      let successCalled = false;
      const r1 = await A.runAction({
        permission: 'orders.view',
        action: async () => ({ id: 1, status: 'accepted' }),
        onSuccess: () => { successCalled = true; },
        silent: true,
      });
      check('runAction muvaffaqiyatli → ok: true',
        r1 && r1.ok === true);
      check('runAction onSuccess chaqirildi', successCalled === true);

      // 2. Permission yo'q scenario
      // Owner'da hammasi bor — staff.foo deb noma'lum perm berolmaymiz
      // (chunki * bor). Boshqa misol — silent: false bilan permission yo'q toast
      // Buni staff role bilan tekshiramiz, lekin owner DOM'da turibmiz.
      // Mock o'rniga oddiy permission tekshirish:
      const result2 = await A.runAction({
        permission: 'this.permission.never.exists',
        action: async () => 'should not run',
        silent: true,
      });
      // Owner '*' bilan — har qanday permission bor bo'ladi
      check('Owner uchun har permission true (wildcard)', result2.ok === true);

      // 3. Xato scenario
      let errorCalled = false;
      const r3 = await A.runAction({
        action: async () => { throw new Error('Mock xato'); },
        onError: () => { errorCalled = true; },
        silent: true,
      });
      check('runAction xato → ok: false', r3 && r3.ok === false);
      check('runAction onError chaqirildi', errorCalled === true);
      check('runAction error qaytarildi', r3.error instanceof Error);
    });
  });

  // 1.6.I: Labels module
  await withDom('http://localhost/?mock=true', async (dom) => {
    await section('Labels — yagona status/role mapping', async () => {
      const w = dom.window;
      const L = w.Adminbot.Core.Labels;
      check('Labels.formatStatus mavjud', typeof L.formatStatus === 'function');
      check('ORDER_STATUS jadval mavjud',
        L.ORDER_STATUS && L.ORDER_STATUS.new);
      check('"new" → label "Yangi"',
        L.formatStatus('new', 'order').label === 'Yangi');
      check('"new" → badge "warning"',
        L.formatStatus('new', 'order').badge === 'warning');
      check('"delivered" → label "Yetkazildi"',
        L.formatStatus('delivered', 'order').label === 'Yetkazildi');
      check('"delivered" → badge "success"',
        L.formatStatus('delivered', 'order').badge === 'success');
      check('Role: owner → "Egasi"',
        L.formatStatus('owner', 'role').label === 'Egasi');
      check('Role: courier → badge "warning"',
        L.formatStatus('courier', 'role').badge === 'warning');
      // Adapter terms override
      const overridden = L.formatStatus('delivered', 'order', { delivered: 'Yetib bordi' });
      check('Terms override ishlaydi',
        overridden.label === 'Yetib bordi' && overridden.badge === 'success');
      // Noma'lum kalit — neutral fallback
      const unknown = L.formatStatus('unknown_status', 'order');
      check('Noma\'lum kalit → neutral badge',
        unknown.badge === 'neutral');
    });
  });

  // 1.6.J: useEvents composable + Composables module
  await withDom('http://localhost/?mock=true', async (dom) => {
    await section('Composables.useEvents() mavjudligi', async () => {
      const w = dom.window;
      const C = w.Adminbot.Core.Composables;
      check('Composables.useEvents mavjud', !!(C && typeof C.useEvents === 'function'));
    });
  });

  // 1.6.K: PIN qulflanganda Events.connect() chaqirilmaydi
  await withDom('http://localhost/?mock=true&pin=on&pin_locked=on', async (dom) => {
    await section('Event ulanish: PIN unlock\'gacha CHAQIRILMAYDI', async () => {
      const w = dom.window;
      // PIN qulflangan, RootShell phase='pin' bo'lishi kerak
      const pinScreen = w.document.querySelector('.pin-screen');
      check('PIN screen ko\'rsatildi', !!pinScreen);
      // Events ulangan bo'lmasligi kerak
      const isConnected = w.Adminbot.Core.Events.isConnected();
      check('PIN qulflangan paytda Events.connect CHAQIRILMAGAN',
        isConnected === false, `isConnected=${isConnected}`);
    });
  });

  // 1.6.L: PIN ochilgandan keyin Events.connect chaqiriladi
  await withDom('http://localhost/?mock=true&pin=on&pin_locked=on', async (dom) => {
    await section('Event ulanish: PIN unlock\'dan keyin CHAQIRILADI', async () => {
      const w = dom.window;
      // PIN'ni ochamiz
      const result = await w.Adminbot.Core.Pin.verifyPin('1234');
      check('PIN ochildi', result && result.ok === true);
      // Phase 'app'ga o'tadi — watch ishlashini kutamiz
      await new Promise(r => setTimeout(r, 150));
      const isConnected = w.Adminbot.Core.Events.isConnected();
      check('PIN unlock\'dan keyin Events ulandi',
        isConnected === true, `isConnected=${isConnected}`);
    });
  });

  // §1.5: Design tizimi yaxlitligi (oldingi testlar)
  await section('Design tizimi (Bosqich 1.5)', async () => {
    // CSS faylda tokenlar mavjud
    const dist = HTML;
    check('CSS token: --color-primary aniqlangan',
      /--color-primary\s*:/.test(dist));
    check('CSS token: --space-4 aniqlangan',
      /--space-4\s*:/.test(dist));
    check('CSS token: --radius-md aniqlangan',
      /--radius-md\s*:/.test(dist));
    check('CSS token: --touch aniqlangan',
      /--touch\s*:/.test(dist));
    check('CSS token: --text-base aniqlangan',
      /--text-base\s*:/.test(dist));

    // Yangi primitivlar mavjud
    check('Primitive: .btn aniqlangan', /\.btn\s*\{/.test(dist));
    check('Primitive: .card aniqlangan', /\.card\s*\{/.test(dist));
    check('Primitive: .stack aniqlangan', /\.stack\s*\{/.test(dist));
    check('Primitive: .cluster aniqlangan', /\.cluster\s*\{/.test(dist));
    check('Primitive: .heading aniqlangan', /\.heading\s*\{/.test(dist));
    check('Primitive: .chip aniqlangan', /\.chip\s*\{/.test(dist));

    // Eski klasslar yo'q (refaktor toza)
    const oldClasses = [
      '\\.page__title\\s*\\{',
      '\\.page__subtitle\\s*\\{',
      '\\.section__title\\s*\\{',
      '\\.between\\s*\\{',
      '\\.top-bar__btn\\s*\\{',
      '\\.stat-grid\\s*\\{',
      '\\.stat-card\\s*\\{',
    ];
    let oldFound = [];
    for (const pat of oldClasses) {
      if (new RegExp(pat).test(dist)) oldFound.push(pat.replace(/\\/g, ''));
    }
    check('Eski klasslar CSS\'da yo\'q (refaktor toza)',
      oldFound.length === 0,
      oldFound.length ? `qoldi: ${oldFound.join(', ')}` : '');

    // Komponentlar yangi klasslarni ishlatadi (HTML template'da)
    check('Dashboard yangi .heading klassini ishlatadi',
      dist.includes('class="heading">Bosh sahifa'));
    check('SettingsView yangi .heading klassini ishlatadi',
      dist.includes('class="heading">Sozlamalar'));
    check('StaffManager yangi .cluster--between ishlatadi',
      /\.cluster\s+\.cluster--between|cluster cluster--between/.test(dist));

    // Qattiq qiymatlar minimal (skeleton placeholder'lar uchun ozgina ruxsat)
    const hardcodedPx = (dist.match(/style="[^"]*\d+px[^"]*"/g) || []).length;
    check(
      `Inline qattiq px ishlatilishi cheklangan (topildi: ${hardcodedPx})`,
      hardcodedPx < 80,  // skeleton, avatar, image preview — Bosqich 3 keyin
      `${hardcodedPx} ta inline px topildi`,
    );
  });

  // §20.18: Telegram start_param route hint sifatida ishlanadi
  await section('Deep-link: start_param → route hint', async () => {
    const vc = new VirtualConsole();
    vc.on('jsdomError', () => {});
    const dom = new JSDOM(HTML, {
      runScripts: 'dangerously',
      url: 'http://localhost/?mock=true',
      pretendToBeVisual: true,
      virtualConsole: vc,
    });
    // jsdom Telegram script'ni yuklamaydi (network), shuning uchun
    // qo'lda mock Telegram WebApp obyekti yaratamiz BOOT'dan oldin
    dom.window.Telegram = {
      WebApp: {
        initData: 'mock_init_data',
        initDataUnsafe: { start_param: 'route:staff' },
        ready: () => {},
        expand: () => {},
        colorScheme: 'light',
        themeParams: {},
        onEvent: () => {},
        offEvent: () => {},
      },
    };
    await new Promise(r => setTimeout(r, 700));
    try {
      const w = dom.window;
      check('start_param o\'qildi', !!w.Adminbot.Runtime, '');
      // Boot tugagandan keyin Router 'staff' ga o'tgan bo'lishi kerak
      // (mock mode'da auth.login Telegram'siz mock fallback qiladi,
      //  shuning uchun start_param hint Runtime'ga yoziladi va RootShell oladi)
      // Boot uzunroq kutamiz
      await new Promise(r => setTimeout(r, 300));
      const cur = w.Adminbot.Core.Router.currentKey.value;
      check('start_param "route:staff" → Router.go("staff")',
        cur === 'staff', `currentKey=${cur}`);
    } finally {
      dom.window.close();
    }
  });

  // Yakuniy
  console.log('\n=========================');
  console.log(`Natija: ${passed} PASS / ${failed} FAIL`);
  if (failures.length) {
    console.log('\nFAIL detallari:');
    for (const f of failures) {
      console.log(`  - ${f.name}` + (f.detail ? ` — ${f.detail}` : ''));
    }
    process.exit(1);
  } else {
    console.log('Hammasi yashil ✓');
  }
})().catch(e => {
  console.error('Test runner crashed:', e);
  process.exit(2);
});
