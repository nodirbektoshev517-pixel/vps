/**
 * test_fastfood_adapter.js — fastfood adapter tezkor testi.
 *
 * Tekshiriladi:
 *   - Adapter ro'yxatga olingan (Business.fastfood)
 *   - Sof deklarativ (function YO'Q)
 *   - Routes va component_configs to'g'ri
 *   - BottomNav 4 ta tab (shop'dan kam)
 *   - delivery_address extension YO'Q (pickup biznes)
 *   - on_delivery va delivered statuslari YO'Q
 *   - CustomerList YO'Q (anonim mijozlar)
 */
const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const DIST = path.join(__dirname, '..', 'dist', 'index.html');
const html = fs.readFileSync(DIST, 'utf8');

let pass = 0, fail = 0;
function check(name, cond, detail = '') {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`); }
}

(async () => {
  const vc = new VirtualConsole();
  vc.on('jsdomError', () => {});
  const dom = new JSDOM(html, {
    runScripts: 'dangerously',
    url: 'http://localhost:8000/?mock=true&tenant_id=tn_demo&biz=fastfood&role=owner&pin=off',
    virtualConsole: vc,
  });

  // Boot kutish
  const start = Date.now();
  while (Date.now() - start < 2000) {
    if (dom.window.Adminbot && dom.window.Adminbot.Business && dom.window.Adminbot.Business.fastfood) break;
    await new Promise(r => setTimeout(r, 50));
  }

  console.log('\n=== Fastfood adapter — registratsiya va purity ===');
  const adapter = dom.window.Adminbot.Business.fastfood;
  check('Business.fastfood ro\'yxatga olingan', !!adapter);
  if (!adapter) { dom.window.close(); process.exit(1); }
  check('business_type to\'g\'ri', adapter.business_type === 'fastfood');
  check('label uzbek tilida', adapter.label === 'Fastfood');

  // BusinessRegistry orqali olish
  const reg = dom.window.Adminbot.Core.BusinessRegistry;
  check('Registry.get(\'fastfood\') ishlaydi', reg.get('fastfood') === adapter);
  check('Registry.list() fastfood ni o\'z ichiga oladi',
    reg.list().includes('fastfood'));

  // Purity tekshirish
  const purity = reg.validatePurity(adapter);
  check('Adapter sof deklarativ (function YO\'Q)',
    purity.ok, purity.violations ? purity.violations.join(', ') : '');

  console.log('\n=== Fastfood adapter — sodda tuzilish ===');
  check('enabled_components massiv', Array.isArray(adapter.enabled_components));
  check('CustomerList YO\'Q (anonim mijozlar)',
    !adapter.enabled_components.includes('CustomerList'));
  check('CustomerProfile YO\'Q', !adapter.enabled_components.includes('CustomerProfile'));
  check('AddressBlock YO\'Q (yetkazib berish yo\'q)',
    !adapter.enabled_components.includes('AddressBlock'));

  console.log('\n=== Fastfood routes (4 ta BottomNav + 4 ta secondary) ===');
  const mainRoutes = adapter.routes.filter(r => !r.secondary);
  const secRoutes = adapter.routes.filter(r => r.secondary);
  check('Asosiy routes 4 ta (dashboard, orders, catalog, settings)',
    mainRoutes.length === 4);
  check('Routes orasida \'customers\' YO\'Q',
    !adapter.routes.some(r => r.key === 'customers'));
  check('Secondary routes 4 ta (reports, broadcast, staff, audit)',
    secRoutes.length === 4);

  console.log('\n=== OrderCard konfiguratsiyasi ===');
  const oc = adapter.component_configs.OrderCard;
  check('OrderCard delivery_address extension YO\'Q',
    !oc.extensions.includes('delivery_address'));
  check('OrderCard payment_method extension BOR',
    oc.extensions.includes('payment_method'));
  check('OrderCard note extension BOR', oc.extensions.includes('note'));
  check('primary_actions[\'ready\'] → completed (delivery oraliq YO\'Q)',
    oc.primary_actions.ready[0] === 'completed');
  check('primary_actions[\'on_delivery\'] YO\'Q',
    !oc.primary_actions.on_delivery);

  console.log('\n=== InboxList statuslari ===');
  const il = adapter.component_configs.InboxList;
  check('Statuslar orasida \'on_delivery\' YO\'Q',
    !il.statuses.includes('on_delivery'));
  check('Statuslar orasida \'delivered\' YO\'Q',
    !il.statuses.includes('delivered'));
  check('Statuslar: new, accepted, preparing, ready, completed, cancelled (6 ta)',
    il.statuses.length === 6 && il.statuses.includes('completed'));

  console.log('\n=== Terms override ===');
  check('CategoryCRUD: "Menyu" termi (Katalog emas)',
    adapter.component_configs.CategoryCRUD.terms.catalog === 'Menyu');
  check('ProductCRUD: "Taom" termi (Mahsulot emas)',
    adapter.component_configs.ProductCRUD.terms.item === 'Taom');
  check('OrderCard ready label override',
    oc.terms && oc.terms.ready === 'Olib ketishga tayyor');

  console.log('\n=== Reports ===');
  const r = adapter.component_configs.ReportsView;
  check('Reports orasida customer_summary YO\'Q (anonim)',
    !r.reports.includes('customer_summary'));
  check('Reports hourly_load BOR (fastfood uchun foydali)',
    r.reports.includes('hourly_load'));

  // Labels integratsiya — terms override ishlaydimi
  console.log('\n=== Labels terms override ===');
  const Labels = dom.window.Adminbot.Core.Labels;
  const readyLabel = Labels.formatStatus('ready', 'order', oc.terms);
  check('Labels.formatStatus terms override qabul qiladi',
    readyLabel.label === 'Olib ketishga tayyor' && readyLabel.badge === 'info');

  console.log(`\nNatija: ${pass} PASS / ${fail} FAIL`);
  dom.window.close();
  process.exit(fail > 0 ? 1 : 0);
})();
