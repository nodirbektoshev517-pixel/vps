/**
 * test_bosqich_2_1.js — Bosqich 2.1 — Inbox bloki testlari.
 *
 * Sinov nuqtalari:
 *   1. Inbox mock pagination (page_size=20, cursor)
 *   2. Status update mock (status transition, 409 noto'g'ri transition'da)
 *   3. OrderStatusBadge — Labels'dan label/badge oladi
 *   4. OrderCard render (extensions, status badge, primary action)
 *   5. Extension komponentlari (AddressBlock, PaymentBlock, NoteBlock)
 *   6. InboxList — filter chip'lar, pagination, "Yana yuklash"
 *   7. Real-time: __mockPushEvent order.created → ro'yxatga prepend
 *   8. Real-time: order.status_changed → mavjud item yangilanadi
 *   9. Idempotency: bir xil event ikki marta → faqat bir marta qo'shiladi
 *   10. Performance: birinchi yuklash 20 ta itemdan oshmaydi
 *   11. Adapter terms — label override ishlaydi
 *   12. useEvents auto-cleanup — komponent unmount qilinsa listener tozalanadi
 */

const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const ROOT = path.resolve(__dirname, '..');
const HTML_PATH = path.join(ROOT, 'dist', 'index.html');
const HTML = fs.readFileSync(HTML_PATH, 'utf8');

let passed = 0;
let failed = 0;
const failures = [];

function check(name, cond, detail) {
  if (cond) { passed++; console.log(`  ✓ ${name}`); }
  else {
    failed++;
    failures.push({ name, detail });
    console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`);
  }
}

async function withDom(url, fn) {
  const vc = new VirtualConsole();
  vc.on('jsdomError', () => {});
  const dom = new JSDOM(HTML, {
    runScripts: 'dangerously',
    url,
    pretendToBeVisual: true,
    virtualConsole: vc,
    resources: 'usable',
  });
  await new Promise(r => setTimeout(r, 700));
  try { await fn(dom); }
  finally { dom.window.close(); }
}

async function section(title, fn) {
  console.log(`\n— ${title} —`);
  await fn();
}

(async () => {
  console.log('=== Bosqich 2.1 — Inbox bloki testlari ===');

  // 1. Services.inbox mock
  await withDom('http://localhost/?mock=true&role=owner', async (dom) => {
    await section('Services.inbox — pagination', async () => {
      const w = dom.window;
      const S = w.Adminbot.Core.Services;
      check('Services.inbox.list mavjud', typeof S.inbox.list === 'function');
      check('Services.inbox.updateStatus mavjud', typeof S.inbox.updateStatus === 'function');

      // Birinchi sahifa
      const page1 = await S.inbox.list({ page_size: 20 });
      check('Birinchi sahifa items qaytadi',
        page1 && Array.isArray(page1.items) && page1.items.length > 0);
      check('Birinchi sahifa ≤ 20 item (performance §7)',
        page1.items.length <= 20, `topildi: ${page1.items.length}`);
      check('has_more true', page1.has_more === true);
      check('next_cursor mavjud', !!page1.next_cursor);

      // Ikkinchi sahifa
      const page2 = await S.inbox.list({ page_size: 20, cursor: page1.next_cursor });
      check('Ikkinchi sahifa olindi',
        page2 && page2.items.length > 0);
      // Duplikat bo'lmasligi
      const ids1 = new Set(page1.items.map(i => i.id));
      const overlap = page2.items.filter(i => ids1.has(i.id));
      check('Sahifalar orasida duplikat YO\'Q',
        overlap.length === 0, `duplikat: ${overlap.length}`);

      // Status filter
      const newOnly = await S.inbox.list({ status: 'new', page_size: 50 });
      check('status=new filter ishlaydi',
        newOnly.items.every(i => i.status === 'new'));
    });

    await section('Status update mock — transitionlar', async () => {
      const w = dom.window;
      const S = w.Adminbot.Core.Services;
      const all = await S.inbox.list({ page_size: 50 });
      const newOne = all.items.find(i => i.status === 'new');
      check('"new" status order topildi', !!newOne);

      // Valid transition: new → accepted
      const updated = await S.inbox.updateStatus(newOne.id, 'accepted');
      check('new → accepted muvaffaqiyatli', updated && updated.status === 'accepted');

      // Invalid transition: accepted → delivered (skip preparing/ready)
      let bad = null;
      try {
        await S.inbox.updateStatus(newOne.id, 'delivered');
      } catch (e) { bad = e; }
      check('Noto\'g\'ri transition → 409', bad && bad.status === 409,
        bad ? `status=${bad.status}` : 'xato bo\'lmadi');
    });

    await section('OrderStatusBadge — Labels orqali', async () => {
      const w = dom.window;
      check('OrderStatusBadge ro\'yxatda', !!w.Adminbot.Components.OrderStatusBadge);
      // Komponent setup() bevosita Labels chaqirishi kerak — bilvosita tekshiruv:
      const L = w.Adminbot.Core.Labels;
      const info = L.formatStatus('new', 'order');
      check('Labels.formatStatus("new") badge="warning"', info.badge === 'warning');
      check('Labels.formatStatus("new") label="Yangi"', info.label === 'Yangi');
    });
  });

  // 2. UI render testlari — InboxList route'iga o'tib
  await withDom('http://localhost/?mock=true&role=owner', async (dom) => {
    await section('InboxList render (orders route)', async () => {
      const w = dom.window;
      w.Adminbot.Core.Router.go('orders');
      await new Promise(r => setTimeout(r, 350));
      // Filter chip'lar
      const chips = w.document.querySelectorAll('[data-status-filter]');
      check('Filter chip\'lar render bo\'ldi', chips.length >= 5,
        `topildi: ${chips.length}`);
      const chipKeys = Array.from(chips).map(c => c.getAttribute('data-status-filter'));
      check('"all" chip mavjud', chipKeys.includes('all'));
      check('"new" chip mavjud', chipKeys.includes('new'));
      check('"delivered" chip mavjud', chipKeys.includes('delivered'));

      // Order kartochkalar
      const cards = w.document.querySelectorAll('[data-order-id]');
      check('OrderCard\'lar render bo\'ldi', cards.length > 0,
        `topildi: ${cards.length}`);
      check('Birinchi yuklashda ≤20 card (performance)',
        cards.length <= 20, `topildi: ${cards.length}`);

      // "Yana yuklash" tugmasi — "all" filtriga o'tib tekshiramiz
      // (default 'new' filterda 5 ta order bor, 20 dan kam — hasMore=false)
      const allChip = w.document.querySelector('[data-status-filter="all"]');
      allChip.click();
      await new Promise(r => setTimeout(r, 250));
      const loadMore = w.document.querySelector('[data-action="load-more"]');
      check('"Yana yuklash" tugmasi "all" filterda mavjud', !!loadMore);
    });

    await section('OrderCard ichida — status badge va extensionlar', async () => {
      const w = dom.window;
      const firstCard = w.document.querySelector('[data-order-id]');
      check('Birinchi OrderCard tanlandi', !!firstCard);

      // Status badge
      const badge = firstCard && firstCard.querySelector('[data-status]');
      check('OrderStatusBadge OrderCard ichida', !!badge);

      // Extension'lar — adapter shop OrderCard.extensions:
      //   ['delivery_address', 'payment_method', 'note']
      const addrExt = firstCard && firstCard.querySelector('[data-ext="delivery_address"]');
      const payExt = firstCard && firstCard.querySelector('[data-ext="payment_method"]');
      check('AddressBlock extension render bo\'ldi', !!addrExt);
      check('PaymentBlock extension render bo\'ldi', !!payExt);
      // NoteBlock — faqat note bo'lsa ko'rinadi (mock'da har 4-buyurtmada bor)
    });

    await section('Filter o\'zgartirish — chip click', async () => {
      const w = dom.window;
      const beforeCount = w.document.querySelectorAll('[data-order-id]').length;

      // "new" filtriga o'tamiz
      const newChip = w.document.querySelector('[data-status-filter="new"]');
      check('"new" chip mavjud', !!newChip);
      newChip.click();
      await new Promise(r => setTimeout(r, 250));

      const afterCount = w.document.querySelectorAll('[data-order-id]').length;
      check('Filter o\'zgardi → ro\'yxat yangilandi',
        afterCount !== beforeCount || afterCount > 0,
        `oldin=${beforeCount}, keyin=${afterCount}`);

      // Chip active class
      const activeChip = w.document.querySelector('.chip--active');
      check('Faol chip active class oldi',
        activeChip && activeChip.getAttribute('data-status-filter') === 'new');

      // Hammasi 'new' status'da bo'lishi kerak
      const cards = w.document.querySelectorAll('[data-order-id]');
      if (cards.length > 0) {
        const badges = Array.from(cards).map(c => {
          const b = c.querySelector('[data-status]');
          return b && b.getAttribute('data-status');
        });
        const allNew = badges.every(s => s === 'new');
        check('Filter natijasi: barcha "new" status', allNew,
          `statuslar: ${badges.slice(0, 5).join(', ')}`);
      }
    });

    await section('Real-time push — order.created prepend', async () => {
      const w = dom.window;
      // "all" filtriga qaytamiz
      const allChip = w.document.querySelector('[data-status-filter="all"]');
      allChip.click();
      await new Promise(r => setTimeout(r, 200));
      const before = w.document.querySelectorAll('[data-order-id]').length;

      // Yangi order push
      check('__mockNewOrder mavjud', typeof w.__mockNewOrder === 'function');
      const newOrder = w.__mockNewOrder();
      check('Yangi order yaratildi', !!newOrder && !!newOrder.id);

      await new Promise(r => setTimeout(r, 150));
      const after = w.document.querySelectorAll('[data-order-id]').length;
      check('Real-time: yangi card qo\'shildi',
        after === before + 1, `oldin=${before}, keyin=${after}`);

      // Birinchi pozitsiyada
      const firstId = w.document.querySelector('[data-order-id]').getAttribute('data-order-id');
      check('Yangi order birinchi pozitsiyada',
        firstId === newOrder.id, `topildi=${firstId}, kutilgan=${newOrder.id}`);
    });

    await section('Idempotency — duplikat event qo\'shilmaydi', async () => {
      const w = dom.window;
      const before = w.document.querySelectorAll('[data-order-id]').length;
      // Bir xil ID bilan event yuboramiz
      const dupEvent = {
        id: 'evt_dup_test_1',
        type: 'order.created',
        entity_id: 'ord_dup_test',
        payload: {
          id: 'ord_dup_test',
          number: 9999,
          status: 'new',
          customer_name: 'Test',
          total: 100000,
          created_at: new Date().toISOString(),
        },
      };
      w.__mockPushEvent(dupEvent);
      await new Promise(r => setTimeout(r, 100));
      const mid = w.document.querySelectorAll('[data-order-id]').length;
      check('1-marta qo\'shildi', mid === before + 1);
      // 2-marta yuborish — duplikat
      w.__mockPushEvent(dupEvent);
      await new Promise(r => setTimeout(r, 100));
      const after = w.document.querySelectorAll('[data-order-id]').length;
      check('2-marta event qo\'shilmadi (idempotent)',
        after === before + 1, `oldin=${before}, keyin=${after}`);
    });

    await section('order.status_changed — mavjud item yangilanadi', async () => {
      const w = dom.window;
      // Mavjud order'ni topamiz
      const firstCard = w.document.querySelector('[data-order-id]');
      const orderId = firstCard.getAttribute('data-order-id');
      const oldStatus = firstCard.querySelector('[data-status]').getAttribute('data-status');

      // Status o'zgarishi event push
      const newStatus = oldStatus === 'new' ? 'accepted' : 'preparing';
      w.__mockPushEvent({
        id: 'evt_status_test_' + Date.now(),
        type: 'order.status_changed',
        entity_id: orderId,
        payload: { id: orderId, status: newStatus, updated_at: new Date().toISOString() },
      });
      await new Promise(r => setTimeout(r, 150));

      // "all" filter'da — item joyda turishi va status yangilanishi kerak
      const sameCard = w.document.querySelector(`[data-order-id="${orderId}"]`);
      if (sameCard) {
        const nowStatus = sameCard.querySelector('[data-status]').getAttribute('data-status');
        check('Mavjud order status yangilandi',
          nowStatus === newStatus, `oldin=${oldStatus}, hozir=${nowStatus}`);
      } else {
        // "all" filtrida bo'lsa, item qoladi. Yo'qolib qolsa — test xato
        check('Mavjud order status yangilandi (yo\'qolib qoldi)', false,
          'card yo\'qoldi');
      }
    });

    await section('Status advance — runAction orqali', async () => {
      const w = dom.window;
      // "new" status order topish
      const newChip = w.document.querySelector('[data-status-filter="new"]');
      newChip.click();
      await new Promise(r => setTimeout(r, 250));

      const cards = w.document.querySelectorAll('[data-order-id]');
      if (cards.length === 0) {
        check('Test uchun new order topildi', false, 'new order yo\'q');
        return;
      }
      const card = cards[0];
      // Adapter primary_actions.new = ['accepted'] — accepted tugma chiqishi kerak
      const acceptBtn = card.querySelector('[data-action="advance-to-accepted"]');
      check('"accepted" advance tugmasi mavjud', !!acceptBtn);

      if (acceptBtn) {
        const orderId = card.getAttribute('data-order-id');
        const beforeCount = cards.length;
        acceptBtn.click();
        // runAction async — kutamiz
        await new Promise(r => setTimeout(r, 350));
        // 'new' filter'da bo'lganimiz uchun, order accepted'ga o'tib filterdan chiqadi
        const stillThere = w.document.querySelector(`[data-order-id="${orderId}"]`);
        check('Status accepted bo\'lgandan keyin "new" filter\'dan chiqdi',
          !stillThere, `topildi: ${!!stillThere}`);
      }
    });
  });

  // Adapter terms override
  await withDom('http://localhost/?mock=true', async (dom) => {
    await section('Labels.formatStatus terms override', async () => {
      const w = dom.window;
      const L = w.Adminbot.Core.Labels;
      const def = L.formatStatus('delivered', 'order');
      check('Default "delivered" = "Yetkazildi"', def.label === 'Yetkazildi');
      const overridden = L.formatStatus('delivered', 'order', { delivered: 'Yetib bordi' });
      check('Terms override → "Yetib bordi"',
        overridden.label === 'Yetib bordi' && overridden.badge === 'success');
    });
  });

  // useEvents cleanup
  await withDom('http://localhost/?mock=true&role=owner', async (dom) => {
    await section('useEvents — komponent unmount cleanup', async () => {
      const w = dom.window;
      // Inbox'ga o'tamiz
      w.Adminbot.Core.Router.go('orders');
      await new Promise(r => setTimeout(r, 250));

      // Subscribe count'ni tekshirish uchun — qancha listener bor
      // (Events.subs ichidagi 'order.created' uchun handlers soni)
      // To'g'ridan-to'g'ri Events.subs Map'iga kira olmaymiz, lekin
      // boshqa route'ga o'tib qaytsak, agar cleanup ishlamasa,
      // duplikat handler'lar paydo bo'ladi va event 2 marta ishlaydi.

      // Hozirgi ro'yxat soni
      const before = w.document.querySelectorAll('[data-order-id]').length;

      // Boshqa route'ga o'tish va qaytish — agar cleanup ishlasa,
      // bitta listener bo'ladi
      w.Adminbot.Core.Router.go('dashboard');
      await new Promise(r => setTimeout(r, 200));
      w.Adminbot.Core.Router.go('orders');
      await new Promise(r => setTimeout(r, 250));

      // Yangi event push
      const newOrder = w.__mockNewOrder();
      await new Promise(r => setTimeout(r, 150));

      const after = w.document.querySelectorAll('[data-order-id]').length;
      // Faqat 1 ta yangi card qo'shilishi kerak (cleanup ishlasa)
      check('useEvents cleanup: route o\'zgartirgandan keyin duplikat listener YO\'Q',
        after === before + 1,
        `before=${before}, after=${after} (kutilgan: ${before + 1})`);
    });
  });

  // Pagination — "Yana yuklash" haqiqatan ishlashi
  await withDom('http://localhost/?mock=true&role=owner', async (dom) => {
    await section('Pagination — "Yana yuklash" ikkinchi sahifa', async () => {
      const w = dom.window;
      w.Adminbot.Core.Router.go('orders');
      await new Promise(r => setTimeout(r, 350));

      // "all" filter
      const allChip = w.document.querySelector('[data-status-filter="all"]');
      allChip.click();
      await new Promise(r => setTimeout(r, 250));

      const before = w.document.querySelectorAll('[data-order-id]').length;
      check('Birinchi sahifada ≤20 item', before <= 20, `topildi: ${before}`);

      const loadMore = w.document.querySelector('[data-action="load-more"]');
      check('"Yana yuklash" tugma mavjud', !!loadMore);
      if (!loadMore) return;

      loadMore.click();
      await new Promise(r => setTimeout(r, 350));

      const after = w.document.querySelectorAll('[data-order-id]').length;
      check('Yana yuklash → ko\'proq item ko\'rindi',
        after > before, `oldin=${before}, keyin=${after}`);

      // Duplikat YO'Q (idempotent pagination)
      const ids = Array.from(w.document.querySelectorAll('[data-order-id]'))
        .map(c => c.getAttribute('data-order-id'));
      const uniq = new Set(ids);
      check('Pagination duplikatsiz', uniq.size === ids.length,
        `ids=${ids.length}, uniq=${uniq.size}`);
    });
  });

  // Static performance check — template ichida og'ir operatsiya YO'Q
  await (async () => {
    await section('Static: template ichida og\'ir filter/sort YO\'Q', async () => {
      const srcDir = path.join(ROOT, 'src', 'components');
      const files = [];
      function walk(d) {
        for (const e of fs.readdirSync(d, { withFileTypes: true })) {
          const p = path.join(d, e.name);
          if (e.isDirectory()) walk(p);
          else if (e.name.endsWith('.js')) files.push(p);
        }
      }
      walk(srcDir);

      const heavyOffenders = [];
      for (const f of files) {
        const txt = fs.readFileSync(f, 'utf8');
        // template:` ... ` ichini izlaymiz
        const templateMatch = txt.match(/template\s*:\s*`([\s\S]*?)`/);
        if (!templateMatch) continue;
        const template = templateMatch[1];
        // template ichida .filter( yoki .sort( yoki .map( bo'lsa — flag
        // (computed yoki setup ichida ruxsat, lekin template'da YO'Q)
        const patterns = [
          { name: '.filter(', re: /\{\{[^}]*\.filter\s*\(/ },
          { name: '.sort(',   re: /\{\{[^}]*\.sort\s*\(/ },
          { name: '.reduce(', re: /\{\{[^}]*\.reduce\s*\(/ },
        ];
        for (const p of patterns) {
          if (p.re.test(template)) {
            heavyOffenders.push(`${path.relative(ROOT, f)} (${p.name})`);
          }
        }
      }
      check('Template ichida {{ ...filter/sort/reduce }} YO\'Q (performance §7)',
        heavyOffenders.length === 0,
        heavyOffenders.length ? heavyOffenders.join(', ') : '');
    });
  })();

  console.log('\n=========================');
  console.log(`Natija: ${passed} PASS / ${failed} FAIL`);
  if (failures.length) {
    console.log('\nFAIL detallari:');
    for (const f of failures) console.log(`  - ${f.name}` + (f.detail ? ` — ${f.detail}` : ''));
    process.exit(1);
  } else {
    console.log('Hammasi yashil ✓');
  }
})().catch(e => {
  console.error('Test runner crashed:', e);
  process.exit(2);
});
