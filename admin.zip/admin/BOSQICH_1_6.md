# Bosqich 1.6 — JS optimizatsiya va xavfsizlik baseline

> Bu hujjat Bosqich 1.5'dan keyin va Bosqich 2'gacha bo'lgan oraliq ishni qamrab oladi.

---

## Tuzatilgan 2 ta kritik xavfsizlik bug'i

### 1. Mock mode prod'da avtomatik ochilardi (§9.1)

**Avval:**
```js
function isMockMode() {
  if (qs('mock') === 'true') return true;
  if (!window.Telegram || !window.Telegram.WebApp) return true;  // ⚠️ XAVFLI
  return false;
}
```

Public domain'da Telegram'siz ochsa, **mock owner sifatida kirib qolardi**.

**Hozir (variant C — defense in depth):**
```js
function isMockMode() {
  // 1) Production build'da har doim false (__ADMINBOT_PROD__)
  // 2) Dev build'da: dev hostname (localhost) + ?mock=true
  return Startup.isMockAllowed();
}
```

3 qatlamli himoya:
- **Build flag** — `python3 build.py --mode=prod` mock fayllarni umuman bundle'ga kiritmaydi va `window.__ADMINBOT_PROD__ = true` o'rnatadi
- **Hostname** — localhost/127.0.0.1/0.0.0.0/.local/.test bo'lmasa, mock paramlari tashlanadi
- **Explicit opt-in** — `?mock=true` aniq kerak (avtomatik fallback yo'q)

### 2. Event stream PIN'gacha ochilardi (§9.5)

**Avval:** AuthGate boot oxirida `Events.connect()` → keyin PinGate ochilardi → lekin event stream allaqachon ochiq edi.

**Hozir:** Event ulanish RootShell'ning `watch(phase)` ichida:
```js
watch(phase, (now, prev) => {
  if (now === 'app' && prev !== 'app') {
    Events.connect();           // PIN unlock'dan keyin
    Events.syncSince(...);
  }
  if ((now === 'locked' || now === 'pin') && prev === 'app') {
    Events.disconnect(now);     // Lock yoki PIN ekraniga qaytsa uziladi
  }
});
```

Test `1.6.K` va `1.6.L` bu tartibni tasdiqlaydi.

---

## Yangi modullar

### `core/startup.js` (§9.2) — URL paramlar yagona kirish nuqtasi

URL/hash/start_param **faqat shu yerda** o'qiladi. Komponentlarga `Startup.params.role` orqali keladi.

Allowlist:
| Parametr | Tur | Dev-only | Validatsiya |
|---|---|---|---|
| `tenant_id` | string | yo'q | `/^[A-Za-z0-9_\-]{1,64}$/` |
| `mock` | flag | ✓ | `true` yoki `1` |
| `biz` | enum | ✓ | 7 biznes turi |
| `role` | enum | ✓ | owner/manager/staff/courier |
| `pin` | flag | ✓ | `on`/`off` |
| `pin_locked` | flag | ✓ | `on`/`off` |

Telegram `start_param`:
- `route:<key>` — bootdan keyin shu route'ga
- `event:<id>` — inbox'da fokuslangan event
- Faqat alphanumeric + `_` + `-`, max 200 belgi

Production hostname'da xom URL `history.replaceState()` bilan tozalanadi (sensitive query share qilingan link'larda qolmasligi uchun).

### `core/labels.js` (§3) — yagona status/role mapping

Universal jadval. Hech qanday adapter o'z rangini belgilamaydi:

```js
ORDER_STATUS = {
  new:       { label: 'Yangi',         badge: 'warning' },
  accepted:  { label: 'Qabul qilindi', badge: 'info' },
  preparing: { label: 'Tayyorlanmoqda', badge: 'primary' },
  delivered: { label: 'Yetkazildi',    badge: 'success' },
  served:    { label: 'Berildi',       badge: 'success' },  // restaurant
  shipped:   { label: 'Jo'natildi',    badge: 'success' },  // supplier
  cancelled: { label: 'Bekor qilindi', badge: 'danger' },
  // ...
};
```

Adapter faqat kalitlarni deklare qiladi:
```js
// shop adapter
InboxList: { statuses: ['new', 'accepted', 'preparing', 'delivered', 'cancelled'] }

// restaurant adapter
InboxList: { statuses: ['new', 'accepted', 'preparing', 'served', 'cancelled'] }
```

Adapter `terms` config bilan label'ni override qila oladi (lekin badge variant'i hech qachon o'zgarmaydi — dizayn universal).

### `core/actions.js` (§5) — `runAction()` wrapper

Write actionlar uchun yagona shablon:
```js
await Actions.runAction({
  permission: 'orders.update',
  actionLabel: 'Buyurtmani qabul qilish',
  confirm: { title: '...', body: '...', confirmText: 'Ha', cancelText: 'Yo\'q' },
  action: () => Services.inbox.updateStatus(id, 'accepted'),
  onSuccess: (result) => updateLocalOrder(result),
  successMessage: 'Status yangilandi',
});
```

Avtomatik:
1. `Permissions.can()` tekshiruvi → yo'q bo'lsa toast + early return
2. Confirm dialog (agar berilgan bo'lsa) → bekor qilinsa early return
3. Loading state (Vue ref berilsa toggle qiladi)
4. Service layer chaqirig'i `try/catch` bilan
5. Xato → `Utils.errorText()` bilan toast (401/423 esa LockScreen ishlaydi, takror toast yo'q)
6. Muvaffaqiyat → success toast + `onSuccess` callback

### `core/composables.js` (§6) — `useEvents()` Vue composable

Event listener'lar auto-cleanup:
```js
const { subscribe } = Composables.useEvents();
subscribe('order.created', (e) => addOrder(e.payload));
subscribe('order.status_changed', (e) => updateOrder(e));
// Komponent unmount → barcha listener avtomat tozalanadi
```

`Vue.onScopeDispose` orqali ishlaydi — har route o'zgarganda eski komponent listener'lari qoladi degan muammo yo'q.

### `core/utils.js`'ga yangi helperlar

`formatTime`, `formatPhone`, `initials`, `classNames`, `safeJsonParse`, `clearAllAuthStorage`.

Token storage:
- **Real mode** — in-memory (`_tokenMem.value`). Refresh'da yo'qoladi, Telegram initData har boot'da qayta keladi.
- **Mock mode** — localStorage (dev qulayligi).

`Utils.qs()` deprecated — yangi kod `Startup.get(...)` ishlatadi.

---

## Build tizimi yangiliklari

### `--mode=dev|prod` flag

```bash
python3 build.py              # dev (sukut)
python3 build.py --mode=prod  # production
```

| | dev | prod |
|---|---|---|
| `src/mocks/*.js` bundle'da | ✓ | ✗ |
| `__ADMINBOT_BUILD__` | `"dev"` | `"prod"` |
| `__ADMINBOT_PROD__` | yo'q | `true` |
| `isMockAllowed()` | hostname check | har doim `false` |

Prod build'da `dist/index.html` taxminan **11 KB kichikroq** (mock kod yo'q).

---

## Static security tekshiruvlari (§9.7)

Test fayli `src/**/*.js` ni grep qiladi va quyidagilar topilsa **FAIL**:

| Pattern | Sabab | Allowlist |
|---|---|---|
| `setInterval(` | Polling taqiqlangan | — |
| `v-html` | XSS riski | — |
| `.innerHTML = ` / `.outerHTML = ` / `.insertAdjacentHTML(` | XSS riski | — |
| `eval(` / `new Function(` | Kod injection | — |
| `location.search` / `location.hash` | URL bypass | `startup.js`, `router.js` |

Bu testlar Bosqich 2'da yangi komponentlar yozilganda **muhim qoidalarni avtomatik tekshiradi**.

---

## Komponent refactor namunalari

### `StaffManager.onRemove()` — eski va yangi

**Eski (manual try/catch):**
```js
async function onRemove(s) {
  if (!canManage.value) return;
  if (s.is_self) { UI.toast('O\'zingizni o\'chira olmaysiz', {type:'warn'}); return; }
  const ok = await UI.confirm({...});
  if (!ok) return;
  try {
    await Services.staff.remove(s.id);
    await load();
    UI.toast('O\'chirildi', {type:'success'});
  } catch (e) {
    UI.toast(Utils.errorText(e), {type:'error'});
  }
}
```

**Yangi (`runAction`):**
```js
async function onRemove(s) {
  if (s.is_self) { UI.toast('O\'zingizni o\'chira olmaysiz', {type:'warn'}); return; }
  await Actions.runAction({
    permission: 'staff.manage',
    confirm: { title: '...', body: '...', confirmText: 'O\'chirish' },
    action: () => Services.staff.remove(s.id),
    onSuccess: async () => { await load(); },
    successMessage: 'O\'chirildi',
  });
}
```

Yarim qisqaroq, hech qanday `try/catch` yo'q, xato handling avtomatik.

### Role badge — eski va yangi

**Eski (hardcoded switch):**
```js
const roleLabel = computed(() => {
  switch (role) {
    case 'owner': return 'Egasi';
    case 'manager': return 'Menejer';
    case 'staff': return 'Xodim';
    case 'courier': return 'Kuryer';
  }
});
// template: <span class="badge" :class="'badge--' + role">{{ roleLabel }}</span>
```

**Yangi (`Labels.formatStatus`):**
```js
const roleInfo = computed(() => Labels.formatStatus(role, 'role'));
// template: <span class="badge" :class="'badge--' + roleInfo.badge">{{ roleInfo.label }}</span>
```

Bir manba — barcha komponentlarda bir xil.

---

## Test natijasi: **152 PASS / 0 FAIL**

| Bosqich | Test soni | Tavsif |
|---|---|---|
| 1.0 | 95 | original (mock boot, events, PIN, permissions, ...) |
| 1.5 | 16 | design tizimi (tokens, primitivlar, eski klasslar yo'qligi) |
| **1.6** | **41** | **static security, prod build, startup, in-memory token, runAction, Labels, useEvents, event ulanish tartibi** |

---

## Bosqich 2 ga qoldirilgan (eslatma)

- `core/permissions.js`'da hujjatlash: backend authoritative ekanligi har komponentda kommentariy bilan
- Adapter'lar `enabled_statuses` deklaratsiyasini qabul qilishi (hozir mock dashboard barcha statuslarni qaytaradi, lekin component tegishli kalitlarni adapter config'idan olishi kerak)
- `WebSocketEventTransport` to'liq implementatsiyasi
- Token in-memory model'ni Telegram WebApp real oqimida sinab ko'rish

---

## Yangi kod yo'riqnomasi

Bosqich 2 komponent yozayotganda quyidagilarga rioya qiling:

1. **API**: faqat `Services.*` chaqiring. To'g'ridan-to'g'ri `fetch` yoki endpoint string YO'Q.
2. **URL params**: `Startup.get('tenant_id')` ishlating, `location.search` YO'Q.
3. **Write actionlar**: `Actions.runAction({...})` orqali — manual try/catch YO'Q.
4. **Permission check**: `Permissions.require(key, label)` (toast bilan) yoki `Permissions.can(key)` (sukut).
5. **Status/role label**: `Labels.formatStatus(key, kind, terms)` — manual switch YO'Q.
6. **Event listener'lar**: `Composables.useEvents()` — manual `onUnmounted` YO'Q.
7. **Format**: `Utils.formatMoney/Date/Time/Phone`, `Utils.initials`, `Utils.relativeTime`.
8. **CSS**: faqat token'lar va primitivlar (DESIGN_SYSTEM.md).
9. **HTML render**: `{{ value }}` yoki `textContent`. `v-html` / `innerHTML` YO'Q.

Bu qoidalar test bilan tekshiriladi — buzilsa build FAIL bo'ladi.
